/**
 * Generated bundle index. Do not edit.
 */
/// <amd-module name="fairfood-form-components" />
export * from './public-api';
