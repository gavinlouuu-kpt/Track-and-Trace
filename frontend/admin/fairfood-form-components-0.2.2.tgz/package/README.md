# FairfoodFormComponents

This library was generated with [Angular CLI](https://github.com/angular/angular-cli) version 15.1.0.

## Code scaffolding

Run `ng generate component component-name --project fairfood-form-components` to generate a new component. You can also use `ng generate directive|pipe|service|class|guard|interface|enum|module --project fairfood-form-components`.
> Note: Don't forget to add `--project fairfood-form-components` or else it will be added to the default project in your `angular.json` file. 

## Build

Run `ng build fairfood-form-components` to build the project. The build artifacts will be stored in the `dist/` directory.

## Publishing

After building your library with `ng build fairfood-form-components`, go to the dist folder `cd dist/fairfood-form-components` and run `npm publish`.

## Running unit tests

Run `ng test fairfood-form-components` to execute the unit tests via [Karma](https://karma-runner.github.io).

## Further help

To get more help on the Angular CLI use `ng help` or go check out the [Angular CLI Overview and Command Reference](https://angular.io/cli) page.
