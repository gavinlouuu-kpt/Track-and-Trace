import * as i0 from '@angular/core';
import { EventEmitter, Component, Input, Output, Pipe, ChangeDetectionStrategy, ViewChild } from '@angular/core';
import * as i1 from '@angular/common';
import { CommonModule, NgClass } from '@angular/common';
import * as i1$2 from '@angular/material/menu';
import { MatMenuModule } from '@angular/material/menu';
import * as i2 from '@angular/material/icon';
import { MatIconModule } from '@angular/material/icon';
import * as i3 from '@angular/material/tooltip';
import { MatTooltipModule } from '@angular/material/tooltip';
import * as i2$1 from '@angular/forms';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import * as i1$1 from '@angular/material/radio';
import { MatRadioModule } from '@angular/material/radio';
import * as i2$2 from '@angular/material/checkbox';
import { MatCheckboxModule } from '@angular/material/checkbox';

class FfFilterBoxComponent {
    constructor() {
        this.boxState = 'default';
        this.showRedBorder = false;
        this.tooltipText = '';
        this.boxClicked = new EventEmitter();
    }
    // Method to handle item click
    itemClicked() {
        this.boxClicked.emit(true);
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "16.2.12", ngImport: i0, type: FfFilterBoxComponent, deps: [], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "16.2.12", type: FfFilterBoxComponent, isStandalone: true, selector: "app-ff-filter-box", inputs: { label: "label", value: "value", boxState: "boxState", showRedBorder: "showRedBorder", tooltipText: "tooltipText", customId: "customId" }, outputs: { boxClicked: "boxClicked" }, ngImport: i0, template: "<div class=\"ff-dropdown-container ff-flex-align-center pointer\" (click)=\"itemClicked()\"\r\n    [ngClass]=\"{'error': showRedBorder, 'active': boxState === 'selected', 'default': boxState !== 'selected', 'short': !label}\"\r\n    [id]=\"customId || 'filterBox-'+label\" [matTooltip]=\"showRedBorder?tooltipText:''\">\r\n    <span class=\"box-label text-overflow\" *ngIf=\"label\" id=\"filterLabel\">{{label}}:</span>&nbsp;\r\n    <span class=\"box-value text-overflow\" title=\"{{value}}\" id=\"filterValue\">{{value}}</span>\r\n    <mat-icon>keyboard_arrow_down</mat-icon>\r\n</div>", styles: [".ff-dropdown-container{position:relative;max-width:227px;width:200px;border-radius:6px;border:1px solid var(--border-color);padding:10px 30px 10px 20px}.ff-dropdown-container mat-icon{position:absolute;right:15px}.ff-dropdown-container .box-value,.ff-dropdown-container .box-label{font-size:14px;color:var(--font-color)}.ff-dropdown-container .box-label{font-family:var(--font-regular);opacity:.7;max-width:100px}.ff-dropdown-container .box-value{font-family:var(--font-bold);max-width:120px}.ff-dropdown-container.active{background-color:var(--color-filter-active)}.ff-dropdown-container.active .box-value{color:var(--font-color)}.ff-dropdown-container.default{background-color:var(--color-white)}.ff-dropdown-container.default .box-value{opacity:.7;color:var(--font-color)}.ff-dropdown-container.error{border:1px solid var(--color-secondary)}.ff-dropdown-container.short{width:100px}.ff-dropdown-container mat-icon{color:var(--color-dropdown-arrow);right:8px;top:6px}\n"], dependencies: [{ kind: "ngmodule", type: CommonModule }, { kind: "directive", type: i1.NgClass, selector: "[ngClass]", inputs: ["class", "ngClass"] }, { kind: "directive", type: i1.NgIf, selector: "[ngIf]", inputs: ["ngIf", "ngIfThen", "ngIfElse"] }, { kind: "ngmodule", type: MatIconModule }, { kind: "component", type: i2.MatIcon, selector: "mat-icon", inputs: ["color", "inline", "svgIcon", "fontSet", "fontIcon"], exportAs: ["matIcon"] }, { kind: "ngmodule", type: MatTooltipModule }, { kind: "directive", type: i3.MatTooltip, selector: "[matTooltip]", exportAs: ["matTooltip"] }] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "16.2.12", ngImport: i0, type: FfFilterBoxComponent, decorators: [{
            type: Component,
            args: [{ selector: 'app-ff-filter-box', standalone: true, imports: [CommonModule, MatIconModule, MatTooltipModule], template: "<div class=\"ff-dropdown-container ff-flex-align-center pointer\" (click)=\"itemClicked()\"\r\n    [ngClass]=\"{'error': showRedBorder, 'active': boxState === 'selected', 'default': boxState !== 'selected', 'short': !label}\"\r\n    [id]=\"customId || 'filterBox-'+label\" [matTooltip]=\"showRedBorder?tooltipText:''\">\r\n    <span class=\"box-label text-overflow\" *ngIf=\"label\" id=\"filterLabel\">{{label}}:</span>&nbsp;\r\n    <span class=\"box-value text-overflow\" title=\"{{value}}\" id=\"filterValue\">{{value}}</span>\r\n    <mat-icon>keyboard_arrow_down</mat-icon>\r\n</div>", styles: [".ff-dropdown-container{position:relative;max-width:227px;width:200px;border-radius:6px;border:1px solid var(--border-color);padding:10px 30px 10px 20px}.ff-dropdown-container mat-icon{position:absolute;right:15px}.ff-dropdown-container .box-value,.ff-dropdown-container .box-label{font-size:14px;color:var(--font-color)}.ff-dropdown-container .box-label{font-family:var(--font-regular);opacity:.7;max-width:100px}.ff-dropdown-container .box-value{font-family:var(--font-bold);max-width:120px}.ff-dropdown-container.active{background-color:var(--color-filter-active)}.ff-dropdown-container.active .box-value{color:var(--font-color)}.ff-dropdown-container.default{background-color:var(--color-white)}.ff-dropdown-container.default .box-value{opacity:.7;color:var(--font-color)}.ff-dropdown-container.error{border:1px solid var(--color-secondary)}.ff-dropdown-container.short{width:100px}.ff-dropdown-container mat-icon{color:var(--color-dropdown-arrow);right:8px;top:6px}\n"] }]
        }], propDecorators: { label: [{
                type: Input
            }], value: [{
                type: Input
            }], boxState: [{
                type: Input
            }], showRedBorder: [{
                type: Input
            }], tooltipText: [{
                type: Input
            }], customId: [{
                type: Input
            }], boxClicked: [{
                type: Output
            }] } });

/**
 * @component FfFilterBoxComponent
 * @description
 *   The `FfFilterBoxComponent` is a reusable Angular component that represents a filter box with a label, value, and dropdown arrow.
 *   It can be used to display and interact with filter options in an Angular application.
 *
 * @usage
 *   ```
 *   <app-ff-filter-box
 *     [label]="filterLabel"
 *     [value]="filterValue"
 *     [boxState]="filterState"
 *     (boxClicked)="onBoxClicked($event)"
 *   ></app-ff-filter-box>
 *   ```
 *
 * @inputs
 *   - `label` (string): The label text to display in the filter box.
 *   - `value` (string): The value to display in the filter box.
 *   - `boxState` (optional): The state of the filter box. Possible values are `'default'` and `'selected'`.
 *
 * @outputs
 *   - `boxClicked` (EventEmitter<boolean>): An event emitted when the filter box is clicked. It emits a boolean value (`true`).
 *
 * @example
 *   ```typescript
 *   import { Component } from '@angular/core';
 *
 *   @Component({
 *     selector: 'app-example',
 *     template: `
 *       <app-ff-filter-box
 *         [label]="'Category'"
 *         [value]="'All'"
 *         [boxState]="'default'"
 *         (boxClicked)="onFilterBoxClicked()"
 *       ></app-ff-filter-box>
 *     `,
 *   })
 *   export class ExampleComponent {
 *     onFilterBoxClicked() {
 *       // Handle filter box click event
 *     }
 *   }
 *   ```
 *
 * @styles
 *   The `FfFilterBoxComponent` applies the following CSS classes:
 *   - `.ff-dropdown-container`: The main container of the filter box.
 *   - `.active`: Applied when `boxState` is `'selected'`. Changes the background color of the filter box.
 *   - `.default`: Applied when `boxState` is `'default'`. Changes the background color of the filter box.
 *   - `.box-label`: The CSS class for the label text inside the filter box.
 *   - `.box-value`: The CSS class for the value text inside the filter box.
 *   - `mat-icon`: The CSS class for the dropdown arrow icon.
 *
 * @dependencies
 *   This component requires the following Angular modules and dependencies to be imported:
 *   - `@angular/core`: Angular core module.
 *   - `@angular/common`: Angular common module.
 *   - `@angular/material/icon`: Angular Material icon module (for the dropdown arrow icon).
 *
 * @version 1.0.0
 */

/* eslint-disable @typescript-eslint/no-explicit-any */
class FilterDropdownPipe {
    transform(items, searchKey) {
        if (!items || !searchKey) {
            return items;
        }
        // filter items array, items which match and return true will be kept
        return items.filter((item) => {
            if (item?.name && typeof item.name === 'string') {
                return item.name.toLowerCase().includes(searchKey.toLowerCase());
            }
            return false;
        });
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "16.2.12", ngImport: i0, type: FilterDropdownPipe, deps: [], target: i0.ɵɵFactoryTarget.Pipe }); }
    static { this.ɵpipe = i0.ɵɵngDeclarePipe({ minVersion: "14.0.0", version: "16.2.12", ngImport: i0, type: FilterDropdownPipe, isStandalone: true, name: "searchOptions", pure: false }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "16.2.12", ngImport: i0, type: FilterDropdownPipe, decorators: [{
            type: Pipe,
            args: [{
                    name: 'searchOptions',
                    pure: false,
                    standalone: true,
                }]
        }] });

/* eslint-disable @typescript-eslint/no-explicit-any */
class IdSelectionPipe {
    transform(item) {
        if (item.includes('+')) {
            return `countryCode-${item.split('+')[1]}`;
        }
        else {
            return item;
        }
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "16.2.12", ngImport: i0, type: IdSelectionPipe, deps: [], target: i0.ɵɵFactoryTarget.Pipe }); }
    static { this.ɵpipe = i0.ɵɵngDeclarePipe({ minVersion: "14.0.0", version: "16.2.12", ngImport: i0, type: IdSelectionPipe, isStandalone: true, name: "idSelection" }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "16.2.12", ngImport: i0, type: IdSelectionPipe, decorators: [{
            type: Pipe,
            args: [{
                    name: 'idSelection',
                    pure: true,
                    standalone: true,
                }]
        }] });

class FfDropMenuRadioComponent {
    constructor() {
        /**
         * Output: currentSelected
         * Description: Event emitted when an item is selected from the dropdown menu.
         * The selected item object is emitted as the event payload.
         */
        this.currentSelected = new EventEmitter();
        /**
         * Output: footerClicked
         * Description: Event emitted when the "Clear selection" footer is clicked.
         */
        this.footerClicked = new EventEmitter();
    }
    /**
     * Method: menuItemSelected
     * Description: Called when an item is selected from the dropdown menu.
     * Emits the 'currentSelected' event with the selected item as the payload.
     * @param selected - The selected item object.
     */
    menuItemSelected(selected) {
        this.searchString = '';
        this.currentSelected.emit(selected);
    }
    /**
     * Method: clearSelection
     * Description: Called when the "Clear selection" footer is clicked.
     * Emits the 'footerClicked' event.
     */
    clearSelection() {
        this.footerClicked.emit(true);
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "16.2.12", ngImport: i0, type: FfDropMenuRadioComponent, deps: [], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "16.2.12", type: FfDropMenuRadioComponent, isStandalone: true, selector: "app-ff-drop-menu-radio", inputs: { menuItems: "menuItems", hideSearch: "hideSearch", selectedId: "selectedId" }, outputs: { currentSelected: "currentSelected", footerClicked: "footerClicked" }, ngImport: i0, template: "<div class=\"menu-wrapper flex-column\">\r\n    <!-- Search box -->\r\n    <section class=\"search-box\" *ngIf=\"!hideSearch\">\r\n        <input type=\"text\" placeholder=\"Search\" class=\"search-item\" [(ngModel)]=\"searchString\"\r\n            [ngModelOptions]=\"{standalone: true}\" autocomplete=\"off\" autofocus id=\"searchItem\">\r\n        <svg width=\"11\" height=\"14\" viewBox=\"0 0 11 14\" fill=\"none\" xmlns=\"http://www.w3.org/2000/svg\">\r\n            <circle cx=\"5\" cy=\"5\" r=\"4.5\" stroke=\"#5691AE\" />\r\n            <line y1=\"-1\" x2=\"4.46301\" y2=\"-1\" transform=\"matrix(0.552178 0.833726 -0.878595 0.477568 6.49231 9.39453)\"\r\n                stroke=\"#5691AE\" stroke-width=\"2\" />\r\n        </svg>\r\n    </section>\r\n    <ul class=\"menu-list-items\" [ngClass]=\"hideSearch?'auto-height':'minimum-height'\">\r\n        <!-- Menu items -->\r\n        <mat-radio-group aria-label=\"Select an option\">\r\n            <li class=\"text-overflow\" *ngFor=\"let item of menuItems | searchOptions:searchString\">\r\n                <mat-radio-button [value]=\"item.id\" [checked]=\"item.id === selectedId\" (click)=\"menuItemSelected(item)\"\r\n                    id=\"radio{{item.id}}\">\r\n                    {{ item.name }}\r\n                </mat-radio-button>\r\n            </li>\r\n        </mat-radio-group>\r\n        <!-- No results message -->\r\n        <li *ngIf=\"(menuItems | searchOptions: searchString)?.length === 0\" id=\"noResults\">\r\n            No results found\r\n        </li>\r\n    </ul>\r\n    <!-- Clear selection footer -->\r\n    <section class=\"footer-box ff-flex-center\" (click)=\"clearSelection()\" id=\"clearSelection\">\r\n        Clear selection\r\n    </section>\r\n</div>", styles: [".menu-list-items{list-style:none;overflow:auto;padding:0 0 10px 10px;margin:0}.menu-list-items::-webkit-scrollbar{width:10px;height:8px}.menu-list-items::-webkit-scrollbar-track{border-radius:2px}.menu-list-items::-webkit-scrollbar-thumb{border-radius:3px;background-color:var(--color-scrollbar)}.menu-list-items.minimum-height{height:150px}.menu-list-items.auto-height{height:auto}.menu-list-items li{padding:8px 0;font-size:14px;color:var(--font-color);font-family:var(--font-medium)}.menu-list-items li ::ng-deep label{display:block;text-overflow:ellipsis;overflow:hidden;white-space:nowrap;width:160px}.menu-wrapper{box-sizing:border-box}.menu-wrapper .search-box,.menu-wrapper .footer-box{min-height:34px}.footer-box{text-transform:capitalize;font-size:14px;font-family:var(--font-bold);cursor:pointer;padding:5px 30px;border-top:1px solid var(--border-color);color:var(--color-secondary)}.search-box{position:relative;padding-left:5px;border:1px solid #f9fafb;border-radius:6px;margin:0 10px}.search-box.mobile-input{border:1px solid var(--border-color);margin-bottom:10px;border-radius:6px}.search-box input{border:0;z-index:5;color:var(--font-color-2);font-size:14px;height:34px;padding:5px 5px 5px 43px;background:var(--color-white);border-radius:2px;width:71%}.search-box input::placeholder{color:var(--font-color-2);opacity:1;font-size:16px}.search-box input:focus-visible{outline:none}.search-box svg{position:absolute;left:20px;top:9px;color:var(--font-color-2);z-index:6;height:30px;width:12px}\n"], dependencies: [{ kind: "ngmodule", type: MatRadioModule }, { kind: "directive", type: i1$1.MatRadioGroup, selector: "mat-radio-group", exportAs: ["matRadioGroup"] }, { kind: "component", type: i1$1.MatRadioButton, selector: "mat-radio-button", inputs: ["disableRipple", "tabIndex"], exportAs: ["matRadioButton"] }, { kind: "ngmodule", type: CommonModule }, { kind: "directive", type: i1.NgClass, selector: "[ngClass]", inputs: ["class", "ngClass"] }, { kind: "directive", type: i1.NgForOf, selector: "[ngFor][ngForOf]", inputs: ["ngForOf", "ngForTrackBy", "ngForTemplate"] }, { kind: "directive", type: i1.NgIf, selector: "[ngIf]", inputs: ["ngIf", "ngIfThen", "ngIfElse"] }, { kind: "ngmodule", type: FormsModule }, { kind: "directive", type: i2$1.DefaultValueAccessor, selector: "input:not([type=checkbox])[formControlName],textarea[formControlName],input:not([type=checkbox])[formControl],textarea[formControl],input:not([type=checkbox])[ngModel],textarea[ngModel],[ngDefaultControl]" }, { kind: "directive", type: i2$1.NgControlStatus, selector: "[formControlName],[ngModel],[formControl]" }, { kind: "directive", type: i2$1.NgModel, selector: "[ngModel]:not([formControlName]):not([formControl])", inputs: ["name", "disabled", "ngModel", "ngModelOptions"], outputs: ["ngModelChange"], exportAs: ["ngModel"] }, { kind: "pipe", type: FilterDropdownPipe, name: "searchOptions" }], changeDetection: i0.ChangeDetectionStrategy.OnPush }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "16.2.12", ngImport: i0, type: FfDropMenuRadioComponent, decorators: [{
            type: Component,
            args: [{ selector: 'app-ff-drop-menu-radio', standalone: true, imports: [MatRadioModule, CommonModule, FormsModule, FilterDropdownPipe], changeDetection: ChangeDetectionStrategy.OnPush, template: "<div class=\"menu-wrapper flex-column\">\r\n    <!-- Search box -->\r\n    <section class=\"search-box\" *ngIf=\"!hideSearch\">\r\n        <input type=\"text\" placeholder=\"Search\" class=\"search-item\" [(ngModel)]=\"searchString\"\r\n            [ngModelOptions]=\"{standalone: true}\" autocomplete=\"off\" autofocus id=\"searchItem\">\r\n        <svg width=\"11\" height=\"14\" viewBox=\"0 0 11 14\" fill=\"none\" xmlns=\"http://www.w3.org/2000/svg\">\r\n            <circle cx=\"5\" cy=\"5\" r=\"4.5\" stroke=\"#5691AE\" />\r\n            <line y1=\"-1\" x2=\"4.46301\" y2=\"-1\" transform=\"matrix(0.552178 0.833726 -0.878595 0.477568 6.49231 9.39453)\"\r\n                stroke=\"#5691AE\" stroke-width=\"2\" />\r\n        </svg>\r\n    </section>\r\n    <ul class=\"menu-list-items\" [ngClass]=\"hideSearch?'auto-height':'minimum-height'\">\r\n        <!-- Menu items -->\r\n        <mat-radio-group aria-label=\"Select an option\">\r\n            <li class=\"text-overflow\" *ngFor=\"let item of menuItems | searchOptions:searchString\">\r\n                <mat-radio-button [value]=\"item.id\" [checked]=\"item.id === selectedId\" (click)=\"menuItemSelected(item)\"\r\n                    id=\"radio{{item.id}}\">\r\n                    {{ item.name }}\r\n                </mat-radio-button>\r\n            </li>\r\n        </mat-radio-group>\r\n        <!-- No results message -->\r\n        <li *ngIf=\"(menuItems | searchOptions: searchString)?.length === 0\" id=\"noResults\">\r\n            No results found\r\n        </li>\r\n    </ul>\r\n    <!-- Clear selection footer -->\r\n    <section class=\"footer-box ff-flex-center\" (click)=\"clearSelection()\" id=\"clearSelection\">\r\n        Clear selection\r\n    </section>\r\n</div>", styles: [".menu-list-items{list-style:none;overflow:auto;padding:0 0 10px 10px;margin:0}.menu-list-items::-webkit-scrollbar{width:10px;height:8px}.menu-list-items::-webkit-scrollbar-track{border-radius:2px}.menu-list-items::-webkit-scrollbar-thumb{border-radius:3px;background-color:var(--color-scrollbar)}.menu-list-items.minimum-height{height:150px}.menu-list-items.auto-height{height:auto}.menu-list-items li{padding:8px 0;font-size:14px;color:var(--font-color);font-family:var(--font-medium)}.menu-list-items li ::ng-deep label{display:block;text-overflow:ellipsis;overflow:hidden;white-space:nowrap;width:160px}.menu-wrapper{box-sizing:border-box}.menu-wrapper .search-box,.menu-wrapper .footer-box{min-height:34px}.footer-box{text-transform:capitalize;font-size:14px;font-family:var(--font-bold);cursor:pointer;padding:5px 30px;border-top:1px solid var(--border-color);color:var(--color-secondary)}.search-box{position:relative;padding-left:5px;border:1px solid #f9fafb;border-radius:6px;margin:0 10px}.search-box.mobile-input{border:1px solid var(--border-color);margin-bottom:10px;border-radius:6px}.search-box input{border:0;z-index:5;color:var(--font-color-2);font-size:14px;height:34px;padding:5px 5px 5px 43px;background:var(--color-white);border-radius:2px;width:71%}.search-box input::placeholder{color:var(--font-color-2);opacity:1;font-size:16px}.search-box input:focus-visible{outline:none}.search-box svg{position:absolute;left:20px;top:9px;color:var(--font-color-2);z-index:6;height:30px;width:12px}\n"] }]
        }], propDecorators: { menuItems: [{
                type: Input
            }], hideSearch: [{
                type: Input
            }], selectedId: [{
                type: Input
            }], currentSelected: [{
                type: Output
            }], footerClicked: [{
                type: Output
            }] } });

/**
 * Component: FfDropMenuRadioComponent
 * Description: Represents a dropdown menu with radio buttons.
 * Allows users to select a single option from a list of items.
 * Provides search functionality to filter options and a "Clear selection" button.
 *
 * Usage:
 * <app-ff-drop-menu-radio
 *   [menuItems]="items"
 *   [hideSearch]="false"
 *   [selectedId]="selectedItemId"
 *   (currentSelected)="handleItemSelected($event)"
 *   (footerClicked)="handleFooterClick($event)"
 * ></app-ff-drop-menu-radio>
 */

class FfDropMenuCheckboxComponent {
    constructor() {
        /**
         * Output: footerClicked
         * Description: Event emitted when the "Clear selection" footer is clicked.
         */
        this.footerClicked = new EventEmitter();
        /**
         * Output: currentSelected
         * Description: Event emitted when an item is selected or deselected.
         * The selected item object is emitted as the event payload.
         */
        this.currentSelected = new EventEmitter();
    }
    /**
     * Method: multipleSelection
     * Description: Called when an item is selected or deselected.
     * Emits the 'currentSelected' event with the selected item as the payload.
     * @param row - The selected item object.
     */
    multipleSelection(row) {
        this.currentSelected.emit(row);
    }
    /**
     * Method: clearSelection
     * Description: Called when the "Clear selection" footer is clicked.
     * Emits the 'footerClicked' event.
     */
    clearSelection() {
        this.footerClicked.emit(true);
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "16.2.12", ngImport: i0, type: FfDropMenuCheckboxComponent, deps: [], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "16.2.12", type: FfDropMenuCheckboxComponent, isStandalone: true, selector: "app-ff-drop-menu-checkbox", inputs: { menuItems: "menuItems", hideSearch: "hideSearch", selectedItems: "selectedItems" }, outputs: { footerClicked: "footerClicked", currentSelected: "currentSelected" }, ngImport: i0, template: "<div class=\"menu-wrapper flex-column\">\r\n    <section class=\"search-box\" *ngIf=\"!hideSearch\">\r\n        <input type=\"text\" placeholder=\"Search\" class=\"search-item\" [(ngModel)]=\"searchString\"\r\n            [ngModelOptions]=\"{standalone: true}\" autocomplete=\"off\" autofocus id=\"searchMultiple\">\r\n        <svg width=\"11\" height=\"14\" viewBox=\"0 0 11 14\" fill=\"none\" xmlns=\"http://www.w3.org/2000/svg\">\r\n            <circle cx=\"5\" cy=\"5\" r=\"4.5\" stroke=\"#5691AE\" />\r\n            <line y1=\"-1\" x2=\"4.46301\" y2=\"-1\" transform=\"matrix(0.552178 0.833726 -0.878595 0.477568 6.49231 9.39453)\"\r\n                stroke=\"#5691AE\" stroke-width=\"2\" />\r\n        </svg>\r\n    </section>\r\n    <ul class=\"menu-list-items\" [ngClass]=\"hideSearch?'auto-height':'minimum-height'\">\r\n        <li *ngFor=\"let item of menuItems | searchOptions:searchString\">\r\n            <mat-checkbox [checked]=\"selectedItems.includes(item?.id)\" (change)=\"multipleSelection(item)\"\r\n                [disabled]=\"item.disabled\" id=\"select{{item.id}}\">\r\n                {{item.name}}\r\n            </mat-checkbox>\r\n        </li>\r\n        <li *ngIf=\"(menuItems | searchOptions: searchString)?.length === 0\" id=\"noResults\">\r\n            No results found\r\n        </li>\r\n    </ul>\r\n    <section class=\"footer-box ff-flex-center\" (click)=\"clearSelection()\" id=\"clearSelection\">\r\n        Clear selection\r\n    </section>\r\n</div>", styles: [".menu-list-items{list-style:none;overflow:auto;padding:0 0 10px 10px;margin:0}.menu-list-items::-webkit-scrollbar{width:10px;height:8px}.menu-list-items::-webkit-scrollbar-track{border-radius:2px}.menu-list-items::-webkit-scrollbar-thumb{border-radius:3px;background-color:var(--color-scrollbar)}.menu-list-items.minimum-height{height:150px}.menu-list-items.auto-height{height:auto}.menu-list-items li{padding:8px 0;font-size:14px;color:var(--font-color);font-family:var(--font-medium)}.menu-list-items li ::ng-deep label{display:block;text-overflow:ellipsis;overflow:hidden;white-space:nowrap;width:160px}.menu-wrapper{box-sizing:border-box}.menu-wrapper .search-box,.menu-wrapper .footer-box{min-height:34px}.footer-box{text-transform:capitalize;font-size:14px;font-family:var(--font-bold);cursor:pointer;padding:5px 30px;border-top:1px solid var(--border-color);color:var(--color-secondary)}.search-box{position:relative;padding-left:5px;border:1px solid #f9fafb;border-radius:6px;margin:0 10px}.search-box.mobile-input{border:1px solid var(--border-color);margin-bottom:10px;border-radius:6px}.search-box input{border:0;z-index:5;color:var(--font-color-2);font-size:14px;height:34px;padding:5px 5px 5px 43px;background:var(--color-white);border-radius:2px;width:71%}.search-box input::placeholder{color:var(--font-color-2);opacity:1;font-size:16px}.search-box input:focus-visible{outline:none}.search-box svg{position:absolute;left:20px;top:9px;color:var(--font-color-2);z-index:6;height:30px;width:12px}\n"], dependencies: [{ kind: "ngmodule", type: CommonModule }, { kind: "directive", type: i1.NgClass, selector: "[ngClass]", inputs: ["class", "ngClass"] }, { kind: "directive", type: i1.NgForOf, selector: "[ngFor][ngForOf]", inputs: ["ngForOf", "ngForTrackBy", "ngForTemplate"] }, { kind: "directive", type: i1.NgIf, selector: "[ngIf]", inputs: ["ngIf", "ngIfThen", "ngIfElse"] }, { kind: "ngmodule", type: MatCheckboxModule }, { kind: "component", type: i2$2.MatCheckbox, selector: "mat-checkbox", inputs: ["disableRipple", "color", "tabIndex"], exportAs: ["matCheckbox"] }, { kind: "ngmodule", type: FormsModule }, { kind: "directive", type: i2$1.DefaultValueAccessor, selector: "input:not([type=checkbox])[formControlName],textarea[formControlName],input:not([type=checkbox])[formControl],textarea[formControl],input:not([type=checkbox])[ngModel],textarea[ngModel],[ngDefaultControl]" }, { kind: "directive", type: i2$1.NgControlStatus, selector: "[formControlName],[ngModel],[formControl]" }, { kind: "directive", type: i2$1.NgModel, selector: "[ngModel]:not([formControlName]):not([formControl])", inputs: ["name", "disabled", "ngModel", "ngModelOptions"], outputs: ["ngModelChange"], exportAs: ["ngModel"] }, { kind: "pipe", type: FilterDropdownPipe, name: "searchOptions" }] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "16.2.12", ngImport: i0, type: FfDropMenuCheckboxComponent, decorators: [{
            type: Component,
            args: [{ selector: 'app-ff-drop-menu-checkbox', standalone: true, imports: [CommonModule, MatCheckboxModule, FormsModule, FilterDropdownPipe], template: "<div class=\"menu-wrapper flex-column\">\r\n    <section class=\"search-box\" *ngIf=\"!hideSearch\">\r\n        <input type=\"text\" placeholder=\"Search\" class=\"search-item\" [(ngModel)]=\"searchString\"\r\n            [ngModelOptions]=\"{standalone: true}\" autocomplete=\"off\" autofocus id=\"searchMultiple\">\r\n        <svg width=\"11\" height=\"14\" viewBox=\"0 0 11 14\" fill=\"none\" xmlns=\"http://www.w3.org/2000/svg\">\r\n            <circle cx=\"5\" cy=\"5\" r=\"4.5\" stroke=\"#5691AE\" />\r\n            <line y1=\"-1\" x2=\"4.46301\" y2=\"-1\" transform=\"matrix(0.552178 0.833726 -0.878595 0.477568 6.49231 9.39453)\"\r\n                stroke=\"#5691AE\" stroke-width=\"2\" />\r\n        </svg>\r\n    </section>\r\n    <ul class=\"menu-list-items\" [ngClass]=\"hideSearch?'auto-height':'minimum-height'\">\r\n        <li *ngFor=\"let item of menuItems | searchOptions:searchString\">\r\n            <mat-checkbox [checked]=\"selectedItems.includes(item?.id)\" (change)=\"multipleSelection(item)\"\r\n                [disabled]=\"item.disabled\" id=\"select{{item.id}}\">\r\n                {{item.name}}\r\n            </mat-checkbox>\r\n        </li>\r\n        <li *ngIf=\"(menuItems | searchOptions: searchString)?.length === 0\" id=\"noResults\">\r\n            No results found\r\n        </li>\r\n    </ul>\r\n    <section class=\"footer-box ff-flex-center\" (click)=\"clearSelection()\" id=\"clearSelection\">\r\n        Clear selection\r\n    </section>\r\n</div>", styles: [".menu-list-items{list-style:none;overflow:auto;padding:0 0 10px 10px;margin:0}.menu-list-items::-webkit-scrollbar{width:10px;height:8px}.menu-list-items::-webkit-scrollbar-track{border-radius:2px}.menu-list-items::-webkit-scrollbar-thumb{border-radius:3px;background-color:var(--color-scrollbar)}.menu-list-items.minimum-height{height:150px}.menu-list-items.auto-height{height:auto}.menu-list-items li{padding:8px 0;font-size:14px;color:var(--font-color);font-family:var(--font-medium)}.menu-list-items li ::ng-deep label{display:block;text-overflow:ellipsis;overflow:hidden;white-space:nowrap;width:160px}.menu-wrapper{box-sizing:border-box}.menu-wrapper .search-box,.menu-wrapper .footer-box{min-height:34px}.footer-box{text-transform:capitalize;font-size:14px;font-family:var(--font-bold);cursor:pointer;padding:5px 30px;border-top:1px solid var(--border-color);color:var(--color-secondary)}.search-box{position:relative;padding-left:5px;border:1px solid #f9fafb;border-radius:6px;margin:0 10px}.search-box.mobile-input{border:1px solid var(--border-color);margin-bottom:10px;border-radius:6px}.search-box input{border:0;z-index:5;color:var(--font-color-2);font-size:14px;height:34px;padding:5px 5px 5px 43px;background:var(--color-white);border-radius:2px;width:71%}.search-box input::placeholder{color:var(--font-color-2);opacity:1;font-size:16px}.search-box input:focus-visible{outline:none}.search-box svg{position:absolute;left:20px;top:9px;color:var(--font-color-2);z-index:6;height:30px;width:12px}\n"] }]
        }], propDecorators: { menuItems: [{
                type: Input
            }], hideSearch: [{
                type: Input
            }], selectedItems: [{
                type: Input
            }], footerClicked: [{
                type: Output
            }], currentSelected: [{
                type: Output
            }] } });

/**
 * Component: FfDropMenuCheckboxComponent
 * Description: Represents a dropdown menu with checkboxes.
 * Allows users to select multiple options from a list of items.
 * Provides search functionality to filter options and a "Clear selection" button.
 *
 * Usage:
 * <app-ff-drop-menu-checkbox
 *   [menuItems]="items"
 *   [hideSearch]="false"
 *   [selectedItems]="selectedItemIds"
 *   (footerClicked)="handleFooterClick($event)"
 *   (currentSelected)="handleItemSelected($event)"
 * ></app-ff-drop-menu-checkbox>
 */

/* eslint-disable @typescript-eslint/no-explicit-any */
class FfFilterBoxWrapperComponent {
    constructor() {
        this.multiple = false;
        this.selectionChange = new EventEmitter();
        this.selectedItem = {
            id: 'All',
            name: 'Select',
            state: 'default',
        };
    }
    /**
     * ngOnChanges
     *
     * Lifecycle hook that gets called whenever the input properties change.
     * Handles setting the default selected item based on defaultValue input.
     *
     * @param changes - The changes object containing the changed properties.
     * @returns void
     */
    ngOnChanges(changes) {
        const { defaultValue } = changes;
        if (defaultValue?.currentValue) {
            const found = this.filterMasterData.find((a) => a.id === defaultValue.currentValue);
            if (found) {
                this.selectedItem = found;
                this.selectedItem.state = 'selected';
            }
            else {
                this.selectedItem = {
                    id: 'All',
                    name: 'Select',
                    state: 'default',
                };
            }
        }
        //  else {
        //   this.selectedItem = {
        //     id: 'All',
        //     name: 'Select',
        //     state: 'default',
        //   };
        // }
    }
    /**
     * closeMenu
     *
     * Closes the dropdown menu by triggering the closeMenu() method of MatMenuTrigger.
     *
     * @returns void
     */
    closeMenu() {
        this.dropdownMenuTrigger.closeMenu();
    }
    /**
     * selectionChanged
     *
     * Handles the selection change event from the dropdown menu.
     * Emits the selected item and updates the selectedItem property.
     *
     * @param data - The selected item data.
     * @returns void
     */
    selectionChanged(data) {
        this.selectedItem = data;
        this.selectedItem.state = 'selected';
        this.selectionChange.emit(data);
        this.closeMenu();
    }
    /**
     * footerClicked
     *
     * Handles the click event on the "Clear selection" footer in the dropdown menu.
     * Emits a default selected item and updates the selectedItem property.
     *
     * @returns void
     */
    footerClicked() {
        this.selectedItem = {
            id: 'All',
            name: 'Select',
            state: 'default',
        };
        this.selectionChange.emit(this.selectedItem);
        this.closeMenu();
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "16.2.12", ngImport: i0, type: FfFilterBoxWrapperComponent, deps: [], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "16.2.12", type: FfFilterBoxWrapperComponent, isStandalone: true, selector: "app-ff-filter-box-wrapper", inputs: { filterMasterData: "filterMasterData", multiple: "multiple", label: "label", defaultValue: "defaultValue", hideSearch: "hideSearch", hideFooter: "hideFooter", customId: "customId" }, outputs: { selectionChange: "selectionChange" }, viewQueries: [{ propertyName: "dropdownMenuTrigger", first: true, predicate: ["dropdownMenuTrigger"], descendants: true }], usesOnChanges: true, ngImport: i0, template: "<app-ff-filter-box [label]=\"label\" [value]=\"selectedItem?.name\" [boxState]=\"selectedItem?.state\" [customId]=\"customId\"\r\n    [matMenuTriggerFor]=\"filterMenu\" #dropdownMenuTrigger=\"matMenuTrigger\"></app-ff-filter-box>\r\n\r\n<mat-menu #filterMenu=\"matMenu\" class=\"mat-menu filter-box\">\r\n    <ng-container *ngIf=\"multiple; else singleSelection\">\r\n        <app-ff-drop-menu-checkbox [menuItems]=\"filterMasterData\"\r\n            (click)=\"$event.stopPropagation();\"></app-ff-drop-menu-checkbox>\r\n    </ng-container>\r\n    <ng-template #singleSelection>\r\n        <app-ff-drop-menu-radio [menuItems]=\"filterMasterData\" (click)=\"$event.stopPropagation();\"\r\n            [hideSearch]=\"hideSearch\" [selectedId]=\"defaultValue || selectedItem?.id\"\r\n            (currentSelected)=\"selectionChanged($event)\" (footerClicked)=\"footerClicked()\"></app-ff-drop-menu-radio>\r\n    </ng-template>\r\n</mat-menu>", styles: ["::ng-deep .filter-box .mat-mdc-menu-content{width:230px}\n"], dependencies: [{ kind: "ngmodule", type: CommonModule }, { kind: "directive", type: i1.NgIf, selector: "[ngIf]", inputs: ["ngIf", "ngIfThen", "ngIfElse"] }, { kind: "ngmodule", type: MatMenuModule }, { kind: "component", type: i1$2.MatMenu, selector: "mat-menu", exportAs: ["matMenu"] }, { kind: "directive", type: i1$2.MatMenuTrigger, selector: "[mat-menu-trigger-for], [matMenuTriggerFor]", exportAs: ["matMenuTrigger"] }, { kind: "component", type: FfFilterBoxComponent, selector: "app-ff-filter-box", inputs: ["label", "value", "boxState", "showRedBorder", "tooltipText", "customId"], outputs: ["boxClicked"] }, { kind: "component", type: FfDropMenuRadioComponent, selector: "app-ff-drop-menu-radio", inputs: ["menuItems", "hideSearch", "selectedId"], outputs: ["currentSelected", "footerClicked"] }, { kind: "component", type: FfDropMenuCheckboxComponent, selector: "app-ff-drop-menu-checkbox", inputs: ["menuItems", "hideSearch", "selectedItems"], outputs: ["footerClicked", "currentSelected"] }], changeDetection: i0.ChangeDetectionStrategy.OnPush }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "16.2.12", ngImport: i0, type: FfFilterBoxWrapperComponent, decorators: [{
            type: Component,
            args: [{ selector: 'app-ff-filter-box-wrapper', standalone: true, imports: [
                        CommonModule,
                        MatMenuModule,
                        FfFilterBoxComponent,
                        FfDropMenuRadioComponent,
                        FfDropMenuCheckboxComponent,
                    ], changeDetection: ChangeDetectionStrategy.OnPush, template: "<app-ff-filter-box [label]=\"label\" [value]=\"selectedItem?.name\" [boxState]=\"selectedItem?.state\" [customId]=\"customId\"\r\n    [matMenuTriggerFor]=\"filterMenu\" #dropdownMenuTrigger=\"matMenuTrigger\"></app-ff-filter-box>\r\n\r\n<mat-menu #filterMenu=\"matMenu\" class=\"mat-menu filter-box\">\r\n    <ng-container *ngIf=\"multiple; else singleSelection\">\r\n        <app-ff-drop-menu-checkbox [menuItems]=\"filterMasterData\"\r\n            (click)=\"$event.stopPropagation();\"></app-ff-drop-menu-checkbox>\r\n    </ng-container>\r\n    <ng-template #singleSelection>\r\n        <app-ff-drop-menu-radio [menuItems]=\"filterMasterData\" (click)=\"$event.stopPropagation();\"\r\n            [hideSearch]=\"hideSearch\" [selectedId]=\"defaultValue || selectedItem?.id\"\r\n            (currentSelected)=\"selectionChanged($event)\" (footerClicked)=\"footerClicked()\"></app-ff-drop-menu-radio>\r\n    </ng-template>\r\n</mat-menu>", styles: ["::ng-deep .filter-box .mat-mdc-menu-content{width:230px}\n"] }]
        }], propDecorators: { dropdownMenuTrigger: [{
                type: ViewChild,
                args: ['dropdownMenuTrigger']
            }], filterMasterData: [{
                type: Input
            }], multiple: [{
                type: Input
            }], label: [{
                type: Input
            }], defaultValue: [{
                type: Input
            }], hideSearch: [{
                type: Input
            }], hideFooter: [{
                type: Input
            }], customId: [{
                type: Input
            }], selectionChange: [{
                type: Output
            }] } });

/* eslint-disable @typescript-eslint/no-explicit-any */
class FairFoodInputComponent {
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "16.2.12", ngImport: i0, type: FairFoodInputComponent, deps: [], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "16.2.12", type: FairFoodInputComponent, isStandalone: true, selector: "app-ff-input", inputs: { parentFormGroup: "parentFormGroup", controlName: "controlName", label: "label", inputSize: "inputSize", inputType: "inputType", isTextarea: "isTextarea" }, ngImport: i0, template: "<ng-container *ngIf=\"isTextarea;else normalInput\" [formGroup]=\"parentFormGroup\">\r\n    <label class=\"has-float-label\">\r\n        <textarea rows=\"4\" cols=\"30\" [formControlName]=\"controlName\" id=\"{{controlName}}textarea\"></textarea>\r\n        <span class=\"label textarea-label\">{{label}}</span>\r\n    </label>\r\n\r\n</ng-container>\r\n\r\n<ng-template #normalInput>\r\n    <ng-container [formGroup]=\"parentFormGroup\">\r\n        <label class=\"has-float-label\"\r\n            [ngClass]=\"{'has-error': parentFormGroup.controls[controlName].invalid && parentFormGroup.controls[controlName].touched }\">\r\n            <input placeholder=\" \" type=\"{{inputType}}\" [formControlName]=\"controlName\" class=\"{{inputSize}}\"\r\n                id=\"{{controlName}}-input\" />\r\n            <span class=\"label\">{{label}}</span>\r\n        </label>\r\n    </ng-container>\r\n</ng-template>", styles: [".has-float-label{display:flex;position:relative;margin:0;width:100%;background-color:var(--color-white)}.has-float-label.has-error{border:1px solid var(--color-secondary);border-radius:6px}.has-float-label.bulk{width:90%}.has-float-label.bulk input{padding-top:10px!important}.has-float-label.bulk mat-icon{top:9px;right:11px!important}.has-float-label mat-icon{position:absolute;right:5px;color:var(--font-color);top:16px}.has-float-label mat-icon.profile{right:30px}.has-float-label textarea{width:100%;resize:none}.has-float-label input,.has-float-label textarea{font-size:inherit;font-family:var(--font-medium);padding:20px 15px 10px 20px;border-radius:6px;box-shadow:none;background-color:initial;color:var(--font-color);border:1px solid var(--border-color);margin:0;outline:none;cursor:pointer}.has-float-label input.full,.has-float-label textarea.full,.has-float-label input.profile,.has-float-label textarea.profile{width:100%}.has-float-label input.profile mat-icon,.has-float-label textarea.profile mat-icon{right:10px}.has-float-label input.stock,.has-float-label textarea.stock{width:97%}.has-float-label input.date-picker,.has-float-label textarea.date-picker{width:94%}.has-float-label input.small,.has-float-label textarea.small{width:120px}.has-float-label input.medium,.has-float-label textarea.medium{width:154px}.has-float-label input.pt-0,.has-float-label textarea.pt-0{padding-top:0}.has-float-label input:placeholder-shown:not(:focus)+.label,.has-float-label textarea:placeholder-shown:not(:focus)+.label{font-size:14px;top:17px;left:20px;color:var(--font-color-2)}.has-float-label label,.has-float-label>.label{position:absolute;left:20px;top:8px;cursor:text;font-size:11px;color:var(--font-color-2);font-family:var(--font-regular);transition:all .2s;pointer-events:none}.has-float-label input:focus~.label,.has-float-label textarea:focus~.label{color:var(--font-color-2)}.textarea-label{background-color:var(--color-white);width:87%;left:2px!important;top:2px!important;padding-left:17px;border-radius:6px;padding-top:6px;font-family:var(--font-regular)}\n"], dependencies: [{ kind: "ngmodule", type: CommonModule }, { kind: "directive", type: i1.NgClass, selector: "[ngClass]", inputs: ["class", "ngClass"] }, { kind: "directive", type: i1.NgIf, selector: "[ngIf]", inputs: ["ngIf", "ngIfThen", "ngIfElse"] }, { kind: "ngmodule", type: FormsModule }, { kind: "directive", type: i2$1.DefaultValueAccessor, selector: "input:not([type=checkbox])[formControlName],textarea[formControlName],input:not([type=checkbox])[formControl],textarea[formControl],input:not([type=checkbox])[ngModel],textarea[ngModel],[ngDefaultControl]" }, { kind: "directive", type: i2$1.NgControlStatus, selector: "[formControlName],[ngModel],[formControl]" }, { kind: "directive", type: i2$1.NgControlStatusGroup, selector: "[formGroupName],[formArrayName],[ngModelGroup],[formGroup],form:not([ngNoForm]),[ngForm]" }, { kind: "ngmodule", type: ReactiveFormsModule }, { kind: "directive", type: i2$1.FormGroupDirective, selector: "[formGroup]", inputs: ["formGroup"], outputs: ["ngSubmit"], exportAs: ["ngForm"] }, { kind: "directive", type: i2$1.FormControlName, selector: "[formControlName]", inputs: ["formControlName", "disabled", "ngModel"], outputs: ["ngModelChange"] }] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "16.2.12", ngImport: i0, type: FairFoodInputComponent, decorators: [{
            type: Component,
            args: [{ selector: 'app-ff-input', standalone: true, imports: [CommonModule, FormsModule, ReactiveFormsModule], template: "<ng-container *ngIf=\"isTextarea;else normalInput\" [formGroup]=\"parentFormGroup\">\r\n    <label class=\"has-float-label\">\r\n        <textarea rows=\"4\" cols=\"30\" [formControlName]=\"controlName\" id=\"{{controlName}}textarea\"></textarea>\r\n        <span class=\"label textarea-label\">{{label}}</span>\r\n    </label>\r\n\r\n</ng-container>\r\n\r\n<ng-template #normalInput>\r\n    <ng-container [formGroup]=\"parentFormGroup\">\r\n        <label class=\"has-float-label\"\r\n            [ngClass]=\"{'has-error': parentFormGroup.controls[controlName].invalid && parentFormGroup.controls[controlName].touched }\">\r\n            <input placeholder=\" \" type=\"{{inputType}}\" [formControlName]=\"controlName\" class=\"{{inputSize}}\"\r\n                id=\"{{controlName}}-input\" />\r\n            <span class=\"label\">{{label}}</span>\r\n        </label>\r\n    </ng-container>\r\n</ng-template>", styles: [".has-float-label{display:flex;position:relative;margin:0;width:100%;background-color:var(--color-white)}.has-float-label.has-error{border:1px solid var(--color-secondary);border-radius:6px}.has-float-label.bulk{width:90%}.has-float-label.bulk input{padding-top:10px!important}.has-float-label.bulk mat-icon{top:9px;right:11px!important}.has-float-label mat-icon{position:absolute;right:5px;color:var(--font-color);top:16px}.has-float-label mat-icon.profile{right:30px}.has-float-label textarea{width:100%;resize:none}.has-float-label input,.has-float-label textarea{font-size:inherit;font-family:var(--font-medium);padding:20px 15px 10px 20px;border-radius:6px;box-shadow:none;background-color:initial;color:var(--font-color);border:1px solid var(--border-color);margin:0;outline:none;cursor:pointer}.has-float-label input.full,.has-float-label textarea.full,.has-float-label input.profile,.has-float-label textarea.profile{width:100%}.has-float-label input.profile mat-icon,.has-float-label textarea.profile mat-icon{right:10px}.has-float-label input.stock,.has-float-label textarea.stock{width:97%}.has-float-label input.date-picker,.has-float-label textarea.date-picker{width:94%}.has-float-label input.small,.has-float-label textarea.small{width:120px}.has-float-label input.medium,.has-float-label textarea.medium{width:154px}.has-float-label input.pt-0,.has-float-label textarea.pt-0{padding-top:0}.has-float-label input:placeholder-shown:not(:focus)+.label,.has-float-label textarea:placeholder-shown:not(:focus)+.label{font-size:14px;top:17px;left:20px;color:var(--font-color-2)}.has-float-label label,.has-float-label>.label{position:absolute;left:20px;top:8px;cursor:text;font-size:11px;color:var(--font-color-2);font-family:var(--font-regular);transition:all .2s;pointer-events:none}.has-float-label input:focus~.label,.has-float-label textarea:focus~.label{color:var(--font-color-2)}.textarea-label{background-color:var(--color-white);width:87%;left:2px!important;top:2px!important;padding-left:17px;border-radius:6px;padding-top:6px;font-family:var(--font-regular)}\n"] }]
        }], propDecorators: { parentFormGroup: [{
                type: Input
            }], controlName: [{
                type: Input
            }], label: [{
                type: Input
            }], inputSize: [{
                type: Input
            }], inputType: [{
                type: Input
            }], isTextarea: [{
                type: Input
            }] } });

class FfDropdownBoxComponent {
    constructor() {
        this.boxState = 'default';
        this.labelClass = false;
        this.boxClicked = new EventEmitter();
    }
    /**
     * itemClicked
     *
     * Handles the click event on the dropdown box and emits the boxClicked event.
     *
     * @returns void
     */
    itemClicked() {
        this.boxClicked.emit(true);
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "16.2.12", ngImport: i0, type: FfDropdownBoxComponent, deps: [], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "16.2.12", type: FfDropdownBoxComponent, isStandalone: true, selector: "app-ff-dropdown-box", inputs: { label: "label", value: "value", customId: "customId", boxState: "boxState", inputClass: "inputClass", showError: "showError", labelClass: "labelClass" }, outputs: { boxClicked: "boxClicked" }, ngImport: i0, template: "<label class=\"has-float-label pointer\" role=\"button\" [ngClass]=\"{'has-error': showError, 'bulk': labelClass }\"\r\n    id=\"dropdownBox-{{customId}}\">\r\n    <input placeholder=\" \" type=\"text\" class=\"{{inputClass}}\" readonly [value]=\"value\" aria-haspopup=\"listbox\"\r\n        aria-expanded=\"false\" id=\"dropdownInput-{{customId}}\" />\r\n    <span class=\"label\">{{label}}</span>\r\n    <mat-icon class=\"{{inputClass}}\" (click)=\"$event.stopPropagation();\" role=\"button\"\r\n        aria-label=\"Open Dropdown\">keyboard_arrow_down</mat-icon>\r\n</label>", styles: [".has-float-label{display:flex;position:relative;margin:0;width:100%;background-color:var(--color-white)}.has-float-label.has-error{border:1px solid var(--color-secondary);border-radius:6px}.has-float-label.bulk{width:90%}.has-float-label.bulk input{padding-top:10px!important}.has-float-label.bulk mat-icon{top:9px;right:11px!important}.has-float-label mat-icon{position:absolute;right:5px;color:var(--font-color);top:16px}.has-float-label mat-icon.profile{right:30px}.has-float-label textarea{width:100%;resize:none}.has-float-label input,.has-float-label textarea{font-size:inherit;font-family:var(--font-medium);padding:20px 15px 10px 20px;border-radius:6px;box-shadow:none;background-color:initial;color:var(--font-color);border:1px solid var(--border-color);margin:0;outline:none;cursor:pointer}.has-float-label input.full,.has-float-label textarea.full,.has-float-label input.profile,.has-float-label textarea.profile{width:100%}.has-float-label input.profile mat-icon,.has-float-label textarea.profile mat-icon{right:10px}.has-float-label input.stock,.has-float-label textarea.stock{width:97%}.has-float-label input.date-picker,.has-float-label textarea.date-picker{width:94%}.has-float-label input.small,.has-float-label textarea.small{width:120px}.has-float-label input.medium,.has-float-label textarea.medium{width:154px}.has-float-label input.pt-0,.has-float-label textarea.pt-0{padding-top:0}.has-float-label input:placeholder-shown:not(:focus)+.label,.has-float-label textarea:placeholder-shown:not(:focus)+.label{font-size:14px;top:17px;left:20px;color:var(--font-color-2)}.has-float-label label,.has-float-label>.label{position:absolute;left:20px;top:8px;cursor:text;font-size:11px;color:var(--font-color-2);font-family:var(--font-regular);transition:all .2s;pointer-events:none}.has-float-label input:focus~.label,.has-float-label textarea:focus~.label{color:var(--font-color-2)}\n"], dependencies: [{ kind: "directive", type: NgClass, selector: "[ngClass]", inputs: ["class", "ngClass"] }, { kind: "ngmodule", type: MatIconModule }, { kind: "component", type: i2.MatIcon, selector: "mat-icon", inputs: ["color", "inline", "svgIcon", "fontSet", "fontIcon"], exportAs: ["matIcon"] }] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "16.2.12", ngImport: i0, type: FfDropdownBoxComponent, decorators: [{
            type: Component,
            args: [{ selector: 'app-ff-dropdown-box', standalone: true, imports: [NgClass, MatIconModule], template: "<label class=\"has-float-label pointer\" role=\"button\" [ngClass]=\"{'has-error': showError, 'bulk': labelClass }\"\r\n    id=\"dropdownBox-{{customId}}\">\r\n    <input placeholder=\" \" type=\"text\" class=\"{{inputClass}}\" readonly [value]=\"value\" aria-haspopup=\"listbox\"\r\n        aria-expanded=\"false\" id=\"dropdownInput-{{customId}}\" />\r\n    <span class=\"label\">{{label}}</span>\r\n    <mat-icon class=\"{{inputClass}}\" (click)=\"$event.stopPropagation();\" role=\"button\"\r\n        aria-label=\"Open Dropdown\">keyboard_arrow_down</mat-icon>\r\n</label>", styles: [".has-float-label{display:flex;position:relative;margin:0;width:100%;background-color:var(--color-white)}.has-float-label.has-error{border:1px solid var(--color-secondary);border-radius:6px}.has-float-label.bulk{width:90%}.has-float-label.bulk input{padding-top:10px!important}.has-float-label.bulk mat-icon{top:9px;right:11px!important}.has-float-label mat-icon{position:absolute;right:5px;color:var(--font-color);top:16px}.has-float-label mat-icon.profile{right:30px}.has-float-label textarea{width:100%;resize:none}.has-float-label input,.has-float-label textarea{font-size:inherit;font-family:var(--font-medium);padding:20px 15px 10px 20px;border-radius:6px;box-shadow:none;background-color:initial;color:var(--font-color);border:1px solid var(--border-color);margin:0;outline:none;cursor:pointer}.has-float-label input.full,.has-float-label textarea.full,.has-float-label input.profile,.has-float-label textarea.profile{width:100%}.has-float-label input.profile mat-icon,.has-float-label textarea.profile mat-icon{right:10px}.has-float-label input.stock,.has-float-label textarea.stock{width:97%}.has-float-label input.date-picker,.has-float-label textarea.date-picker{width:94%}.has-float-label input.small,.has-float-label textarea.small{width:120px}.has-float-label input.medium,.has-float-label textarea.medium{width:154px}.has-float-label input.pt-0,.has-float-label textarea.pt-0{padding-top:0}.has-float-label input:placeholder-shown:not(:focus)+.label,.has-float-label textarea:placeholder-shown:not(:focus)+.label{font-size:14px;top:17px;left:20px;color:var(--font-color-2)}.has-float-label label,.has-float-label>.label{position:absolute;left:20px;top:8px;cursor:text;font-size:11px;color:var(--font-color-2);font-family:var(--font-regular);transition:all .2s;pointer-events:none}.has-float-label input:focus~.label,.has-float-label textarea:focus~.label{color:var(--font-color-2)}\n"] }]
        }], propDecorators: { label: [{
                type: Input
            }], value: [{
                type: Input
            }], customId: [{
                type: Input
            }], boxState: [{
                type: Input
            }], inputClass: [{
                type: Input
            }], showError: [{
                type: Input
            }], labelClass: [{
                type: Input
            }], boxClicked: [{
                type: Output
            }] } });

/**
 * FfDropdownBoxComponent
 *
 * This component represents the box portion of the dropdown menu.
 * It displays the selected value and label.
 *
 * Usage:
 * <app-ff-dropdown-box></app-ff-dropdown-box>
 *
 * Selector: app-ff-dropdown-box
 *
 * @Input:
 *   - label: string - The label text for the dropdown box.
 *   - value: string - The value to display in the dropdown box.
 *   - boxState: 'default' | 'selected' - The state of the dropdown box. 'default' represents the initial state, and 'selected' represents a selected state.
 *
 * @Output:
 *   - boxClicked: EventEmitter<boolean> - Event emitted when the dropdown box is clicked. It emits a boolean value indicating whether the box was clicked.
 *
 * Dependencies:
 *   - CommonModule from '@angular/common'
 *   - MatIconModule from '@angular/material/icon'
 *
 * Example:
 * <app-ff-dropdown-box></app-ff-dropdown-box>
 */

class FfDropdownSelectComponent {
    constructor() {
        this.currentSelected = new EventEmitter();
        this.footerClicked = new EventEmitter();
    }
    /**
     * menuItemSelected
     *
     * Handles the selection of a menu item and emits the currentSelected event with the selected item.
     *
     * @param selected - The selected dropdown item.
     * @returns void
     */
    menuItemSelected(selected) {
        this.searchString = '';
        this.currentSelected.emit(selected);
    }
    /**
     * clearSelection
     *
     * Handles the click event on the clear selection footer and emits the footerClicked event.
     *
     * @returns void
     */
    clearSelection() {
        this.footerClicked.emit(true);
    }
    trackByFn(index) {
        return index;
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "16.2.12", ngImport: i0, type: FfDropdownSelectComponent, deps: [], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "16.2.12", type: FfDropdownSelectComponent, isStandalone: true, selector: "app-ff-dropdown-select", inputs: { menuItems: "menuItems", hideSearch: "hideSearch", selectedId: "selectedId", hideFooter: "hideFooter", clearButtonText: "clearButtonText" }, outputs: { currentSelected: "currentSelected", footerClicked: "footerClicked" }, ngImport: i0, template: "<div class=\"menu-wrapper flex-column\" id=\"dropdownSelectWrapper\">\r\n    <!-- Search box -->\r\n    <section class=\"search-box\" *ngIf=\"!hideSearch\">\r\n        <input type=\"text\" placeholder=\"Search\" class=\"search-item\" [(ngModel)]=\"searchString\"\r\n            [ngModelOptions]=\"{standalone: true}\" autocomplete=\"off\" autofocus id=\"dropdownSearch\">\r\n        <svg width=\"11\" height=\"14\" viewBox=\"0 0 11 14\" fill=\"none\" xmlns=\"http://www.w3.org/2000/svg\">\r\n            <circle cx=\"5\" cy=\"5\" r=\"4.5\" stroke=\"#5691AE\" />\r\n            <line y1=\"-1\" x2=\"4.46301\" y2=\"-1\" transform=\"matrix(0.552178 0.833726 -0.878595 0.477568 6.49231 9.39453)\"\r\n                stroke=\"#5691AE\" stroke-width=\"2\" />\r\n        </svg>\r\n    </section>\r\n    <ul class=\"menu-list-items\" [ngClass]=\"hideSearch?'auto-height':'minimum-height'\">\r\n        <!-- Menu items -->\r\n        <ng-container *ngFor=\"let item of menuItems | searchOptions:searchString; trackBy: trackByFn\">\r\n            <li class=\"pointer text-overflow\" *ngIf=\"!item.hideItem\" (click)=\"menuItemSelected(item)\"\r\n                [ngClass]=\"{'selected-option': item.id === selectedId}\" [id]=\"item.id | idSelection\">\r\n                {{ item.name }}\r\n            </li>\r\n        </ng-container>\r\n        <!-- No results message -->\r\n        <li *ngIf=\"(menuItems | searchOptions: searchString)?.length === 0\" id=\"noResult\">\r\n            No results found\r\n        </li>\r\n    </ul>\r\n    <!-- Clear selection footer -->\r\n    <section class=\"footer-box ff-flex-center\" (click)=\"clearSelection()\" *ngIf=\"!hideFooter\" id=\"clearSelection\">\r\n        {{clearButtonText ?? 'Clear selection'}}\r\n    </section>\r\n</div>", styles: [".menu-list-items{list-style:none;overflow:auto;padding:0 0 10px 10px;margin:0}.menu-list-items::-webkit-scrollbar{width:10px;height:8px}.menu-list-items::-webkit-scrollbar-track{border-radius:2px}.menu-list-items::-webkit-scrollbar-thumb{border-radius:3px;background-color:var(--color-scrollbar)}.menu-list-items.minimum-height{height:150px}.menu-list-items.auto-height{height:auto}.menu-list-items li{padding:8px 0;font-size:14px;color:var(--font-color);font-family:var(--font-medium)}.menu-list-items li ::ng-deep label{display:block;text-overflow:ellipsis;overflow:hidden;white-space:nowrap;width:160px}.menu-wrapper{box-sizing:border-box}.menu-wrapper .search-box,.menu-wrapper .footer-box{min-height:34px}.footer-box{text-transform:capitalize;font-size:14px;font-family:var(--font-bold);cursor:pointer;padding:5px 30px;border-top:1px solid var(--border-color);color:var(--color-secondary)}.search-box{position:relative;padding-left:5px;border:1px solid #f9fafb;border-radius:6px;margin:0 10px}.search-box.mobile-input{border:1px solid var(--border-color);margin-bottom:10px;border-radius:6px}.search-box input{border:0;z-index:5;color:var(--font-color-2);font-size:14px;height:34px;padding:5px 5px 5px 43px;background:var(--color-white);border-radius:2px;width:71%}.search-box input::placeholder{color:var(--font-color-2);opacity:1;font-size:16px}.search-box input:focus-visible{outline:none}.search-box svg{position:absolute;left:20px;top:9px;color:var(--font-color-2);z-index:6;height:30px;width:12px}.search-box{border:1px solid var(--border-color);margin-bottom:10px}.search-box input::placeholder{font-size:12px}.selected-option{font-family:var(--font-bold)}\n"], dependencies: [{ kind: "ngmodule", type: CommonModule }, { kind: "directive", type: i1.NgClass, selector: "[ngClass]", inputs: ["class", "ngClass"] }, { kind: "directive", type: i1.NgForOf, selector: "[ngFor][ngForOf]", inputs: ["ngForOf", "ngForTrackBy", "ngForTemplate"] }, { kind: "directive", type: i1.NgIf, selector: "[ngIf]", inputs: ["ngIf", "ngIfThen", "ngIfElse"] }, { kind: "ngmodule", type: FormsModule }, { kind: "directive", type: i2$1.DefaultValueAccessor, selector: "input:not([type=checkbox])[formControlName],textarea[formControlName],input:not([type=checkbox])[formControl],textarea[formControl],input:not([type=checkbox])[ngModel],textarea[ngModel],[ngDefaultControl]" }, { kind: "directive", type: i2$1.NgControlStatus, selector: "[formControlName],[ngModel],[formControl]" }, { kind: "directive", type: i2$1.NgModel, selector: "[ngModel]:not([formControlName]):not([formControl])", inputs: ["name", "disabled", "ngModel", "ngModelOptions"], outputs: ["ngModelChange"], exportAs: ["ngModel"] }, { kind: "pipe", type: FilterDropdownPipe, name: "searchOptions" }, { kind: "pipe", type: IdSelectionPipe, name: "idSelection" }] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "16.2.12", ngImport: i0, type: FfDropdownSelectComponent, decorators: [{
            type: Component,
            args: [{ selector: 'app-ff-dropdown-select', standalone: true, imports: [CommonModule, FormsModule, FilterDropdownPipe, IdSelectionPipe], template: "<div class=\"menu-wrapper flex-column\" id=\"dropdownSelectWrapper\">\r\n    <!-- Search box -->\r\n    <section class=\"search-box\" *ngIf=\"!hideSearch\">\r\n        <input type=\"text\" placeholder=\"Search\" class=\"search-item\" [(ngModel)]=\"searchString\"\r\n            [ngModelOptions]=\"{standalone: true}\" autocomplete=\"off\" autofocus id=\"dropdownSearch\">\r\n        <svg width=\"11\" height=\"14\" viewBox=\"0 0 11 14\" fill=\"none\" xmlns=\"http://www.w3.org/2000/svg\">\r\n            <circle cx=\"5\" cy=\"5\" r=\"4.5\" stroke=\"#5691AE\" />\r\n            <line y1=\"-1\" x2=\"4.46301\" y2=\"-1\" transform=\"matrix(0.552178 0.833726 -0.878595 0.477568 6.49231 9.39453)\"\r\n                stroke=\"#5691AE\" stroke-width=\"2\" />\r\n        </svg>\r\n    </section>\r\n    <ul class=\"menu-list-items\" [ngClass]=\"hideSearch?'auto-height':'minimum-height'\">\r\n        <!-- Menu items -->\r\n        <ng-container *ngFor=\"let item of menuItems | searchOptions:searchString; trackBy: trackByFn\">\r\n            <li class=\"pointer text-overflow\" *ngIf=\"!item.hideItem\" (click)=\"menuItemSelected(item)\"\r\n                [ngClass]=\"{'selected-option': item.id === selectedId}\" [id]=\"item.id | idSelection\">\r\n                {{ item.name }}\r\n            </li>\r\n        </ng-container>\r\n        <!-- No results message -->\r\n        <li *ngIf=\"(menuItems | searchOptions: searchString)?.length === 0\" id=\"noResult\">\r\n            No results found\r\n        </li>\r\n    </ul>\r\n    <!-- Clear selection footer -->\r\n    <section class=\"footer-box ff-flex-center\" (click)=\"clearSelection()\" *ngIf=\"!hideFooter\" id=\"clearSelection\">\r\n        {{clearButtonText ?? 'Clear selection'}}\r\n    </section>\r\n</div>", styles: [".menu-list-items{list-style:none;overflow:auto;padding:0 0 10px 10px;margin:0}.menu-list-items::-webkit-scrollbar{width:10px;height:8px}.menu-list-items::-webkit-scrollbar-track{border-radius:2px}.menu-list-items::-webkit-scrollbar-thumb{border-radius:3px;background-color:var(--color-scrollbar)}.menu-list-items.minimum-height{height:150px}.menu-list-items.auto-height{height:auto}.menu-list-items li{padding:8px 0;font-size:14px;color:var(--font-color);font-family:var(--font-medium)}.menu-list-items li ::ng-deep label{display:block;text-overflow:ellipsis;overflow:hidden;white-space:nowrap;width:160px}.menu-wrapper{box-sizing:border-box}.menu-wrapper .search-box,.menu-wrapper .footer-box{min-height:34px}.footer-box{text-transform:capitalize;font-size:14px;font-family:var(--font-bold);cursor:pointer;padding:5px 30px;border-top:1px solid var(--border-color);color:var(--color-secondary)}.search-box{position:relative;padding-left:5px;border:1px solid #f9fafb;border-radius:6px;margin:0 10px}.search-box.mobile-input{border:1px solid var(--border-color);margin-bottom:10px;border-radius:6px}.search-box input{border:0;z-index:5;color:var(--font-color-2);font-size:14px;height:34px;padding:5px 5px 5px 43px;background:var(--color-white);border-radius:2px;width:71%}.search-box input::placeholder{color:var(--font-color-2);opacity:1;font-size:16px}.search-box input:focus-visible{outline:none}.search-box svg{position:absolute;left:20px;top:9px;color:var(--font-color-2);z-index:6;height:30px;width:12px}.search-box{border:1px solid var(--border-color);margin-bottom:10px}.search-box input::placeholder{font-size:12px}.selected-option{font-family:var(--font-bold)}\n"] }]
        }], propDecorators: { menuItems: [{
                type: Input
            }], hideSearch: [{
                type: Input
            }], selectedId: [{
                type: Input
            }], hideFooter: [{
                type: Input
            }], clearButtonText: [{
                type: Input
            }], currentSelected: [{
                type: Output
            }], footerClicked: [{
                type: Output
            }] } });

/**
 * FfDropdownSelectComponent
 *
 * This component represents the dropdown menu for selecting options.
 *
 * Usage:
 * <app-ff-dropdown-select></app-ff-dropdown-select>
 *
 * Selector: app-ff-dropdown-select
 *
 * @Input:
 *   - menuItems: IDropdownItem[] - The list of dropdown menu items.
 *   - hideSearch: boolean - Determines whether to hide the search box.
 *   - selectedId: string | number - The ID of the currently selected item.
 *   - hideFooter: boolean - Determines whether to hide the clear selection footer.
 *
 * @Output:
 *   - currentSelected: EventEmitter<any> - Event emitted when an item is selected from the dropdown menu. It emits the selected item.
 *   - footerClicked: EventEmitter<boolean> - Event emitted when the clear selection footer is clicked. It emits a boolean value indicating the footer click event.
 *
 * Dependencies:
 *   - CommonModule from '@angular/common'
 *   - FormsModule from '@angular/forms'
 *   - FilterDropdownPipe (custom pipe) for filtering dropdown menu items based on search query
 *
 * Example:
 * <app-ff-dropdown-select></app-ff-dropdown-select>
 */

/* eslint-disable @typescript-eslint/no-explicit-any */
class FfDropdownComponent {
    constructor() {
        this.labelClass = false;
        this.selectionChange = new EventEmitter();
    }
    ngOnChanges(changes) {
        const { defaultValue, dropdownOptions, label } = changes;
        const optionToSearch = dropdownOptions?.currentValue || this.dropdownOptions;
        if (defaultValue && optionToSearch) {
            const found = optionToSearch.find((a) => a.id === defaultValue.currentValue);
            this.selectedItem = found;
        }
        if (label) {
            const { currentValue, firstChange } = label;
            if (currentValue && firstChange) {
                this.customId = currentValue.replace(/\s|\*/g, '').toLowerCase();
            }
        }
    }
    /**
     * handleOptionSelection
     *
     * Updates the selected item and emits the selectionChange event with the selected item as the payload.
     *
     * @param selectedOption - The selected dropdown item.
     * @returns void
     */
    handleOptionSelection(selectedOption) {
        this.selectedItem = selectedOption;
        this.selectionChange.emit(selectedOption);
        this.closeMenu();
    }
    /**
     * closeMenu
     *
     * Closes the dropdown menu.
     *
     * @returns void
     */
    closeMenu() {
        this.dropdownMenuTrigger.closeMenu();
    }
    clearDropdown(clear) {
        if (clear) {
            this.selectedItem = {};
            this.selectionChange.emit({
                id: 'All',
                name: '',
            });
            this.closeMenu();
        }
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "16.2.12", ngImport: i0, type: FfDropdownComponent, deps: [], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "16.2.12", type: FfDropdownComponent, isStandalone: true, selector: "app-ff-dropdown", inputs: { dropdownOptions: "dropdownOptions", label: "label", defaultValue: "defaultValue", hideSearch: "hideSearch", hideFooter: "hideFooter", inputClass: "inputClass", showRedBorder: "showRedBorder", labelClass: "labelClass", clearButtonText: "clearButtonText" }, outputs: { selectionChange: "selectionChange" }, viewQueries: [{ propertyName: "dropdownMenuTrigger", first: true, predicate: ["dropdownMenuTrigger"], descendants: true }], usesOnChanges: true, ngImport: i0, template: "<app-ff-dropdown-box [matMenuTriggerFor]=\"beforeMenu\" class=\"pointer\" [label]=\"label\" [value]=\"selectedItem?.name ?? ''\"\r\n    boxState=\"default\" [inputClass]=\"inputClass || 'full'\" [showError]=\"showRedBorder\" [labelClass]=\"labelClass\"\r\n    [customId]=\"customId || 'customId'\" #dropdownMenuTrigger=\"matMenuTrigger\" class=\"w-100\"></app-ff-dropdown-box>\r\n<mat-menu class=\"ff-mat-menu-dropdown\" #beforeMenu=\"matMenu\" xPosition=\"after\">\r\n    <app-ff-dropdown-select [menuItems]=\"dropdownOptions\" (click)=\"$event.stopPropagation();\"\r\n        [selectedId]=\"selectedItem?.id ?? ''\" [hideSearch]=\"hideSearch\" [hideFooter]=\"hideFooter\"\r\n        [clearButtonText]=\"clearButtonText\"\r\n        (currentSelected)=\"handleOptionSelection($event)\"\r\n        (footerClicked)=\"clearDropdown($event)\"></app-ff-dropdown-select>\r\n</mat-menu>", styles: ["::ng-deep .ff-mat-menu-dropdown{min-width:250px!important}\n"], dependencies: [{ kind: "ngmodule", type: CommonModule }, { kind: "ngmodule", type: MatMenuModule }, { kind: "component", type: i1$2.MatMenu, selector: "mat-menu", exportAs: ["matMenu"] }, { kind: "directive", type: i1$2.MatMenuTrigger, selector: "[mat-menu-trigger-for], [matMenuTriggerFor]", exportAs: ["matMenuTrigger"] }, { kind: "component", type: FfDropdownBoxComponent, selector: "app-ff-dropdown-box", inputs: ["label", "value", "customId", "boxState", "inputClass", "showError", "labelClass"], outputs: ["boxClicked"] }, { kind: "component", type: FfDropdownSelectComponent, selector: "app-ff-dropdown-select", inputs: ["menuItems", "hideSearch", "selectedId", "hideFooter", "clearButtonText"], outputs: ["currentSelected", "footerClicked"] }], changeDetection: i0.ChangeDetectionStrategy.OnPush }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "16.2.12", ngImport: i0, type: FfDropdownComponent, decorators: [{
            type: Component,
            args: [{ selector: 'app-ff-dropdown', standalone: true, imports: [
                        CommonModule,
                        MatMenuModule,
                        FfDropdownBoxComponent,
                        FfDropdownSelectComponent,
                    ], changeDetection: ChangeDetectionStrategy.OnPush, template: "<app-ff-dropdown-box [matMenuTriggerFor]=\"beforeMenu\" class=\"pointer\" [label]=\"label\" [value]=\"selectedItem?.name ?? ''\"\r\n    boxState=\"default\" [inputClass]=\"inputClass || 'full'\" [showError]=\"showRedBorder\" [labelClass]=\"labelClass\"\r\n    [customId]=\"customId || 'customId'\" #dropdownMenuTrigger=\"matMenuTrigger\" class=\"w-100\"></app-ff-dropdown-box>\r\n<mat-menu class=\"ff-mat-menu-dropdown\" #beforeMenu=\"matMenu\" xPosition=\"after\">\r\n    <app-ff-dropdown-select [menuItems]=\"dropdownOptions\" (click)=\"$event.stopPropagation();\"\r\n        [selectedId]=\"selectedItem?.id ?? ''\" [hideSearch]=\"hideSearch\" [hideFooter]=\"hideFooter\"\r\n        [clearButtonText]=\"clearButtonText\"\r\n        (currentSelected)=\"handleOptionSelection($event)\"\r\n        (footerClicked)=\"clearDropdown($event)\"></app-ff-dropdown-select>\r\n</mat-menu>", styles: ["::ng-deep .ff-mat-menu-dropdown{min-width:250px!important}\n"] }]
        }], propDecorators: { dropdownMenuTrigger: [{
                type: ViewChild,
                args: ['dropdownMenuTrigger']
            }], dropdownOptions: [{
                type: Input
            }], label: [{
                type: Input
            }], defaultValue: [{
                type: Input
            }], hideSearch: [{
                type: Input
            }], hideFooter: [{
                type: Input
            }], inputClass: [{
                type: Input
            }], showRedBorder: [{
                type: Input
            }], labelClass: [{
                type: Input
            }], clearButtonText: [{
                type: Input
            }], selectionChange: [{
                type: Output
            }] } });

/**
 * FfDropdownComponent
 *
 * This component represents a dropdown menu with selectable options. It utilizes Angular Material components for menu functionality.
 *
 * Usage:
 * <app-ff-dropdown></app-ff-dropdown>
 *
 * Selector: app-ff-dropdown
 *
 * @Input:
 *   - dropdownOptions: IDropdownItem[] - The list of dropdown options to display.
 *   - label: string - The label text for the dropdown.
 *   - defaultValue: IDropdownItem - The default selected option.
 *   - hideSearch: boolean - Determines whether to hide the search input in the dropdown menu.
 *   - hideFooter: boolean - Determines whether to hide the footer section in the dropdown menu.
 *
 * @Output:
 *   - selectionChange: EventEmitter<IDropdownItem> - Event emitted when a dropdown option is selected. The selected option is passed as the event payload.
 *
 * Dependencies:
 *   - CommonModule from '@angular/common'
 *   - MatMenuModule, MatMenuTrigger from '@angular/material/menu'
 *   - FfDropdownBoxComponent from '../ff-dropdown-box'
 *   - FfDropdownSelectComponent from '../ff-dropdown-select'
 *   - IDropdownItem from '../../configs/app.model'
 *
 * Example:
 * <app-ff-dropdown></app-ff-dropdown>
 */

/* eslint-disable @typescript-eslint/no-explicit-any */
class LabelFormatingPipe {
    transform(items) {
        if (!items) {
            return '';
        }
        return items.map((m) => m.name).join(', ');
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "16.2.12", ngImport: i0, type: LabelFormatingPipe, deps: [], target: i0.ɵɵFactoryTarget.Pipe }); }
    static { this.ɵpipe = i0.ɵɵngDeclarePipe({ minVersion: "14.0.0", version: "16.2.12", ngImport: i0, type: LabelFormatingPipe, isStandalone: true, name: "labelFormating", pure: false }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "16.2.12", ngImport: i0, type: LabelFormatingPipe, decorators: [{
            type: Pipe,
            args: [{
                    name: 'labelFormating',
                    pure: false,
                    standalone: true,
                }]
        }] });
class FfMultiSelectDropdownComponent {
    constructor() {
        this.selectionChange = new EventEmitter();
        this.selectedItems = [];
    }
    /**
     * closeMenu
     *
     * Closes the dropdown menu.
     *
     * @returns void
     */
    closeMenu() {
        this.dropdownMenuTrigger.closeMenu();
    }
    handleOptionSelection(selectedOption) {
        const found = this.selectedItems.find((f) => f.id === selectedOption.id);
        if (found) {
            this.selectedItems = this.selectedItems.filter((s) => s.id !== selectedOption.id);
        }
        else {
            this.selectedItems.push(selectedOption);
        }
        this.selectionChange.emit(selectedOption);
        this.closeMenu();
    }
    clearDropdown(clear) {
        if (clear) {
            this.selectedItems = [];
            this.selectionChange.emit('');
            this.closeMenu();
        }
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "16.2.12", ngImport: i0, type: FfMultiSelectDropdownComponent, deps: [], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "16.2.12", type: FfMultiSelectDropdownComponent, isStandalone: true, selector: "app-ff-multi-select-dropdown", inputs: { dropdownOptions: "dropdownOptions", label: "label", defaultValue: "defaultValue", hideSearch: "hideSearch", hideFooter: "hideFooter", inputClass: "inputClass" }, outputs: { selectionChange: "selectionChange" }, viewQueries: [{ propertyName: "dropdownMenuTrigger", first: true, predicate: ["dropdownMenuTrigger"], descendants: true }], ngImport: i0, template: "<app-ff-dropdown-box [matMenuTriggerFor]=\"beforeMenu\" class=\"pointer\" [label]=\"label\"\r\n    [value]=\"selectedItems|labelFormating\" boxState=\"default\" [inputClass]=\"inputClass || 'full'\"\r\n    #dropdownMenuTrigger=\"matMenuTrigger\"></app-ff-dropdown-box>\r\n<mat-menu class=\"ff-mat-menu-dropdown\" #beforeMenu=\"matMenu\" xPosition=\"after\">\r\n    <app-ff-drop-menu-checkbox [menuItems]=\"dropdownOptions\" (click)=\"$event.stopPropagation();\"\r\n        [hideSearch]=\"hideSearch\" (currentSelected)=\"handleOptionSelection($event)\"\r\n        (footerClicked)=\"clearDropdown($event)\"></app-ff-drop-menu-checkbox>\r\n</mat-menu>", dependencies: [{ kind: "ngmodule", type: CommonModule }, { kind: "component", type: FfDropMenuCheckboxComponent, selector: "app-ff-drop-menu-checkbox", inputs: ["menuItems", "hideSearch", "selectedItems"], outputs: ["footerClicked", "currentSelected"] }, { kind: "component", type: FfDropdownBoxComponent, selector: "app-ff-dropdown-box", inputs: ["label", "value", "customId", "boxState", "inputClass", "showError", "labelClass"], outputs: ["boxClicked"] }, { kind: "ngmodule", type: MatMenuModule }, { kind: "component", type: i1$2.MatMenu, selector: "mat-menu", exportAs: ["matMenu"] }, { kind: "directive", type: i1$2.MatMenuTrigger, selector: "[mat-menu-trigger-for], [matMenuTriggerFor]", exportAs: ["matMenuTrigger"] }, { kind: "pipe", type: LabelFormatingPipe, name: "labelFormating" }] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "16.2.12", ngImport: i0, type: FfMultiSelectDropdownComponent, decorators: [{
            type: Component,
            args: [{ selector: 'app-ff-multi-select-dropdown', standalone: true, imports: [
                        CommonModule,
                        FfDropMenuCheckboxComponent,
                        FfDropdownBoxComponent,
                        MatMenuModule,
                        LabelFormatingPipe,
                    ], template: "<app-ff-dropdown-box [matMenuTriggerFor]=\"beforeMenu\" class=\"pointer\" [label]=\"label\"\r\n    [value]=\"selectedItems|labelFormating\" boxState=\"default\" [inputClass]=\"inputClass || 'full'\"\r\n    #dropdownMenuTrigger=\"matMenuTrigger\"></app-ff-dropdown-box>\r\n<mat-menu class=\"ff-mat-menu-dropdown\" #beforeMenu=\"matMenu\" xPosition=\"after\">\r\n    <app-ff-drop-menu-checkbox [menuItems]=\"dropdownOptions\" (click)=\"$event.stopPropagation();\"\r\n        [hideSearch]=\"hideSearch\" (currentSelected)=\"handleOptionSelection($event)\"\r\n        (footerClicked)=\"clearDropdown($event)\"></app-ff-drop-menu-checkbox>\r\n</mat-menu>" }]
        }], propDecorators: { dropdownMenuTrigger: [{
                type: ViewChild,
                args: ['dropdownMenuTrigger']
            }], dropdownOptions: [{
                type: Input
            }], label: [{
                type: Input
            }], defaultValue: [{
                type: Input
            }], hideSearch: [{
                type: Input
            }], hideFooter: [{
                type: Input
            }], inputClass: [{
                type: Input
            }], selectionChange: [{
                type: Output
            }] } });

/**
 * Generated bundle index. Do not edit.
 */

export { FairFoodInputComponent, FfDropMenuCheckboxComponent, FfDropMenuRadioComponent, FfDropdownBoxComponent, FfDropdownComponent, FfDropdownSelectComponent, FfFilterBoxComponent, FfFilterBoxWrapperComponent, FfMultiSelectDropdownComponent };
//# sourceMappingURL=fairfood-form-components.mjs.map
