import { EventEmitter, OnChanges, SimpleChanges } from '@angular/core';
import { MatMenuTrigger } from '@angular/material/menu';
import { IDropdownItem } from '../configs/app.model';
import * as i0 from "@angular/core";
export declare class FfDropdownComponent implements OnChanges {
    dropdownMenuTrigger: MatMenuTrigger;
    dropdownOptions: IDropdownItem[];
    label: string;
    defaultValue: string;
    hideSearch: boolean;
    hideFooter: boolean;
    inputClass: string;
    showRedBorder: boolean;
    labelClass: boolean;
    clearButtonText: string;
    selectionChange: EventEmitter<any>;
    selectedItem: Partial<IDropdownItem>;
    customId: string;
    ngOnChanges(changes: SimpleChanges): void;
    /**
     * handleOptionSelection
     *
     * Updates the selected item and emits the selectionChange event with the selected item as the payload.
     *
     * @param selectedOption - The selected dropdown item.
     * @returns void
     */
    handleOptionSelection(selectedOption: IDropdownItem): void;
    /**
     * closeMenu
     *
     * Closes the dropdown menu.
     *
     * @returns void
     */
    closeMenu(): void;
    clearDropdown(clear: boolean): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<FfDropdownComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<FfDropdownComponent, "app-ff-dropdown", never, { "dropdownOptions": { "alias": "dropdownOptions"; "required": false; }; "label": { "alias": "label"; "required": false; }; "defaultValue": { "alias": "defaultValue"; "required": false; }; "hideSearch": { "alias": "hideSearch"; "required": false; }; "hideFooter": { "alias": "hideFooter"; "required": false; }; "inputClass": { "alias": "inputClass"; "required": false; }; "showRedBorder": { "alias": "showRedBorder"; "required": false; }; "labelClass": { "alias": "labelClass"; "required": false; }; "clearButtonText": { "alias": "clearButtonText"; "required": false; }; }, { "selectionChange": "selectionChange"; }, never, never, true, never>;
}
