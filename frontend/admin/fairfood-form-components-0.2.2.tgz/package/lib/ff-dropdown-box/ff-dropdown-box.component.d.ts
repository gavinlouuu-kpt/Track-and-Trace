import { EventEmitter } from '@angular/core';
import * as i0 from "@angular/core";
export declare class FfDropdownBoxComponent {
    label: string;
    value: string;
    customId: string;
    boxState: 'default' | 'selected';
    inputClass: string;
    showError: boolean;
    labelClass: boolean;
    boxClicked: EventEmitter<any>;
    /**
     * itemClicked
     *
     * Handles the click event on the dropdown box and emits the boxClicked event.
     *
     * @returns void
     */
    itemClicked(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<FfDropdownBoxComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<FfDropdownBoxComponent, "app-ff-dropdown-box", never, { "label": { "alias": "label"; "required": false; }; "value": { "alias": "value"; "required": false; }; "customId": { "alias": "customId"; "required": false; }; "boxState": { "alias": "boxState"; "required": false; }; "inputClass": { "alias": "inputClass"; "required": false; }; "showError": { "alias": "showError"; "required": false; }; "labelClass": { "alias": "labelClass"; "required": false; }; }, { "boxClicked": "boxClicked"; }, never, never, true, never>;
}
