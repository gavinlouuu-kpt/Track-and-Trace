import { EventEmitter, OnChanges, SimpleChanges } from '@angular/core';
import { MatMenuTrigger } from '@angular/material/menu';
import * as i0 from "@angular/core";
export declare class FfFilterBoxWrapperComponent implements OnChanges {
    dropdownMenuTrigger: MatMenuTrigger;
    filterMasterData: any;
    multiple?: boolean | undefined;
    label: string;
    defaultValue: any;
    hideSearch: boolean;
    hideFooter: boolean;
    customId?: string;
    selectionChange: EventEmitter<any>;
    selectedItem: any;
    /**
     * ngOnChanges
     *
     * Lifecycle hook that gets called whenever the input properties change.
     * Handles setting the default selected item based on defaultValue input.
     *
     * @param changes - The changes object containing the changed properties.
     * @returns void
     */
    ngOnChanges(changes: SimpleChanges): void;
    /**
     * closeMenu
     *
     * Closes the dropdown menu by triggering the closeMenu() method of MatMenuTrigger.
     *
     * @returns void
     */
    closeMenu(): void;
    /**
     * selectionChanged
     *
     * Handles the selection change event from the dropdown menu.
     * Emits the selected item and updates the selectedItem property.
     *
     * @param data - The selected item data.
     * @returns void
     */
    selectionChanged(data: any): void;
    /**
     * footerClicked
     *
     * Handles the click event on the "Clear selection" footer in the dropdown menu.
     * Emits a default selected item and updates the selectedItem property.
     *
     * @returns void
     */
    footerClicked(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<FfFilterBoxWrapperComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<FfFilterBoxWrapperComponent, "app-ff-filter-box-wrapper", never, { "filterMasterData": { "alias": "filterMasterData"; "required": false; }; "multiple": { "alias": "multiple"; "required": false; }; "label": { "alias": "label"; "required": false; }; "defaultValue": { "alias": "defaultValue"; "required": false; }; "hideSearch": { "alias": "hideSearch"; "required": false; }; "hideFooter": { "alias": "hideFooter"; "required": false; }; "customId": { "alias": "customId"; "required": false; }; }, { "selectionChange": "selectionChange"; }, never, never, true, never>;
}
