import { EventEmitter } from '@angular/core';
import * as i0 from "@angular/core";
interface Item {
    name: string;
    id: string;
    disabled?: boolean;
}
export declare class FfDropMenuCheckboxComponent {
    /**
     * Input: menuItems
     * Description: An array of items to be displayed in the dropdown menu.
     * Each item should have a 'name' and 'id' property.
     * 'name' represents the display text, and 'id' uniquely identifies the item.
     * An optional 'disabled' property can be set to true to disable the checkbox.
     */
    menuItems: Partial<Item>[];
    /**
     * Input: hideSearch
     * Description: Boolean value indicating whether to hide the search box.
     * Set to 'true' to hide the search functionality.
     */
    hideSearch: boolean;
    /**
     * Input: selectedItems
     * Description: An array of 'id's representing the initially selected items.
     * Use this property to preselect items in the dropdown menu.
     */
    selectedItems: string[];
    /**
     * Output: footerClicked
     * Description: Event emitted when the "Clear selection" footer is clicked.
     */
    footerClicked: EventEmitter<any>;
    /**
     * Output: currentSelected
     * Description: Event emitted when an item is selected or deselected.
     * The selected item object is emitted as the event payload.
     */
    currentSelected: EventEmitter<any>;
    searchString: string;
    /**
     * Method: multipleSelection
     * Description: Called when an item is selected or deselected.
     * Emits the 'currentSelected' event with the selected item as the payload.
     * @param row - The selected item object.
     */
    multipleSelection(row: Item): void;
    /**
     * Method: clearSelection
     * Description: Called when the "Clear selection" footer is clicked.
     * Emits the 'footerClicked' event.
     */
    clearSelection(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<FfDropMenuCheckboxComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<FfDropMenuCheckboxComponent, "app-ff-drop-menu-checkbox", never, { "menuItems": { "alias": "menuItems"; "required": false; }; "hideSearch": { "alias": "hideSearch"; "required": false; }; "selectedItems": { "alias": "selectedItems"; "required": false; }; }, { "footerClicked": "footerClicked"; "currentSelected": "currentSelected"; }, never, never, true, never>;
}
export {};
