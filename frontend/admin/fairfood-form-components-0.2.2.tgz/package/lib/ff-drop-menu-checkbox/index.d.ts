export { FfDropMenuCheckboxComponent } from './ff-drop-menu-checkbox.component';
/**
 * Component: FfDropMenuCheckboxComponent
 * Description: Represents a dropdown menu with checkboxes.
 * Allows users to select multiple options from a list of items.
 * Provides search functionality to filter options and a "Clear selection" button.
 *
 * Usage:
 * <app-ff-drop-menu-checkbox
 *   [menuItems]="items"
 *   [hideSearch]="false"
 *   [selectedItems]="selectedItemIds"
 *   (footerClicked)="handleFooterClick($event)"
 *   (currentSelected)="handleItemSelected($event)"
 * ></app-ff-drop-menu-checkbox>
 */
