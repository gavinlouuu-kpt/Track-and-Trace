import { EventEmitter } from '@angular/core';
import * as i0 from "@angular/core";
export declare class FfFilterBoxComponent {
    label: string;
    value: string;
    boxState: 'default' | 'selected';
    showRedBorder?: boolean;
    tooltipText: string;
    customId?: string;
    boxClicked: EventEmitter<any>;
    itemClicked(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<FfFilterBoxComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<FfFilterBoxComponent, "app-ff-filter-box", never, { "label": { "alias": "label"; "required": false; }; "value": { "alias": "value"; "required": false; }; "boxState": { "alias": "boxState"; "required": false; }; "showRedBorder": { "alias": "showRedBorder"; "required": false; }; "tooltipText": { "alias": "tooltipText"; "required": false; }; "customId": { "alias": "customId"; "required": false; }; }, { "boxClicked": "boxClicked"; }, never, never, true, never>;
}
