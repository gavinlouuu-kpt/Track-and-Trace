import { EventEmitter } from '@angular/core';
import { IDropdownItem } from '../configs/app.model';
import * as i0 from "@angular/core";
export declare class FfDropdownSelectComponent {
    menuItems: IDropdownItem[];
    hideSearch: boolean;
    selectedId: string | number;
    hideFooter: boolean;
    clearButtonText: string;
    currentSelected: EventEmitter<any>;
    footerClicked: EventEmitter<any>;
    searchString: string;
    /**
     * menuItemSelected
     *
     * Handles the selection of a menu item and emits the currentSelected event with the selected item.
     *
     * @param selected - The selected dropdown item.
     * @returns void
     */
    menuItemSelected(selected: IDropdownItem): void;
    /**
     * clearSelection
     *
     * Handles the click event on the clear selection footer and emits the footerClicked event.
     *
     * @returns void
     */
    clearSelection(): void;
    trackByFn(index: number): number;
    static ɵfac: i0.ɵɵFactoryDeclaration<FfDropdownSelectComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<FfDropdownSelectComponent, "app-ff-dropdown-select", never, { "menuItems": { "alias": "menuItems"; "required": false; }; "hideSearch": { "alias": "hideSearch"; "required": false; }; "selectedId": { "alias": "selectedId"; "required": false; }; "hideFooter": { "alias": "hideFooter"; "required": false; }; "clearButtonText": { "alias": "clearButtonText"; "required": false; }; }, { "currentSelected": "currentSelected"; "footerClicked": "footerClicked"; }, never, never, true, never>;
}
