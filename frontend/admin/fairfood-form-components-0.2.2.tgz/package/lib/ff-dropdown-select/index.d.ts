export { FfDropdownSelectComponent } from './ff-dropdown-select.component';
/**
 * FfDropdownSelectComponent
 *
 * This component represents the dropdown menu for selecting options.
 *
 * Usage:
 * <app-ff-dropdown-select></app-ff-dropdown-select>
 *
 * Selector: app-ff-dropdown-select
 *
 * @Input:
 *   - menuItems: IDropdownItem[] - The list of dropdown menu items.
 *   - hideSearch: boolean - Determines whether to hide the search box.
 *   - selectedId: string | number - The ID of the currently selected item.
 *   - hideFooter: boolean - Determines whether to hide the clear selection footer.
 *
 * @Output:
 *   - currentSelected: EventEmitter<any> - Event emitted when an item is selected from the dropdown menu. It emits the selected item.
 *   - footerClicked: EventEmitter<boolean> - Event emitted when the clear selection footer is clicked. It emits a boolean value indicating the footer click event.
 *
 * Dependencies:
 *   - CommonModule from '@angular/common'
 *   - FormsModule from '@angular/forms'
 *   - FilterDropdownPipe (custom pipe) for filtering dropdown menu items based on search query
 *
 * Example:
 * <app-ff-dropdown-select></app-ff-dropdown-select>
 */
