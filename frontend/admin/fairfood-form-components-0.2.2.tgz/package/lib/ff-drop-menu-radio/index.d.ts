export { FfDropMenuRadioComponent } from './ff-drop-menu-radio.component';
/**
 * Component: FfDropMenuRadioComponent
 * Description: Represents a dropdown menu with radio buttons.
 * Allows users to select a single option from a list of items.
 * Provides search functionality to filter options and a "Clear selection" button.
 *
 * Usage:
 * <app-ff-drop-menu-radio
 *   [menuItems]="items"
 *   [hideSearch]="false"
 *   [selectedId]="selectedItemId"
 *   (currentSelected)="handleItemSelected($event)"
 *   (footerClicked)="handleFooterClick($event)"
 * ></app-ff-drop-menu-radio>
 */
