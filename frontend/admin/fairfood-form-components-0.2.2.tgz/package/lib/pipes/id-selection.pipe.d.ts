import { PipeTransform } from '@angular/core';
import * as i0 from "@angular/core";
export declare class IdSelectionPipe implements PipeTransform {
    transform(item: string): any;
    static ɵfac: i0.ɵɵFactoryDeclaration<IdSelectionPipe, never>;
    static ɵpipe: i0.ɵɵPipeDeclaration<IdSelectionPipe, "idSelection", true>;
}
