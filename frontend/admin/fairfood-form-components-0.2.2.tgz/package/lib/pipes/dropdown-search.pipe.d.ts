import { PipeTransform } from '@angular/core';
import * as i0 from "@angular/core";
export declare class FilterDropdownPipe implements PipeTransform {
    transform(items: any[], searchKey: any): any;
    static ɵfac: i0.ɵɵFactoryDeclaration<FilterDropdownPipe, never>;
    static ɵpipe: i0.ɵɵPipeDeclaration<FilterDropdownPipe, "searchOptions", true>;
}
