export interface IDropdownItem {
    id: string;
    name: string;
    hideItem?: boolean;
}
