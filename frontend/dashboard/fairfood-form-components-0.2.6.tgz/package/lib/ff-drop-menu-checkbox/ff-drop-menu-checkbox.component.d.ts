import { EventEmitter } from '@angular/core';
import * as i0 from "@angular/core";
interface Item {
    name: string;
    id: string;
    disabled?: boolean;
}
export declare class FfDropMenuCheckboxComponent {
    menuItems: Partial<Item>[];
    hideSearch: boolean;
    selectedItems: string[];
    selectAllOption: boolean;
    footerClicked: EventEmitter<any>;
    currentSelected: EventEmitter<any>;
    searchString: string;
    multipleSelection(row: Item): void;
    clearSelection(): void;
    isAllSelected(): boolean;
    toggleSelectAll(event: any): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<FfDropMenuCheckboxComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<FfDropMenuCheckboxComponent, "app-ff-drop-menu-checkbox", never, { "menuItems": { "alias": "menuItems"; "required": false; }; "hideSearch": { "alias": "hideSearch"; "required": false; }; "selectedItems": { "alias": "selectedItems"; "required": false; }; "selectAllOption": { "alias": "selectAllOption"; "required": false; }; }, { "footerClicked": "footerClicked"; "currentSelected": "currentSelected"; }, never, never, true, never>;
}
export {};
