import { EventEmitter } from '@angular/core';
import { MatMenuTrigger } from '@angular/material/menu';
import { IDropdownItem } from '../configs/app.model';
import * as i0 from "@angular/core";
export declare class FfMultiSelectDropdownComponent {
    dropdownMenuTrigger: MatMenuTrigger;
    dropdownOptions: IDropdownItem[];
    label: string;
    defaultValue: any;
    hideSearch: boolean;
    hideFooter: boolean;
    inputClass: string;
    multipleItems: boolean;
    itemCount: number;
    isAllSelected: boolean;
    selectionChange: EventEmitter<any>;
    selectedItems: IDropdownItem[];
    /**
     * closeMenu
     *
     * Closes the dropdown menu.
     *
     * @returns void
     */
    closeMenu(): void;
    handleOptionSelection(selectedOption: IDropdownItem): void;
    clearDropdown(clear: boolean): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<FfMultiSelectDropdownComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<FfMultiSelectDropdownComponent, "app-ff-multi-select-dropdown", never, { "dropdownOptions": { "alias": "dropdownOptions"; "required": false; }; "label": { "alias": "label"; "required": false; }; "defaultValue": { "alias": "defaultValue"; "required": false; }; "hideSearch": { "alias": "hideSearch"; "required": false; }; "hideFooter": { "alias": "hideFooter"; "required": false; }; "inputClass": { "alias": "inputClass"; "required": false; }; "multipleItems": { "alias": "multipleItems"; "required": false; }; "itemCount": { "alias": "itemCount"; "required": false; }; "isAllSelected": { "alias": "isAllSelected"; "required": false; }; }, { "selectionChange": "selectionChange"; }, never, never, true, never>;
}
