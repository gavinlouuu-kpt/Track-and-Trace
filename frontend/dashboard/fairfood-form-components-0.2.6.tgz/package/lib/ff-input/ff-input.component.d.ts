import * as i0 from "@angular/core";
export declare class FairFoodInputComponent {
    parentFormGroup: any;
    controlName: string;
    label: any;
    inputSize: string;
    inputType: string;
    isTextarea?: boolean;
    static ɵfac: i0.ɵɵFactoryDeclaration<FairFoodInputComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<FairFoodInputComponent, "app-ff-input", never, { "parentFormGroup": { "alias": "parentFormGroup"; "required": false; }; "controlName": { "alias": "controlName"; "required": false; }; "label": { "alias": "label"; "required": false; }; "inputSize": { "alias": "inputSize"; "required": false; }; "inputType": { "alias": "inputType"; "required": false; }; "isTextarea": { "alias": "isTextarea"; "required": false; }; }, {}, never, never, true, never>;
}
