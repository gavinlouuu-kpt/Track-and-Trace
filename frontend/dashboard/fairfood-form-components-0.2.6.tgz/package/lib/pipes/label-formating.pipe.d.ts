import { PipeTransform } from "@angular/core";
import { IDropdownItem } from "../configs/app.model";
import * as i0 from "@angular/core";
export declare class LabelFormatingPipe implements PipeTransform {
    transform(items: IDropdownItem[]): any;
    static ɵfac: i0.ɵɵFactoryDeclaration<LabelFormatingPipe, never>;
    static ɵpipe: i0.ɵɵPipeDeclaration<LabelFormatingPipe, "labelFormating", true>;
}
