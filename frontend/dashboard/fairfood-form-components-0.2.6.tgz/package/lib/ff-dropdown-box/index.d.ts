export { FfDropdownBoxComponent } from './ff-dropdown-box.component';
/**
 * FfDropdownBoxComponent
 *
 * This component represents the box portion of the dropdown menu.
 * It displays the selected value and label.
 *
 * Usage:
 * <app-ff-dropdown-box></app-ff-dropdown-box>
 *
 * Selector: app-ff-dropdown-box
 *
 * @Input:
 *   - label: string - The label text for the dropdown box.
 *   - value: string - The value to display in the dropdown box.
 *   - boxState: 'default' | 'selected' - The state of the dropdown box. 'default' represents the initial state, and 'selected' represents a selected state.
 *
 * @Output:
 *   - boxClicked: EventEmitter<boolean> - Event emitted when the dropdown box is clicked. It emits a boolean value indicating whether the box was clicked.
 *
 * Dependencies:
 *   - CommonModule from '@angular/common'
 *   - MatIconModule from '@angular/material/icon'
 *
 * Example:
 * <app-ff-dropdown-box></app-ff-dropdown-box>
 */
