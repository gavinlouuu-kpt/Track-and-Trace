/**
 * @component FfFilterBoxComponent
 * @description
 *   The `FfFilterBoxComponent` is a reusable Angular component that represents a filter box with a label, value, and dropdown arrow.
 *   It can be used to display and interact with filter options in an Angular application.
 *
 * @usage
 *   ```
 *   <app-ff-filter-box
 *     [label]="filterLabel"
 *     [value]="filterValue"
 *     [boxState]="filterState"
 *     (boxClicked)="onBoxClicked($event)"
 *   ></app-ff-filter-box>
 *   ```
 *
 * @inputs
 *   - `label` (string): The label text to display in the filter box.
 *   - `value` (string): The value to display in the filter box.
 *   - `boxState` (optional): The state of the filter box. Possible values are `'default'` and `'selected'`.
 *
 * @outputs
 *   - `boxClicked` (EventEmitter<boolean>): An event emitted when the filter box is clicked. It emits a boolean value (`true`).
 *
 * @example
 *   ```typescript
 *   import { Component } from '@angular/core';
 *
 *   @Component({
 *     selector: 'app-example',
 *     template: `
 *       <app-ff-filter-box
 *         [label]="'Category'"
 *         [value]="'All'"
 *         [boxState]="'default'"
 *         (boxClicked)="onFilterBoxClicked()"
 *       ></app-ff-filter-box>
 *     `,
 *   })
 *   export class ExampleComponent {
 *     onFilterBoxClicked() {
 *       // Handle filter box click event
 *     }
 *   }
 *   ```
 *
 * @styles
 *   The `FfFilterBoxComponent` applies the following CSS classes:
 *   - `.ff-dropdown-container`: The main container of the filter box.
 *   - `.active`: Applied when `boxState` is `'selected'`. Changes the background color of the filter box.
 *   - `.default`: Applied when `boxState` is `'default'`. Changes the background color of the filter box.
 *   - `.box-label`: The CSS class for the label text inside the filter box.
 *   - `.box-value`: The CSS class for the value text inside the filter box.
 *   - `mat-icon`: The CSS class for the dropdown arrow icon.
 *
 * @dependencies
 *   This component requires the following Angular modules and dependencies to be imported:
 *   - `@angular/core`: Angular core module.
 *   - `@angular/common`: Angular common module.
 *   - `@angular/material/icon`: Angular Material icon module (for the dropdown arrow icon).
 *
 * @version 1.0.0
 */
export { FfFilterBoxComponent } from './ff-filter-box.component';
