export { FfDropdownComponent } from './ff-dropdown.component';
/**
 * FfDropdownComponent
 *
 * This component represents a dropdown menu with selectable options. It utilizes Angular Material components for menu functionality.
 *
 * Usage:
 * <app-ff-dropdown></app-ff-dropdown>
 *
 * Selector: app-ff-dropdown
 *
 * @Input:
 *   - dropdownOptions: IDropdownItem[] - The list of dropdown options to display.
 *   - label: string - The label text for the dropdown.
 *   - defaultValue: IDropdownItem - The default selected option.
 *   - hideSearch: boolean - Determines whether to hide the search input in the dropdown menu.
 *   - hideFooter: boolean - Determines whether to hide the footer section in the dropdown menu.
 *
 * @Output:
 *   - selectionChange: EventEmitter<IDropdownItem> - Event emitted when a dropdown option is selected. The selected option is passed as the event payload.
 *
 * Dependencies:
 *   - CommonModule from '@angular/common'
 *   - MatMenuModule, MatMenuTrigger from '@angular/material/menu'
 *   - FfDropdownBoxComponent from '../ff-dropdown-box'
 *   - FfDropdownSelectComponent from '../ff-dropdown-select'
 *   - IDropdownItem from '../../configs/app.model'
 *
 * Example:
 * <app-ff-dropdown></app-ff-dropdown>
 */
