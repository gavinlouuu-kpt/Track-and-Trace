import { EventEmitter } from '@angular/core';
import { IDropdownItem } from '../configs/app.model';
import * as i0 from "@angular/core";
export declare class FfDropMenuRadioComponent {
    /**
     * Input: menuItems
     * Description: An array of items to be displayed in the dropdown menu.
     * Each item should have a 'name' and 'id' property.
     * 'name' represents the display text, and 'id' uniquely identifies the item.
     */
    menuItems: Partial<IDropdownItem>[];
    /**
     * Input: hideSearch
     * Description: Boolean value indicating whether to hide the search box.
     * Set to 'true' to hide the search functionality.
     */
    hideSearch: boolean;
    /**
     * Input: selectedId
     * Description: The 'id' of the currently selected item.
     * Use this property to preselect an item in the dropdown menu.
     */
    selectedId: string | number;
    /**
     * Output: currentSelected
     * Description: Event emitted when an item is selected from the dropdown menu.
     * The selected item object is emitted as the event payload.
     */
    currentSelected: EventEmitter<any>;
    /**
     * Output: footerClicked
     * Description: Event emitted when the "Clear selection" footer is clicked.
     */
    footerClicked: EventEmitter<any>;
    searchString: string;
    /**
     * Method: menuItemSelected
     * Description: Called when an item is selected from the dropdown menu.
     * Emits the 'currentSelected' event with the selected item as the payload.
     * @param selected - The selected item object.
     */
    menuItemSelected(selected: IDropdownItem): void;
    /**
     * Method: clearSelection
     * Description: Called when the "Clear selection" footer is clicked.
     * Emits the 'footerClicked' event.
     */
    clearSelection(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<FfDropMenuRadioComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<FfDropMenuRadioComponent, "app-ff-drop-menu-radio", never, { "menuItems": { "alias": "menuItems"; "required": false; }; "hideSearch": { "alias": "hideSearch"; "required": false; }; "selectedId": { "alias": "selectedId"; "required": false; }; }, { "currentSelected": "currentSelected"; "footerClicked": "footerClicked"; }, never, never, true, never>;
}
