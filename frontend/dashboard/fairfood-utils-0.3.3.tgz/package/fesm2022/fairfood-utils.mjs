import * as i1 from '@angular/common';
import { CommonModule, NgIf, AsyncPipe } from '@angular/common';
import * as i0 from '@angular/core';
import { Pipe, EventEmitter, Component, ChangeDetectionStrategy, Input, Output, ViewChild, Inject, inject, Injectable } from '@angular/core';
import * as i4 from '@angular/material/checkbox';
import { MatCheckboxModule } from '@angular/material/checkbox';
import * as i2 from '@angular/material/icon';
import { MatIconModule } from '@angular/material/icon';
import * as i2$1 from '@angular/material/menu';
import { MatMenuModule } from '@angular/material/menu';
import * as i3 from '@angular/material/paginator';
import { MatPaginator, MatPaginatorModule } from '@angular/material/paginator';
import * as i4$1 from '@angular/forms';
import { FormsModule } from '@angular/forms';
import { Subject, takeUntil } from 'rxjs';
import { HttpHeaders, HttpClient } from '@angular/common/http';
import * as i1$1 from '@angular/material/snack-bar';
import { MAT_SNACK_BAR_DATA, MatSnackBarModule, MatSnackBar } from '@angular/material/snack-bar';

class ButtonClassPipe {
    transform(value, size, custom) {
        let buttonClass = '';
        switch (value) {
            case 'fill':
                buttonClass = 'ff-btn-fill';
                break;
            case 'stroked':
                buttonClass = 'ff-btn-stroked';
                break;
            case 'secondary':
                buttonClass = 'ff-btn-secondary';
                break;
            default:
                buttonClass = 'ff-btn-fill';
                break;
        }
        if (size === 'medium') {
            buttonClass += ` md`;
        }
        else {
            buttonClass += ` lg`;
        }
        if (custom) {
            buttonClass += ` ${custom}`;
        }
        return buttonClass;
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "16.2.12", ngImport: i0, type: ButtonClassPipe, deps: [], target: i0.ɵɵFactoryTarget.Pipe }); }
    static { this.ɵpipe = i0.ɵɵngDeclarePipe({ minVersion: "14.0.0", version: "16.2.12", ngImport: i0, type: ButtonClassPipe, isStandalone: true, name: "generateBtnClass" }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "16.2.12", ngImport: i0, type: ButtonClassPipe, decorators: [{
            type: Pipe,
            args: [{
                    name: 'generateBtnClass',
                    standalone: true,
                }]
        }] });

class ButtonsComponent {
    constructor() {
        /**
         * Event emitted when the button is clicked.
         * Emits a boolean value representing the click event.
         *
         * @type {EventEmitter<boolean>}
         * @memberof ButtonsComponent
         */
        this.buttonClicked = new EventEmitter();
    }
    buttonClick() {
        this.buttonClicked.emit(true);
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "16.2.12", ngImport: i0, type: ButtonsComponent, deps: [], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "16.2.12", type: ButtonsComponent, isStandalone: true, selector: "app-buttons", inputs: { buttonType: "buttonType", buttonSize: "buttonSize", customId: "customId", buttonClass: "buttonClass", isDisabled: "isDisabled", tooltip: "tooltip" }, outputs: { buttonClicked: "buttonClicked" }, ngImport: i0, template: "<button type=\"button\" [ngClass]=\"buttonType | generateBtnClass:buttonSize:buttonClass \" (click)=\"buttonClick()\"\n    [disabled]=\"isDisabled\" [title]=\"tooltip || ''\" [id]=\"customId || 'actionButton'\">\n    <ng-content></ng-content>\n</button>", styles: [".ff-btn-secondary,.ff-btn-fill,.ff-btn-stroked{cursor:pointer;font-family:Moderat Regular,sans-serif;transition:color .15s ease-in-out,background-color .15s ease-in-out,border-color .15s ease-in-out,box-shadow .15s ease-in-out;border:none;font-size:14px;height:auto!important;margin:5px;white-space:nowrap;border-radius:5px;display:flex;align-items:center;line-height:1}.lg.ff-btn-secondary,.lg.ff-btn-fill,.lg.ff-btn-stroked{padding:12px 25px}@media only screen and (min-width: 1600px){.lg.ff-btn-secondary,.lg.ff-btn-fill,.lg.ff-btn-stroked{padding:15px 25px}}.md.ff-btn-secondary,.md.ff-btn-fill,.md.ff-btn-stroked{padding:7.5px 15px}@media only screen and (min-width: 1600px){.md.ff-btn-secondary,.md.ff-btn-fill,.md.ff-btn-stroked{padding:12px 16px}}.ff-btn-secondary:disabled,.ff-btn-fill:disabled,.ff-btn-stroked:disabled{background:var(--border-color);border:none;color:var(--font-color);cursor:default}.ff-btn-stroked{background-color:var(--color-white);color:var(--color-secondary);border:1px solid var(--color-secondary)}.ff-btn-fill{background-color:var(--color-secondary);color:var(--color-white)}.ff-btn-secondary{background-color:var(--color-white);color:var(--font-color);border:1px solid var(--font-color);height:34px!important;padding:10px!important}@media only screen and (min-width: 1600px){.ff-btn-secondary{padding:10px 15px!important;height:40px!important}}\n"], dependencies: [{ kind: "ngmodule", type: CommonModule }, { kind: "directive", type: i1.NgClass, selector: "[ngClass]", inputs: ["class", "ngClass"] }, { kind: "pipe", type: ButtonClassPipe, name: "generateBtnClass" }], changeDetection: i0.ChangeDetectionStrategy.OnPush }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "16.2.12", ngImport: i0, type: ButtonsComponent, decorators: [{
            type: Component,
            args: [{ selector: 'app-buttons', standalone: true, imports: [CommonModule, ButtonClassPipe], changeDetection: ChangeDetectionStrategy.OnPush, template: "<button type=\"button\" [ngClass]=\"buttonType | generateBtnClass:buttonSize:buttonClass \" (click)=\"buttonClick()\"\n    [disabled]=\"isDisabled\" [title]=\"tooltip || ''\" [id]=\"customId || 'actionButton'\">\n    <ng-content></ng-content>\n</button>", styles: [".ff-btn-secondary,.ff-btn-fill,.ff-btn-stroked{cursor:pointer;font-family:Moderat Regular,sans-serif;transition:color .15s ease-in-out,background-color .15s ease-in-out,border-color .15s ease-in-out,box-shadow .15s ease-in-out;border:none;font-size:14px;height:auto!important;margin:5px;white-space:nowrap;border-radius:5px;display:flex;align-items:center;line-height:1}.lg.ff-btn-secondary,.lg.ff-btn-fill,.lg.ff-btn-stroked{padding:12px 25px}@media only screen and (min-width: 1600px){.lg.ff-btn-secondary,.lg.ff-btn-fill,.lg.ff-btn-stroked{padding:15px 25px}}.md.ff-btn-secondary,.md.ff-btn-fill,.md.ff-btn-stroked{padding:7.5px 15px}@media only screen and (min-width: 1600px){.md.ff-btn-secondary,.md.ff-btn-fill,.md.ff-btn-stroked{padding:12px 16px}}.ff-btn-secondary:disabled,.ff-btn-fill:disabled,.ff-btn-stroked:disabled{background:var(--border-color);border:none;color:var(--font-color);cursor:default}.ff-btn-stroked{background-color:var(--color-white);color:var(--color-secondary);border:1px solid var(--color-secondary)}.ff-btn-fill{background-color:var(--color-secondary);color:var(--color-white)}.ff-btn-secondary{background-color:var(--color-white);color:var(--font-color);border:1px solid var(--font-color);height:34px!important;padding:10px!important}@media only screen and (min-width: 1600px){.ff-btn-secondary{padding:10px 15px!important;height:40px!important}}\n"] }]
        }], propDecorators: { buttonType: [{
                type: Input
            }], buttonSize: [{
                type: Input
            }], customId: [{
                type: Input
            }], buttonClass: [{
                type: Input
            }], isDisabled: [{
                type: Input
            }], tooltip: [{
                type: Input
            }], buttonClicked: [{
                type: Output
            }] } });

/**
 * ButtonsComponent is a reusable component that represents a button with different styles and sizes.
 * It supports various customization options such as button type, size, additional classes, and disabled state.
 *
 * Usage:
 *
 * <app-buttons
 *   [buttonType]="'fill' | 'stroked' | 'secondary'"
 *   [buttonSize]="'medium' | 'large'"
 *   [buttonClass]="customButtonClass"
 *   [isDisabled]="disabledState"
 *   [tooltip]="tooltipText"
 *   (buttonClicked)="handleButtonClick()"
 * >
 *   Button Text
 * </app-buttons>
 *
 * @example
 *
 * <app-buttons
 *   buttonType="fill"
 *   buttonSize="large"
 *   buttonClass="custom-class"
 *   isDisabled="false"
 *   tooltip="Click me!"
 *   (buttonClicked)="handleButtonClick()"
 * >
 *   Button Text
 * </app-buttons>
 *
 */

class ActionButtonsComponent {
    constructor() {
        this.buttonsClicked = new EventEmitter();
    }
    buttonNavigation(type) {
        this.buttonsClicked.next(type);
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "16.2.12", ngImport: i0, type: ActionButtonsComponent, deps: [], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "16.2.12", type: ActionButtonsComponent, isStandalone: true, selector: "app-action-buttons", inputs: { buttonNextState: "buttonNextState", buttonPrevText: "buttonPrevText", customId: "customId" }, outputs: { buttonsClicked: "buttonsClicked" }, ngImport: i0, template: `
    <section class="action-section">
      <app-buttons
        buttonType="stroked"
        customId="backButton"
        (buttonClicked)="buttonNavigation('prev')"
      >
        {{ buttonPrevText ? buttonPrevText : 'Back' }}
      </app-buttons>
      <app-buttons
        buttonType="fill"
        [isDisabled]="buttonNextState.disabled"
        [customId]="customId"
        (buttonClicked)="buttonNavigation('next')"
      >
        {{ buttonNextState.buttonText }}
      </app-buttons>
    </section>
  `, isInline: true, styles: [".action-section{display:flex;align-items:center;justify-content:space-between;width:100%;margin-top:25px}\n"], dependencies: [{ kind: "ngmodule", type: CommonModule }, { kind: "component", type: ButtonsComponent, selector: "app-buttons", inputs: ["buttonType", "buttonSize", "customId", "buttonClass", "isDisabled", "tooltip"], outputs: ["buttonClicked"] }] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "16.2.12", ngImport: i0, type: ActionButtonsComponent, decorators: [{
            type: Component,
            args: [{ selector: 'app-action-buttons', standalone: true, imports: [CommonModule, ButtonsComponent], template: `
    <section class="action-section">
      <app-buttons
        buttonType="stroked"
        customId="backButton"
        (buttonClicked)="buttonNavigation('prev')"
      >
        {{ buttonPrevText ? buttonPrevText : 'Back' }}
      </app-buttons>
      <app-buttons
        buttonType="fill"
        [isDisabled]="buttonNextState.disabled"
        [customId]="customId"
        (buttonClicked)="buttonNavigation('next')"
      >
        {{ buttonNextState.buttonText }}
      </app-buttons>
    </section>
  `, styles: [".action-section{display:flex;align-items:center;justify-content:space-between;width:100%;margin-top:25px}\n"] }]
        }], propDecorators: { buttonNextState: [{
                type: Input
            }], buttonPrevText: [{
                type: Input
            }], customId: [{
                type: Input
            }], buttonsClicked: [{
                type: Output
            }] } });

class SortCustomComponent {
    ngOnChanges() {
    }
    logParams() {
        // console.log(this.filterValues,this.columnName,'fff');
        // console.log((this.filterValues?.orderBy === 'asc'&& this.filterValues?.sortBy===this.columnName)?'active':'inactive','Up');
        // console.log((this.filterValues?.orderBy === 'desc'&& this.filterValues?.sortBy===this.columnName)?'active':'inactive','down');
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "16.2.12", ngImport: i0, type: SortCustomComponent, deps: [], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "16.2.12", type: SortCustomComponent, isStandalone: true, selector: "app-sort-custom", inputs: { filterValues: "filterValues", columnName: "columnName" }, usesOnChanges: true, ngImport: i0, template: "<article class=\"sort-wrap ff-flex-align-center flex-column\" >\n    <span class=\"arrow-up\" (click)=\"logParams()\"\n        [ngClass]=\"(filterValues?.orderBy === 'asc'&& filterValues?.sortBy===columnName)?'active':'inactive'\" id=\"arrowUp\"></span>\n    <span class=\"arrow-down\" (click)=\"logParams()\"\n        [ngClass]=\"(filterValues?.orderBy === 'desc'&& filterValues?.sortBy===columnName)?'active':'inactive'\" id=\"arrowDown\"></span>\n</article>", styles: [".sort-wrap{margin-left:10px}.sort-wrap .arrow-down,.sort-wrap .arrow-up{width:0;height:0;border-left:6px solid transparent;border-right:6px solid transparent}.sort-wrap .arrow-up{border-bottom:6px solid;margin-bottom:2px}.sort-wrap .arrow-up.active{border-bottom-color:var(--font-color)}.sort-wrap .arrow-up.inactive{border-bottom-color:var(--color-sort-inactive)}.sort-wrap .arrow-down{border-top:6px solid}.sort-wrap .arrow-down.active{border-top-color:var(--font-color)}.sort-wrap .arrow-down.inactive{border-top-color:var(--color-sort-inactive)}\n"], dependencies: [{ kind: "ngmodule", type: CommonModule }, { kind: "directive", type: i1.NgClass, selector: "[ngClass]", inputs: ["class", "ngClass"] }] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "16.2.12", ngImport: i0, type: SortCustomComponent, decorators: [{
            type: Component,
            args: [{ selector: 'app-sort-custom', standalone: true, imports: [CommonModule], template: "<article class=\"sort-wrap ff-flex-align-center flex-column\" >\n    <span class=\"arrow-up\" (click)=\"logParams()\"\n        [ngClass]=\"(filterValues?.orderBy === 'asc'&& filterValues?.sortBy===columnName)?'active':'inactive'\" id=\"arrowUp\"></span>\n    <span class=\"arrow-down\" (click)=\"logParams()\"\n        [ngClass]=\"(filterValues?.orderBy === 'desc'&& filterValues?.sortBy===columnName)?'active':'inactive'\" id=\"arrowDown\"></span>\n</article>", styles: [".sort-wrap{margin-left:10px}.sort-wrap .arrow-down,.sort-wrap .arrow-up{width:0;height:0;border-left:6px solid transparent;border-right:6px solid transparent}.sort-wrap .arrow-up{border-bottom:6px solid;margin-bottom:2px}.sort-wrap .arrow-up.active{border-bottom-color:var(--font-color)}.sort-wrap .arrow-up.inactive{border-bottom-color:var(--color-sort-inactive)}.sort-wrap .arrow-down{border-top:6px solid}.sort-wrap .arrow-down.active{border-top-color:var(--font-color)}.sort-wrap .arrow-down.inactive{border-top-color:var(--color-sort-inactive)}\n"] }]
        }], propDecorators: { filterValues: [{
                type: Input
            }], columnName: [{
                type: Input
            }] } });

var LoaderType;
(function (LoaderType) {
    LoaderType["Type1"] = "type1";
    LoaderType["Type2"] = "type2";
    LoaderType["Default"] = "default";
})(LoaderType || (LoaderType = {}));
class LoaderComponent {
    constructor() {
        this.loaderType = LoaderType.Default;
        this.LoaderType = LoaderType;
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "16.2.12", ngImport: i0, type: LoaderComponent, deps: [], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "16.2.12", type: LoaderComponent, isStandalone: true, selector: "app-loader", inputs: { loaderText: "loaderText", noText: "noText", loaderType: "loaderType" }, ngImport: i0, template: "<section class=\"loader-wrapper\">\n    <ng-container *ngIf=\"loaderType === LoaderType.Default\">\n        <!-- Default loader SVG code -->\n        <svg class=\"size-60\" xmlns=\"http://www.w3.org/2000/svg\" xmlns:xlink=\"http://www.w3.org/1999/xlink\" width=\"144px\"\n            height=\"144px\" viewBox=\"10 0 80 80\" preserveAspectRatio=\"xMidYMid\">\n            <circle cx=\"50\" cy=\"50\" r=\"18\" class=\"circle1\" stroke-width=\"2\" fill=\"none\"></circle>\n            <circle cx=\"50\" cy=\"50\" r=\"18\" class=\"circle2\" stroke-width=\"4\" stroke-linecap=\"round\" fill=\"none\"\n                transform=\"rotate(12.575 50 50)\">\n                <animateTransform attributeName=\"transform\" type=\"rotate\" repeatCount=\"indefinite\"\n                    dur=\"1.7241379310344827s\" values=\"0 50 50;180 50 50;720 50 50\" keyTimes=\"0;0.5;1\">\n                </animateTransform>\n                <animate attributeName=\"stroke-dasharray\" repeatCount=\"indefinite\" dur=\"1.7241379310344827s\"\n                    values=\"11.309733552923255 101.7876019763093;56.548667764616276 56.548667764616276;11.309733552923255 101.7876019763093\"\n                    keyTimes=\"0;0.5;1\"></animate>\n            </circle>\n        </svg>\n    </ng-container>\n\n    <ng-container *ngIf=\"loaderType === LoaderType.Type1\">\n        <!-- Type 1 loader SVG code -->\n        <svg height=\"200\" width=\"200\">\n            <circle id=\"c1\" cx=\"100\" cy=\"100\" r=\"30\" stroke=\"#4dcaf4\" stroke-width=\"5\" fill=\"transparent\" />\n        </svg>\n    </ng-container>\n\n    <ng-container *ngIf=\"loaderType === LoaderType.Type2\">\n        <!-- Type 2 loader its type 1 and smaller SVG code -->\n        <svg height=\"60\" width=\"60\">\n            <circle id=\"c1\" cx=\"30\" cy=\"30\" r=\"20\" stroke=\"#4dcaf4\" stroke-width=\"5\" fill=\"transparent\" />\n        </svg>\n    </ng-container>\n\n    <ng-container *ngIf=\"!noText\">\n        <span class=\"paragraph1\">{{ loaderText }}...</span>\n    </ng-container>\n</section>\n", styles: [".circle1{stroke:var(--color-primary-1)}.circle2{stroke:var(--color-secondary)}.loader-wrapper{display:flex;align-items:center;justify-content:center;flex-direction:column;padding-bottom:20px}#c1{stroke-dasharray:20;stroke-dashoffset:500;animation:loading2 2s ease infinite;-webkit-animation:loading2 2s ease infinite}@keyframes loading2{to{stroke-dashoffset:0}}#c2{stroke-dasharray:80;stroke-dashoffset:500;animation:loading3 2s linear infinite;-webkit-animation:loading3 2s linear infinite}@keyframes loading3{to{stroke-dashoffset:0}}#c3{stroke-dasharray:20;stroke-dashoffset:200;animation:loading4 2s linear infinite;-webkit-animation:loading4 2s linear infinite}@keyframes loading4{to{stroke-dashoffset:0}}\n"], dependencies: [{ kind: "ngmodule", type: CommonModule }, { kind: "directive", type: i1.NgIf, selector: "[ngIf]", inputs: ["ngIf", "ngIfThen", "ngIfElse"] }] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "16.2.12", ngImport: i0, type: LoaderComponent, decorators: [{
            type: Component,
            args: [{ selector: 'app-loader', standalone: true, imports: [CommonModule], template: "<section class=\"loader-wrapper\">\n    <ng-container *ngIf=\"loaderType === LoaderType.Default\">\n        <!-- Default loader SVG code -->\n        <svg class=\"size-60\" xmlns=\"http://www.w3.org/2000/svg\" xmlns:xlink=\"http://www.w3.org/1999/xlink\" width=\"144px\"\n            height=\"144px\" viewBox=\"10 0 80 80\" preserveAspectRatio=\"xMidYMid\">\n            <circle cx=\"50\" cy=\"50\" r=\"18\" class=\"circle1\" stroke-width=\"2\" fill=\"none\"></circle>\n            <circle cx=\"50\" cy=\"50\" r=\"18\" class=\"circle2\" stroke-width=\"4\" stroke-linecap=\"round\" fill=\"none\"\n                transform=\"rotate(12.575 50 50)\">\n                <animateTransform attributeName=\"transform\" type=\"rotate\" repeatCount=\"indefinite\"\n                    dur=\"1.7241379310344827s\" values=\"0 50 50;180 50 50;720 50 50\" keyTimes=\"0;0.5;1\">\n                </animateTransform>\n                <animate attributeName=\"stroke-dasharray\" repeatCount=\"indefinite\" dur=\"1.7241379310344827s\"\n                    values=\"11.309733552923255 101.7876019763093;56.548667764616276 56.548667764616276;11.309733552923255 101.7876019763093\"\n                    keyTimes=\"0;0.5;1\"></animate>\n            </circle>\n        </svg>\n    </ng-container>\n\n    <ng-container *ngIf=\"loaderType === LoaderType.Type1\">\n        <!-- Type 1 loader SVG code -->\n        <svg height=\"200\" width=\"200\">\n            <circle id=\"c1\" cx=\"100\" cy=\"100\" r=\"30\" stroke=\"#4dcaf4\" stroke-width=\"5\" fill=\"transparent\" />\n        </svg>\n    </ng-container>\n\n    <ng-container *ngIf=\"loaderType === LoaderType.Type2\">\n        <!-- Type 2 loader its type 1 and smaller SVG code -->\n        <svg height=\"60\" width=\"60\">\n            <circle id=\"c1\" cx=\"30\" cy=\"30\" r=\"20\" stroke=\"#4dcaf4\" stroke-width=\"5\" fill=\"transparent\" />\n        </svg>\n    </ng-container>\n\n    <ng-container *ngIf=\"!noText\">\n        <span class=\"paragraph1\">{{ loaderText }}...</span>\n    </ng-container>\n</section>\n", styles: [".circle1{stroke:var(--color-primary-1)}.circle2{stroke:var(--color-secondary)}.loader-wrapper{display:flex;align-items:center;justify-content:center;flex-direction:column;padding-bottom:20px}#c1{stroke-dasharray:20;stroke-dashoffset:500;animation:loading2 2s ease infinite;-webkit-animation:loading2 2s ease infinite}@keyframes loading2{to{stroke-dashoffset:0}}#c2{stroke-dasharray:80;stroke-dashoffset:500;animation:loading3 2s linear infinite;-webkit-animation:loading3 2s linear infinite}@keyframes loading3{to{stroke-dashoffset:0}}#c3{stroke-dasharray:20;stroke-dashoffset:200;animation:loading4 2s linear infinite;-webkit-animation:loading4 2s linear infinite}@keyframes loading4{to{stroke-dashoffset:0}}\n"] }]
        }], propDecorators: { loaderText: [{
                type: Input
            }], noText: [{
                type: Input
            }], loaderType: [{
                type: Input
            }] } });

/**
 * @component LoaderComponent
 * @description
 *   The `LoaderComponent` is a reusable Angular component that displays a loader with customizable text and styles.
 *   It can be used to indicate loading or processing states in an Angular application.
 *
 * @usage
 *   ```
 *   <app-loader
 *     [loaderText]="loadingText"
 *     [noText]="hideText"
 *     [loaderType]="selectedLoaderType"
 *   ></app-loader>
 *   ```
 *
 * @inputs
 *   - `loaderText` (string): The text to display alongside the loader. (Optional)
 *   - `noText` (boolean): Determines whether to hide the loader text. Defaults to `false`. (Optional)
 *   - `loaderType` (string): The type of loader to display. Possible values are `LoaderType.Type1`, `LoaderType.Type2`, `LoaderType.Type3`, and `LoaderType.Default`. Defaults to `LoaderType.Default`. (Optional)
 *
 * @enums
 *   - `LoaderType`: An enumeration that represents the available loader types.
 *     - `Type1`: Type 1 loader style.
 *     - `Type2`: Type 2 loader style.
 *     - `Type3`: Type 3 loader style.
 *     - `Default`: Default loader style.
 *
 * @example
 *   ```typescript
 *   import { Component } from '@angular/core';
 *
 *   @Component({
 *     selector: 'app-example',
 *     template: `
 *       <app-loader
 *         [loaderText]="'Loading...'"
 *         [noText]="false"
 *         [loaderType]="LoaderType.Type1"
 *       ></app-loader>
 *     `,
 *   })
 *   export class ExampleComponent {
 *     readonly LoaderType = LoaderType;
 *   }
 *   ```
 *
 * @styles
 *   The `LoaderComponent` applies the following CSS classes:
 *   - `.loader-container`: The main container of the loader component.
 *   - `.loader-text`: The CSS class for the loader text.
 *   - `.circle1`, `.circle2`: Applied to customize the colors of the circles in the loader SVG code.
 *   - `.loader-wrapper`: The CSS class for the wrapper element of the loader component.
 *
 * @dependencies
 *   This component requires the following Angular modules and dependencies to be imported:
 *   - `@angular/core`: Angular core module.
 *   - `@angular/common`: Angular common module.
 *
 * @version 1.0.0
 */

/* eslint-disable @typescript-eslint/no-explicit-any */
class FairFoodCustomTabComponent {
    constructor() {
        this.tabChanged = new EventEmitter();
    }
    ngOnChanges(changes) {
        const { tabGroupItems } = changes;
        if (tabGroupItems) {
            this.tabList = JSON.parse(JSON.stringify(tabGroupItems.currentValue));
        }
    }
    changeTab(tabItem) {
        if (this.withDescription) {
            tabItem.active ? this.tabChanged.emit(tabItem) : console.log('Disabled');
        }
        else {
            this.tabChanged.emit(tabItem);
        }
    }
    addTab(item) {
        const found = this.tabList.findIndex(t => t.id === item.id);
        if (found !== -1) {
            item.selected = false;
            this.tabList.splice(found, 1);
            this.activeTabId = this.tabList[0].id;
            this.tabChanged.emit(this.tabList[0]);
        }
        else {
            item.selected = true;
            this.tabList.push(item);
        }
    }
    trackByFn(index) {
        return index;
    }
    ngOnDestroy() {
        this.moreTabs = [];
        this.tabGroupItems = [];
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "16.2.12", ngImport: i0, type: FairFoodCustomTabComponent, deps: [], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "16.2.12", type: FairFoodCustomTabComponent, isStandalone: true, selector: "app-ff-custom-tab", inputs: { tabGroupItems: "tabGroupItems", activeTabId: "activeTabId", moreTabs: "moreTabs", withDescription: "withDescription" }, outputs: { tabChanged: "tabChanged" }, usesOnChanges: true, ngImport: i0, template: "<ul class=\"tab-group ff-flex-start\" [class.border-tab]=\"withDescription\">\n    <!-- stock process tab contains state. So it should be handled seperately -->\n    <ng-container *ngIf=\"!withDescription; else withDescriptionTabs\">\n        <ng-container *ngFor=\"let tr of tabList; trackBy: trackByFn; let i = index\">\n            <li class=\"tab-item font-1-bold pointer\" [ngClass]=\"activeTabId === tr.id? 'active': ''\"\n                (click)=\"changeTab(tr)\" id=\"tabItem-{{i}}\">\n                {{tr?.name}}\n            </li>\n        </ng-container>\n        <li class=\"tab-item font-1-bold pointer\" [matMenuTriggerFor]=\"moreTabsMenu\" *ngIf=\"moreTabs?.length\"\n            id=\"moreButton\">\n            More <mat-icon>keyboard_arrow_down</mat-icon>\n        </li>\n        <mat-menu class=\"mat-menu more-filters\" #moreTabsMenu=\"matMenu\" xPosition=\"after\">\n            <ul *ngIf=\"moreTabs?.length\" (click)=\"$event.stopPropagation()\">\n                <li *ngFor=\"let item of moreTabs; trackBy: trackByFn; let j=index\">\n                    <mat-checkbox class=\"w-100\" [checked]=\"item.selected\"\n                        (click)=\"addTab(item)\" id=\"check{{j}}\">{{item.name}}</mat-checkbox>\n                </li>\n            </ul>\n        </mat-menu>\n    </ng-container>\n\n    <ng-template #withDescriptionTabs>\n        <ng-container *ngFor=\"let ta of tabList; trackBy: trackByFn; let i = index\">\n            <li class=\"tab-item font-1-bold pointer no-left-p\" [ngClass]=\"activeTabId === ta.id? 'active': ''\"\n                (click)=\"changeTab(ta)\" id=\"withDescription-{{i}}\">\n                <mat-icon [ngClass]=\"ta?.active ? 'set-primary': 'set-disabled'\">check_circle</mat-icon>\n                <aside class=\"details\" [class.disabled-details]=\"!ta.active\">\n                    <span>{{ta?.name}}</span>\n                    <p *ngIf=\"ta?.description\">{{ta?.description}}</p>\n                </aside>\n            </li>\n        </ng-container>\n    </ng-template>\n\n</ul>", styles: ["::ng-deep .more-filters .mat-mdc-menu-content{padding:15px;width:210px}::ng-deep .more-filters .mat-mdc-menu-content ul{list-style:none;padding:0;margin:0}::ng-deep .more-filters .mat-mdc-menu-content ul li{padding:5px 3px;color:var(--font-color);font-family:var(--font-regular);font-size:14px}ul{list-style:none;margin:0}.tab-group{padding:0;margin-bottom:-7px;overflow-x:auto}.tab-group.border-tab{border-bottom:1px solid var(--border-color)}.tab-group::-webkit-scrollbar{width:10px;height:8px}.tab-group::-webkit-scrollbar-track{border-radius:2px}.tab-group::-webkit-scrollbar-thumb{border-radius:3px;background-color:var(--color-scrollbar)}.tab-group .tab-item{font-size:14px;color:var(--font-color);padding:20px;display:flex;align-items:center;justify-content:center;white-space:nowrap}@media only screen and (min-width: 1600px){.tab-group .tab-item{font-size:16px}}.tab-group .tab-item.active{border-bottom:5px solid var(--color-primary-2);transition:all .3s linear;padding:15px 20px}.tab-group .tab-item.no-left-p{padding-left:0;padding-bottom:10px}.tab-group .tab-item .details{display:flex;flex-direction:column;padding-left:15px}.tab-group .tab-item .details.disabled-details{color:var(--color-disabled)}.tab-group .tab-item .details p{font-family:var(--font-regular);font-size:12px;color:var(--font-color-2);margin:0}.tab-group .tab-item .set-primary{color:var(--font-color-2)}.tab-group .tab-item .set-disabled{color:var(--border-color)}\n"], dependencies: [{ kind: "ngmodule", type: CommonModule }, { kind: "directive", type: i1.NgClass, selector: "[ngClass]", inputs: ["class", "ngClass"] }, { kind: "directive", type: i1.NgForOf, selector: "[ngFor][ngForOf]", inputs: ["ngForOf", "ngForTrackBy", "ngForTemplate"] }, { kind: "directive", type: i1.NgIf, selector: "[ngIf]", inputs: ["ngIf", "ngIfThen", "ngIfElse"] }, { kind: "ngmodule", type: MatIconModule }, { kind: "component", type: i2.MatIcon, selector: "mat-icon", inputs: ["color", "inline", "svgIcon", "fontSet", "fontIcon"], exportAs: ["matIcon"] }, { kind: "ngmodule", type: MatMenuModule }, { kind: "component", type: i2$1.MatMenu, selector: "mat-menu", exportAs: ["matMenu"] }, { kind: "directive", type: i2$1.MatMenuTrigger, selector: "[mat-menu-trigger-for], [matMenuTriggerFor]", exportAs: ["matMenuTrigger"] }, { kind: "ngmodule", type: MatCheckboxModule }, { kind: "component", type: i4.MatCheckbox, selector: "mat-checkbox", inputs: ["disableRipple", "color", "tabIndex"], exportAs: ["matCheckbox"] }] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "16.2.12", ngImport: i0, type: FairFoodCustomTabComponent, decorators: [{
            type: Component,
            args: [{ selector: 'app-ff-custom-tab', standalone: true, imports: [CommonModule, MatIconModule, MatMenuModule, MatCheckboxModule], template: "<ul class=\"tab-group ff-flex-start\" [class.border-tab]=\"withDescription\">\n    <!-- stock process tab contains state. So it should be handled seperately -->\n    <ng-container *ngIf=\"!withDescription; else withDescriptionTabs\">\n        <ng-container *ngFor=\"let tr of tabList; trackBy: trackByFn; let i = index\">\n            <li class=\"tab-item font-1-bold pointer\" [ngClass]=\"activeTabId === tr.id? 'active': ''\"\n                (click)=\"changeTab(tr)\" id=\"tabItem-{{i}}\">\n                {{tr?.name}}\n            </li>\n        </ng-container>\n        <li class=\"tab-item font-1-bold pointer\" [matMenuTriggerFor]=\"moreTabsMenu\" *ngIf=\"moreTabs?.length\"\n            id=\"moreButton\">\n            More <mat-icon>keyboard_arrow_down</mat-icon>\n        </li>\n        <mat-menu class=\"mat-menu more-filters\" #moreTabsMenu=\"matMenu\" xPosition=\"after\">\n            <ul *ngIf=\"moreTabs?.length\" (click)=\"$event.stopPropagation()\">\n                <li *ngFor=\"let item of moreTabs; trackBy: trackByFn; let j=index\">\n                    <mat-checkbox class=\"w-100\" [checked]=\"item.selected\"\n                        (click)=\"addTab(item)\" id=\"check{{j}}\">{{item.name}}</mat-checkbox>\n                </li>\n            </ul>\n        </mat-menu>\n    </ng-container>\n\n    <ng-template #withDescriptionTabs>\n        <ng-container *ngFor=\"let ta of tabList; trackBy: trackByFn; let i = index\">\n            <li class=\"tab-item font-1-bold pointer no-left-p\" [ngClass]=\"activeTabId === ta.id? 'active': ''\"\n                (click)=\"changeTab(ta)\" id=\"withDescription-{{i}}\">\n                <mat-icon [ngClass]=\"ta?.active ? 'set-primary': 'set-disabled'\">check_circle</mat-icon>\n                <aside class=\"details\" [class.disabled-details]=\"!ta.active\">\n                    <span>{{ta?.name}}</span>\n                    <p *ngIf=\"ta?.description\">{{ta?.description}}</p>\n                </aside>\n            </li>\n        </ng-container>\n    </ng-template>\n\n</ul>", styles: ["::ng-deep .more-filters .mat-mdc-menu-content{padding:15px;width:210px}::ng-deep .more-filters .mat-mdc-menu-content ul{list-style:none;padding:0;margin:0}::ng-deep .more-filters .mat-mdc-menu-content ul li{padding:5px 3px;color:var(--font-color);font-family:var(--font-regular);font-size:14px}ul{list-style:none;margin:0}.tab-group{padding:0;margin-bottom:-7px;overflow-x:auto}.tab-group.border-tab{border-bottom:1px solid var(--border-color)}.tab-group::-webkit-scrollbar{width:10px;height:8px}.tab-group::-webkit-scrollbar-track{border-radius:2px}.tab-group::-webkit-scrollbar-thumb{border-radius:3px;background-color:var(--color-scrollbar)}.tab-group .tab-item{font-size:14px;color:var(--font-color);padding:20px;display:flex;align-items:center;justify-content:center;white-space:nowrap}@media only screen and (min-width: 1600px){.tab-group .tab-item{font-size:16px}}.tab-group .tab-item.active{border-bottom:5px solid var(--color-primary-2);transition:all .3s linear;padding:15px 20px}.tab-group .tab-item.no-left-p{padding-left:0;padding-bottom:10px}.tab-group .tab-item .details{display:flex;flex-direction:column;padding-left:15px}.tab-group .tab-item .details.disabled-details{color:var(--color-disabled)}.tab-group .tab-item .details p{font-family:var(--font-regular);font-size:12px;color:var(--font-color-2);margin:0}.tab-group .tab-item .set-primary{color:var(--font-color-2)}.tab-group .tab-item .set-disabled{color:var(--border-color)}\n"] }]
        }], propDecorators: { tabGroupItems: [{
                type: Input
            }], activeTabId: [{
                type: Input
            }], moreTabs: [{
                type: Input
            }], withDescription: [{
                type: Input
            }], tabChanged: [{
                type: Output
            }] } });

/* eslint-disable @typescript-eslint/no-explicit-any */
class FfPaginationComponent {
    constructor() {
        this.hidePageSize = false;
        this.defaultPageSize = 10;
        this.paginationAction = new EventEmitter();
    }
    /**
     * This method is called when there are changes in the input properties.
     * It adjusts the paginator's pageSize and pageIndex if customPageSize is provided.
     * @param changes - The changes in input properties.
     */
    ngOnChanges(changes) {
        const { customPageSize } = changes;
        if (customPageSize?.currentValue && this.paginator) {
            this.paginator.pageSize = customPageSize.currentValue.limit;
            this.paginator.pageIndex = customPageSize.currentValue.offset;
        }
    }
    /**
     * Get the page size options based on the totalCount.
     * @returns An array of page size options.
     */
    getPageSizeOptions() {
        if (this.totalCount > 20) {
            return [10, 20, 50];
        }
        else {
            return [10, 20];
        }
    }
    /**
     * Handles the page event emitted by the paginator.
     * @param e - The page event.
     */
    pageEvent(e) {
        e.length = this.defaultPageSize;
        this.paginator.pageSize = e?.pageSize || this.defaultPageSize;
        this.paginationAction.emit({
            limit: this.paginator.pageSize,
            offset: this.paginator.pageIndex * this.paginator.pageSize,
            type: 'page',
        });
    }
    /**
     * Sets the page size and resets pageIndex to 0.
     * @param pageSize - The selected page size.
     */
    pageSizeSetter(pageSize) {
        this.paginator.pageIndex = 0;
        this.paginator.pageSize = pageSize;
        this.paginationAction.emit({
            limit: this.paginator.pageSize,
            offset: 0,
            type: 'perPage',
        });
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "16.2.12", ngImport: i0, type: FfPaginationComponent, deps: [], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "16.2.12", type: FfPaginationComponent, isStandalone: true, selector: "app-ff-pagination", inputs: { totalCount: "totalCount", customPageSize: "customPageSize", hidePageSize: "hidePageSize", defaultPageSize: "defaultPageSize" }, outputs: { paginationAction: "paginationAction" }, viewQueries: [{ propertyName: "paginator", first: true, predicate: MatPaginator, descendants: true }], usesOnChanges: true, ngImport: i0, template: "<aside aria-label=\"paginator wrapper\" class=\"ff-flex-between custom-style-paginator-select\">\n    <article class=\"per-page-wrapper\" *ngIf=\"!hidePageSize\">\n        <span class=\"custom-text\">\n            Items per page: &nbsp;\n        </span>\n        <aside aria-label=\"custom material pagesize dropdown\" class=\"page-size-dropdown pointer\"\n            [matMenuTriggerFor]=\"pageSizeMenu\" id=\"pageSize\">\n            {{(paginator?.pageSize || defaultPageSize)}} <mat-icon>keyboard_arrow_down</mat-icon>\n        </aside>\n        <mat-menu class=\"mat-menu\" #pageSizeMenu=\"matMenu\" xPosition=\"after\">\n            <ul class=\"dropdown-page\">\n                <li *ngFor=\"let item of getPageSizeOptions()\" (click)=\"pageSizeSetter(item)\" id=\"page{{item}}\">\n                    {{item}}\n                </li>\n            </ul>\n        </mat-menu>\n    </article>\n\n    <mat-paginator [length]=\"totalCount\" [pageSize]=\"defaultPageSize\" [hidePageSize]=\"true\" (page)=\"pageEvent($event)\">\n    </mat-paginator>\n</aside>", styles: ["::ng-deep .mat-mdc-paginator-page-size{position:relative;right:80px}::ng-deep .mat-mdc-paginator-page-size .mat-form-field-appearance-legacy .mat-form-field-infix{padding-bottom:2px!important;color:var(--color-secondary)}.mat-mdc-paginator-range-label{margin-right:45px}::ng-deep .mat-mdc-paginator .mat-mdc-paginator-navigation-previous{right:110px;margin-left:0}::ng-deep .mat-mdc-paginator .mat-mdc-paginator-navigation-next{right:17px}::ng-deep .mat-mdc-paginator .mat-mdc-paginator-range-label{height:40px;position:absolute;margin-right:0;display:flex;align-items:center;justify-content:center;right:86px;color:var(--font-color);font-size:14px;font-family:var(--font-regular);line-height:0px;top:auto}ul{list-style:none;margin:0}.custom-style-paginator-select{margin-top:10px;position:relative}@media only screen and (min-width: 992px){.custom-style-paginator-select{justify-content:flex-end}}.dropdown-page{list-style:none;padding-left:10px;margin:0}.dropdown-page li{padding:4px;cursor:pointer}.page-size-dropdown{border-radius:6px;border:1px solid var(--border-color);padding:4px 12px;color:var(--font-color);min-width:100px;display:flex;justify-content:space-between}.per-page-wrapper{display:flex;align-items:center}@media only screen and (min-width: 992px){.per-page-wrapper{position:relative;right:8vw}}\n"], dependencies: [{ kind: "ngmodule", type: CommonModule }, { kind: "directive", type: i1.NgForOf, selector: "[ngFor][ngForOf]", inputs: ["ngForOf", "ngForTrackBy", "ngForTemplate"] }, { kind: "directive", type: i1.NgIf, selector: "[ngIf]", inputs: ["ngIf", "ngIfThen", "ngIfElse"] }, { kind: "ngmodule", type: MatMenuModule }, { kind: "component", type: i2$1.MatMenu, selector: "mat-menu", exportAs: ["matMenu"] }, { kind: "directive", type: i2$1.MatMenuTrigger, selector: "[mat-menu-trigger-for], [matMenuTriggerFor]", exportAs: ["matMenuTrigger"] }, { kind: "ngmodule", type: MatPaginatorModule }, { kind: "component", type: i3.MatPaginator, selector: "mat-paginator", inputs: ["disabled"], exportAs: ["matPaginator"] }, { kind: "ngmodule", type: MatIconModule }, { kind: "component", type: i2.MatIcon, selector: "mat-icon", inputs: ["color", "inline", "svgIcon", "fontSet", "fontIcon"], exportAs: ["matIcon"] }] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "16.2.12", ngImport: i0, type: FfPaginationComponent, decorators: [{
            type: Component,
            args: [{ selector: 'app-ff-pagination', standalone: true, imports: [CommonModule, MatMenuModule, MatPaginatorModule, MatIconModule], template: "<aside aria-label=\"paginator wrapper\" class=\"ff-flex-between custom-style-paginator-select\">\n    <article class=\"per-page-wrapper\" *ngIf=\"!hidePageSize\">\n        <span class=\"custom-text\">\n            Items per page: &nbsp;\n        </span>\n        <aside aria-label=\"custom material pagesize dropdown\" class=\"page-size-dropdown pointer\"\n            [matMenuTriggerFor]=\"pageSizeMenu\" id=\"pageSize\">\n            {{(paginator?.pageSize || defaultPageSize)}} <mat-icon>keyboard_arrow_down</mat-icon>\n        </aside>\n        <mat-menu class=\"mat-menu\" #pageSizeMenu=\"matMenu\" xPosition=\"after\">\n            <ul class=\"dropdown-page\">\n                <li *ngFor=\"let item of getPageSizeOptions()\" (click)=\"pageSizeSetter(item)\" id=\"page{{item}}\">\n                    {{item}}\n                </li>\n            </ul>\n        </mat-menu>\n    </article>\n\n    <mat-paginator [length]=\"totalCount\" [pageSize]=\"defaultPageSize\" [hidePageSize]=\"true\" (page)=\"pageEvent($event)\">\n    </mat-paginator>\n</aside>", styles: ["::ng-deep .mat-mdc-paginator-page-size{position:relative;right:80px}::ng-deep .mat-mdc-paginator-page-size .mat-form-field-appearance-legacy .mat-form-field-infix{padding-bottom:2px!important;color:var(--color-secondary)}.mat-mdc-paginator-range-label{margin-right:45px}::ng-deep .mat-mdc-paginator .mat-mdc-paginator-navigation-previous{right:110px;margin-left:0}::ng-deep .mat-mdc-paginator .mat-mdc-paginator-navigation-next{right:17px}::ng-deep .mat-mdc-paginator .mat-mdc-paginator-range-label{height:40px;position:absolute;margin-right:0;display:flex;align-items:center;justify-content:center;right:86px;color:var(--font-color);font-size:14px;font-family:var(--font-regular);line-height:0px;top:auto}ul{list-style:none;margin:0}.custom-style-paginator-select{margin-top:10px;position:relative}@media only screen and (min-width: 992px){.custom-style-paginator-select{justify-content:flex-end}}.dropdown-page{list-style:none;padding-left:10px;margin:0}.dropdown-page li{padding:4px;cursor:pointer}.page-size-dropdown{border-radius:6px;border:1px solid var(--border-color);padding:4px 12px;color:var(--font-color);min-width:100px;display:flex;justify-content:space-between}.per-page-wrapper{display:flex;align-items:center}@media only screen and (min-width: 992px){.per-page-wrapper{position:relative;right:8vw}}\n"] }]
        }], propDecorators: { paginator: [{
                type: ViewChild,
                args: [MatPaginator]
            }], totalCount: [{
                type: Input
            }], customPageSize: [{
                type: Input
            }], hidePageSize: [{
                type: Input
            }], defaultPageSize: [{
                type: Input
            }], paginationAction: [{
                type: Output
            }] } });

class CustomPaginatorComponent {
    constructor() {
        this.totalCount = 0;
        this.pageSize = 10;
        this.currentPage = 1;
        this.pageChange = new EventEmitter(); // Emits the new page data
        this.totalPages = 1;
        this.previousPageIndex = 0;
    }
    ngOnChanges(changes) {
        this.calculateTotalPages();
    }
    /**
     * Calculate total pages based on totalCount and pageSize.
     */
    calculateTotalPages() {
        this.totalPages = Math.ceil(this.totalCount / this.pageSize);
    }
    /**
     * Navigate to the previous page.
     */
    goToPreviousPage() {
        if (this.currentPage > 1) {
            const event = this.createPageEvent(this.currentPage - 2);
            this.previousPageIndex = this.currentPage - 1;
            this.currentPage--;
            this.pageChange.emit(event);
        }
    }
    /**
     * Navigate to the next page.
     */
    goToNextPage() {
        if (this.currentPage < this.totalPages) {
            const event = this.createPageEvent(this.currentPage);
            this.previousPageIndex = this.currentPage - 1;
            this.currentPage++;
            this.pageChange.emit(event);
        }
    }
    /**
     * Create the structured page event object.
     */
    createPageEvent(pageIndex) {
        return {
            previousPageIndex: this.previousPageIndex,
            pageIndex: pageIndex,
            pageSize: this.pageSize,
            length: this.totalCount,
        };
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "16.2.12", ngImport: i0, type: CustomPaginatorComponent, deps: [], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "16.2.12", type: CustomPaginatorComponent, isStandalone: true, selector: "app-custom-paginator", inputs: { totalCount: "totalCount", pageSize: "pageSize", currentPage: "currentPage" }, outputs: { pageChange: "pageChange" }, usesOnChanges: true, ngImport: i0, template: "<div class=\"custom-paginator\">\n    <!-- Previous Button -->\n    <button \n      class=\"paginator-btn\" \n      [disabled]=\"currentPage === 1\" \n      (click)=\"goToPreviousPage()\">\n      <ng-container *ngIf=\"currentPage === 1; else enabledPrevIcon\">\n        <!-- Disabled SVG for Previous -->\n        <svg width=\"32\" height=\"32\" viewBox=\"0 0 32 32\" fill=\"none\" xmlns=\"http://www.w3.org/2000/svg\">\n          <g opacity=\"0.5\">\n            <rect width=\"32\" height=\"32\" rx=\"4\" fill=\"#C4CDD5\"/>\n            <path d=\"M19.1599 11.41L14.5799 16L19.1599 20.59L17.7499 22L11.7499 16L17.7499 10L19.1599 11.41Z\" fill=\"white\"/>\n          </g>\n        </svg>\n      </ng-container>\n      <ng-template #enabledPrevIcon>\n        <!-- Enabled SVG for Previous -->\n        <svg width=\"32\" height=\"32\" viewBox=\"0 0 32 32\" fill=\"none\" xmlns=\"http://www.w3.org/2000/svg\" style=\"transform: scaleX(-1);\">\n          <rect x=\"0.5\" y=\"0.5\" width=\"31\" height=\"31\" rx=\"3.5\" fill=\"white\"/>\n          <rect x=\"0.5\" y=\"0.5\" width=\"31\" height=\"31\" rx=\"3.5\" stroke=\"#DFE3E8\"/>\n          <path d=\"M12.8401 11.41L17.4201 16L12.8401 20.59L14.2501 22L20.2501 16L14.2501 10L12.8401 11.41Z\" fill=\"#C4CDD5\"/>\n        </svg>\n      </ng-template>\n    </button>\n  \n    <!-- Page Display -->\n    <span class=\"page-info\">\n      {{ currentPage }} of {{ totalPages }}\n    </span>\n  \n    <!-- Next Button -->\n    <button \n      class=\"paginator-btn\" \n      [disabled]=\"currentPage === totalPages\" \n      (click)=\"goToNextPage()\">\n      <ng-container *ngIf=\"currentPage === totalPages; else enabledNextIcon\">\n        <!-- Disabled SVG for Next -->\n        <svg width=\"32\" height=\"32\" viewBox=\"0 0 32 32\" fill=\"none\" xmlns=\"http://www.w3.org/2000/svg\">\n          <g opacity=\"0.5\">\n            <rect width=\"32\" height=\"32\" rx=\"4\" fill=\"#C4CDD5\"/>\n            <path d=\"M12.8401 11.41L17.4201 16L12.8401 20.59L14.2501 22L20.2501 16L14.2501 10L12.8401 11.41Z\" fill=\"white\"/>\n          </g>\n        </svg>\n      </ng-container>\n      <ng-template #enabledNextIcon>\n        <!-- Enabled SVG for Next -->\n        <svg width=\"32\" height=\"32\" viewBox=\"0 0 32 32\" fill=\"none\" xmlns=\"http://www.w3.org/2000/svg\">\n          <rect x=\"0.5\" y=\"0.5\" width=\"31\" height=\"31\" rx=\"3.5\" fill=\"white\"/>\n          <rect x=\"0.5\" y=\"0.5\" width=\"31\" height=\"31\" rx=\"3.5\" stroke=\"#DFE3E8\"/>\n          <path d=\"M12.8401 11.41L17.4201 16L12.8401 20.59L14.2501 22L20.2501 16L14.2501 10L12.8401 11.41Z\" fill=\"#C4CDD5\"/>\n        </svg>\n      </ng-template>\n    </button>\n  </div>\n  ", styles: [".custom-paginator{display:flex;align-items:center;justify-content:center;gap:10px;position:absolute;right:213px;top:-7px}.custom-paginator .paginator-btn{border:none;background:none;cursor:pointer;border-radius:5px;transition:background-color .3s;margin-top:7px}.custom-paginator .paginator-btn:disabled{cursor:not-allowed;opacity:.5}.custom-paginator .paginator-btn img{width:20px;height:20px}.custom-paginator .page-info{font-size:14px;font-weight:700}@media screen and (max-width: 850px){.custom-paginator{position:relative;right:0;top:0}}\n"], dependencies: [{ kind: "ngmodule", type: CommonModule }, { kind: "directive", type: i1.NgIf, selector: "[ngIf]", inputs: ["ngIf", "ngIfThen", "ngIfElse"] }] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "16.2.12", ngImport: i0, type: CustomPaginatorComponent, decorators: [{
            type: Component,
            args: [{ selector: 'app-custom-paginator', standalone: true, imports: [CommonModule], template: "<div class=\"custom-paginator\">\n    <!-- Previous Button -->\n    <button \n      class=\"paginator-btn\" \n      [disabled]=\"currentPage === 1\" \n      (click)=\"goToPreviousPage()\">\n      <ng-container *ngIf=\"currentPage === 1; else enabledPrevIcon\">\n        <!-- Disabled SVG for Previous -->\n        <svg width=\"32\" height=\"32\" viewBox=\"0 0 32 32\" fill=\"none\" xmlns=\"http://www.w3.org/2000/svg\">\n          <g opacity=\"0.5\">\n            <rect width=\"32\" height=\"32\" rx=\"4\" fill=\"#C4CDD5\"/>\n            <path d=\"M19.1599 11.41L14.5799 16L19.1599 20.59L17.7499 22L11.7499 16L17.7499 10L19.1599 11.41Z\" fill=\"white\"/>\n          </g>\n        </svg>\n      </ng-container>\n      <ng-template #enabledPrevIcon>\n        <!-- Enabled SVG for Previous -->\n        <svg width=\"32\" height=\"32\" viewBox=\"0 0 32 32\" fill=\"none\" xmlns=\"http://www.w3.org/2000/svg\" style=\"transform: scaleX(-1);\">\n          <rect x=\"0.5\" y=\"0.5\" width=\"31\" height=\"31\" rx=\"3.5\" fill=\"white\"/>\n          <rect x=\"0.5\" y=\"0.5\" width=\"31\" height=\"31\" rx=\"3.5\" stroke=\"#DFE3E8\"/>\n          <path d=\"M12.8401 11.41L17.4201 16L12.8401 20.59L14.2501 22L20.2501 16L14.2501 10L12.8401 11.41Z\" fill=\"#C4CDD5\"/>\n        </svg>\n      </ng-template>\n    </button>\n  \n    <!-- Page Display -->\n    <span class=\"page-info\">\n      {{ currentPage }} of {{ totalPages }}\n    </span>\n  \n    <!-- Next Button -->\n    <button \n      class=\"paginator-btn\" \n      [disabled]=\"currentPage === totalPages\" \n      (click)=\"goToNextPage()\">\n      <ng-container *ngIf=\"currentPage === totalPages; else enabledNextIcon\">\n        <!-- Disabled SVG for Next -->\n        <svg width=\"32\" height=\"32\" viewBox=\"0 0 32 32\" fill=\"none\" xmlns=\"http://www.w3.org/2000/svg\">\n          <g opacity=\"0.5\">\n            <rect width=\"32\" height=\"32\" rx=\"4\" fill=\"#C4CDD5\"/>\n            <path d=\"M12.8401 11.41L17.4201 16L12.8401 20.59L14.2501 22L20.2501 16L14.2501 10L12.8401 11.41Z\" fill=\"white\"/>\n          </g>\n        </svg>\n      </ng-container>\n      <ng-template #enabledNextIcon>\n        <!-- Enabled SVG for Next -->\n        <svg width=\"32\" height=\"32\" viewBox=\"0 0 32 32\" fill=\"none\" xmlns=\"http://www.w3.org/2000/svg\">\n          <rect x=\"0.5\" y=\"0.5\" width=\"31\" height=\"31\" rx=\"3.5\" fill=\"white\"/>\n          <rect x=\"0.5\" y=\"0.5\" width=\"31\" height=\"31\" rx=\"3.5\" stroke=\"#DFE3E8\"/>\n          <path d=\"M12.8401 11.41L17.4201 16L12.8401 20.59L14.2501 22L20.2501 16L14.2501 10L12.8401 11.41Z\" fill=\"#C4CDD5\"/>\n        </svg>\n      </ng-template>\n    </button>\n  </div>\n  ", styles: [".custom-paginator{display:flex;align-items:center;justify-content:center;gap:10px;position:absolute;right:213px;top:-7px}.custom-paginator .paginator-btn{border:none;background:none;cursor:pointer;border-radius:5px;transition:background-color .3s;margin-top:7px}.custom-paginator .paginator-btn:disabled{cursor:not-allowed;opacity:.5}.custom-paginator .paginator-btn img{width:20px;height:20px}.custom-paginator .page-info{font-size:14px;font-weight:700}@media screen and (max-width: 850px){.custom-paginator{position:relative;right:0;top:0}}\n"] }]
        }], propDecorators: { totalCount: [{
                type: Input
            }], pageSize: [{
                type: Input
            }], currentPage: [{
                type: Input
            }], pageChange: [{
                type: Output
            }] } });

class FfCustomPaginationComponent {
    constructor() {
        this.hidePageSize = false;
        this.defaultPageSize = 10;
        this.currentStartIndex = 1;
        this.currentEndIndex = 10;
        this.isLoading = true;
        this.pageSize = this.defaultPageSize;
        this.pageIndex = 0;
        this.paginationAction = new EventEmitter();
    }
    ngOnChanges(changes) {
        const { customPageSize } = changes;
        if (customPageSize?.currentValue) {
            this.pageSize = customPageSize.currentValue.limit;
            this.pageIndex = customPageSize.currentValue.offset;
        }
        if (this.customPage) {
            this.pageSize = this.customPage.limit || 0;
            if (this.customPage.offset) {
                this.pageIndex = this.customPage.offset / this.pageSize;
            }
        }
        this.updatePaginationDetails();
    }
    getPageSizeOptions() {
        if (this.totalCount > 20) {
            return [10, 20, 50];
        }
        else {
            return [10, 20];
        }
    }
    pageEvent(e) {
        if (!e || typeof e !== 'object') {
            console.error('Invalid page event:', e);
            return;
        }
        this.pageSize = e.pageSize || this.defaultPageSize;
        this.pageIndex = e.pageIndex || 0;
        this.updatePaginationDetails();
        this.paginationAction.emit({
            limit: this.pageSize,
            offset: this.pageIndex * this.pageSize,
            type: 'page',
        });
    }
    pageSizeSetter(pageSize) {
        this.pageIndex = 0;
        this.pageSize = pageSize;
        this.updatePaginationDetails();
        this.paginationAction.emit({
            limit: this.pageSize,
            offset: 0,
            type: 'perPage',
        });
    }
    updatePaginationDetails(pageIndex, pageSize) {
        const effectivePageSize = pageSize || this.pageSize;
        const effectivePageIndex = pageIndex !== undefined ? pageIndex : this.pageIndex;
        this.currentStartIndex = effectivePageIndex * effectivePageSize + 1;
        this.currentEndIndex = Math.min(this.currentStartIndex + effectivePageSize - 1, this.totalCount);
        const totalPageCount = Math.ceil(this.totalCount / effectivePageSize);
        const currentPage = effectivePageIndex + 1;
        this.totalPages = `${currentPage}/${totalPageCount}`;
        if (totalPageCount) {
            this.isLoading = false;
        }
        this.enteredPageNo = null;
    }
    jumpToPage(pageNo) {
        const parsedPageNo = parseFloat(pageNo);
        const totalPageCount = Math.ceil(this.totalCount / this.pageSize);
        if (pageNo < 1 || pageNo > totalPageCount || isNaN(parsedPageNo) || !Number.isInteger(parsedPageNo)) {
            this.enteredPageNo = null;
            return;
        }
        this.pageIndex = pageNo - 1;
        this.paginationAction.emit({
            limit: this.pageSize,
            offset: this.pageIndex * this.pageSize,
            type: 'page',
        });
        this.updatePaginationDetails(this.pageIndex, this.pageSize);
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "16.2.12", ngImport: i0, type: FfCustomPaginationComponent, deps: [], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "16.2.12", type: FfCustomPaginationComponent, isStandalone: true, selector: "app-ff-custom-pagination", inputs: { totalCount: "totalCount", customPage: "customPage", hidePageSize: "hidePageSize", defaultPageSize: "defaultPageSize" }, outputs: { paginationAction: "paginationAction" }, usesOnChanges: true, ngImport: i0, template: "<aside aria-label=\"paginator wrapper\" class=\"ff-flex-between custom-style-paginator-select\" *ngIf=\"!isLoading\">\n    <article class=\"per-page-wrapper\" *ngIf=\"!hidePageSize\">\n        <div class=\"custom-text\">\n            Showing <span class=\"pagination-text\"> {{currentStartIndex}}-{{currentEndIndex}} </span> results out of\n            <span class=\"pagination-text\"> {{totalCount}}</span> &nbsp;\n        </div>\n        <aside aria-label=\"custom material pagesize dropdown\" class=\"page-size-dropdown pointer\"\n            [matMenuTriggerFor]=\"pageSizeMenu\" id=\"pageSize\">\n            {{pageSize}} items / Page <mat-icon>keyboard_arrow_down</mat-icon>\n        </aside>\n        <mat-menu class=\"mat-menu\" #pageSizeMenu=\"matMenu\" xPosition=\"after\">\n            <ul class=\"dropdown-page\">\n                <li *ngFor=\"let item of getPageSizeOptions()\" (click)=\"pageSizeSetter(item)\" id=\"page{{item}}\">\n                    {{item}}\n                </li>\n            </ul>\n        </mat-menu>\n    </article>\n    <article class=\"paginator-container\">\n        <app-custom-paginator [totalCount]=\"totalCount\" [pageSize]=\"pageSize\" [currentPage]=\"pageIndex + 1\"\n            (pageChange)=\"pageEvent($event)\">\n        </app-custom-paginator>\n\n        <article class=\"page-input-container\">\n            <span class=\"pagination-text pl-3\">Page:</span>\n            <input class=\"page-input\" type=\"text\" [(ngModel)]=\"enteredPageNo\" [min]=\"1\" name=\"pageNo\" id=\"pageNo\"\n                [placeholder]=\"totalPages\" />\n            <span class=\"pagination-text pointer\" (click)=\"jumpToPage(enteredPageNo)\">Go</span>\n        </article>\n    </article>\n</aside>", styles: ["::ng-deep .mat-mdc-paginator-page-size{position:relative;right:80px}::ng-deep .mat-mdc-paginator-page-size .mat-form-field-appearance-legacy .mat-form-field-infix{padding-bottom:2px!important;color:var(--color-secondary)}.mat-mdc-paginator-range-label{margin-right:45px}::ng-deep .mat-mdc-paginator .mat-mdc-paginator-navigation-previous{right:110px;margin-left:0}::ng-deep .mat-mdc-paginator .mat-mdc-paginator-navigation-next{right:17px}::ng-deep .mat-mdc-paginator .mat-mdc-paginator-range-label{height:40px;position:absolute;margin-right:0;display:flex;align-items:center;justify-content:center;right:86px;color:var(--font-color);font-size:14px;font-family:var(--font-regular);line-height:0px;top:auto}ul{list-style:none;margin:0}.custom-style-paginator-select{margin-top:15px;margin-right:40px;position:relative;display:flex;flex-wrap:wrap;justify-content:space-between;align-items:center}.dropdown-page{list-style:none;padding-left:10px;margin:0}.dropdown-page li{padding:4px;cursor:pointer}.page-size-dropdown{border-radius:6px;border:1px solid var(--border-color);padding:4px 12px;color:var(--font-color);min-width:100px;display:flex;justify-content:space-between}.per-page-wrapper{display:flex;align-items:center;justify-content:flex-start}.button-go{color:var(--font-color);font-family:Moderat Bold;font-size:14px}.page-input{border-radius:6px;border:1px solid var(--border-color);padding:4px 12px;color:var(--font-color);max-width:102px;margin:0 10px}.page-input-container{border-left:1px solid var(--border-color);margin-left:16px}.pagination-text{font-size:16px;font-weight:700}.paginator-container{display:flex;align-items:center}@media screen and (max-width: 850px){.custom-style-paginator-select{flex-direction:column;gap:10px}.paginator-container{flex-basis:100%;order:2}.per-page-wrapper{flex-basis:100%;order:1}}\n"], dependencies: [{ kind: "ngmodule", type: CommonModule }, { kind: "directive", type: i1.NgForOf, selector: "[ngFor][ngForOf]", inputs: ["ngForOf", "ngForTrackBy", "ngForTemplate"] }, { kind: "directive", type: i1.NgIf, selector: "[ngIf]", inputs: ["ngIf", "ngIfThen", "ngIfElse"] }, { kind: "ngmodule", type: MatMenuModule }, { kind: "component", type: i2$1.MatMenu, selector: "mat-menu", exportAs: ["matMenu"] }, { kind: "directive", type: i2$1.MatMenuTrigger, selector: "[mat-menu-trigger-for], [matMenuTriggerFor]", exportAs: ["matMenuTrigger"] }, { kind: "ngmodule", type: MatIconModule }, { kind: "component", type: i2.MatIcon, selector: "mat-icon", inputs: ["color", "inline", "svgIcon", "fontSet", "fontIcon"], exportAs: ["matIcon"] }, { kind: "ngmodule", type: FormsModule }, { kind: "directive", type: i4$1.DefaultValueAccessor, selector: "input:not([type=checkbox])[formControlName],textarea[formControlName],input:not([type=checkbox])[formControl],textarea[formControl],input:not([type=checkbox])[ngModel],textarea[ngModel],[ngDefaultControl]" }, { kind: "directive", type: i4$1.NgControlStatus, selector: "[formControlName],[ngModel],[formControl]" }, { kind: "directive", type: i4$1.NgModel, selector: "[ngModel]:not([formControlName]):not([formControl])", inputs: ["name", "disabled", "ngModel", "ngModelOptions"], outputs: ["ngModelChange"], exportAs: ["ngModel"] }, { kind: "component", type: CustomPaginatorComponent, selector: "app-custom-paginator", inputs: ["totalCount", "pageSize", "currentPage"], outputs: ["pageChange"] }] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "16.2.12", ngImport: i0, type: FfCustomPaginationComponent, decorators: [{
            type: Component,
            args: [{ selector: 'app-ff-custom-pagination', standalone: true, imports: [CommonModule, MatMenuModule, MatIconModule, FormsModule, CustomPaginatorComponent], template: "<aside aria-label=\"paginator wrapper\" class=\"ff-flex-between custom-style-paginator-select\" *ngIf=\"!isLoading\">\n    <article class=\"per-page-wrapper\" *ngIf=\"!hidePageSize\">\n        <div class=\"custom-text\">\n            Showing <span class=\"pagination-text\"> {{currentStartIndex}}-{{currentEndIndex}} </span> results out of\n            <span class=\"pagination-text\"> {{totalCount}}</span> &nbsp;\n        </div>\n        <aside aria-label=\"custom material pagesize dropdown\" class=\"page-size-dropdown pointer\"\n            [matMenuTriggerFor]=\"pageSizeMenu\" id=\"pageSize\">\n            {{pageSize}} items / Page <mat-icon>keyboard_arrow_down</mat-icon>\n        </aside>\n        <mat-menu class=\"mat-menu\" #pageSizeMenu=\"matMenu\" xPosition=\"after\">\n            <ul class=\"dropdown-page\">\n                <li *ngFor=\"let item of getPageSizeOptions()\" (click)=\"pageSizeSetter(item)\" id=\"page{{item}}\">\n                    {{item}}\n                </li>\n            </ul>\n        </mat-menu>\n    </article>\n    <article class=\"paginator-container\">\n        <app-custom-paginator [totalCount]=\"totalCount\" [pageSize]=\"pageSize\" [currentPage]=\"pageIndex + 1\"\n            (pageChange)=\"pageEvent($event)\">\n        </app-custom-paginator>\n\n        <article class=\"page-input-container\">\n            <span class=\"pagination-text pl-3\">Page:</span>\n            <input class=\"page-input\" type=\"text\" [(ngModel)]=\"enteredPageNo\" [min]=\"1\" name=\"pageNo\" id=\"pageNo\"\n                [placeholder]=\"totalPages\" />\n            <span class=\"pagination-text pointer\" (click)=\"jumpToPage(enteredPageNo)\">Go</span>\n        </article>\n    </article>\n</aside>", styles: ["::ng-deep .mat-mdc-paginator-page-size{position:relative;right:80px}::ng-deep .mat-mdc-paginator-page-size .mat-form-field-appearance-legacy .mat-form-field-infix{padding-bottom:2px!important;color:var(--color-secondary)}.mat-mdc-paginator-range-label{margin-right:45px}::ng-deep .mat-mdc-paginator .mat-mdc-paginator-navigation-previous{right:110px;margin-left:0}::ng-deep .mat-mdc-paginator .mat-mdc-paginator-navigation-next{right:17px}::ng-deep .mat-mdc-paginator .mat-mdc-paginator-range-label{height:40px;position:absolute;margin-right:0;display:flex;align-items:center;justify-content:center;right:86px;color:var(--font-color);font-size:14px;font-family:var(--font-regular);line-height:0px;top:auto}ul{list-style:none;margin:0}.custom-style-paginator-select{margin-top:15px;margin-right:40px;position:relative;display:flex;flex-wrap:wrap;justify-content:space-between;align-items:center}.dropdown-page{list-style:none;padding-left:10px;margin:0}.dropdown-page li{padding:4px;cursor:pointer}.page-size-dropdown{border-radius:6px;border:1px solid var(--border-color);padding:4px 12px;color:var(--font-color);min-width:100px;display:flex;justify-content:space-between}.per-page-wrapper{display:flex;align-items:center;justify-content:flex-start}.button-go{color:var(--font-color);font-family:Moderat Bold;font-size:14px}.page-input{border-radius:6px;border:1px solid var(--border-color);padding:4px 12px;color:var(--font-color);max-width:102px;margin:0 10px}.page-input-container{border-left:1px solid var(--border-color);margin-left:16px}.pagination-text{font-size:16px;font-weight:700}.paginator-container{display:flex;align-items:center}@media screen and (max-width: 850px){.custom-style-paginator-select{flex-direction:column;gap:10px}.paginator-container{flex-basis:100%;order:2}.per-page-wrapper{flex-basis:100%;order:1}}\n"] }]
        }], propDecorators: { totalCount: [{
                type: Input
            }], customPage: [{
                type: Input
            }], hidePageSize: [{
                type: Input
            }], defaultPageSize: [{
                type: Input
            }], paginationAction: [{
                type: Output
            }] } });

const HTTP_OPTION_1 = {
    contentType: true,
    token: true,
    userId: true,
    timezone: true,
};
const HTTP_OPTION_2 = {
    token: true,
    userId: true,
    timezone: true,
};
const HTTP_OPTION_3 = {
    contentType: true,
    token: true,
    userId: true,
    nodeId: true,
};
const HTTP_OPTION_4 = {
    token: true,
    userId: true,
    nodeId: true,
    timezone: true,
};
const HTTP_OPTION_5 = {
    token: true,
    contentType: true,
};
const HTTP_OPTION_6 = {
    urlEncode: true,
};
const HTTP_OPTION_7 = {
    token: true,
    contentType: true,
    entityId: true
};
var ACTION_TYPE;
(function (ACTION_TYPE) {
    ACTION_TYPE["SUCCESS"] = "success";
    ACTION_TYPE["FAILED"] = "error";
    ACTION_TYPE["DELETE"] = "delete";
})(ACTION_TYPE || (ACTION_TYPE = {}));

/**
 * Generates HTTP headers based on the provided configuration.
 *
 * @param itemsNeeded - Partial configuration object specifying which headers are needed.
 * @returns HTTP headers options object.
 */
const headerOptions = (itemsNeeded) => {
    // Get user data and company ID from local storage
    const companyId = localStorage.getItem('companyID');
    // Check if impersonation is enabled
    const impersonate = localStorage.getItem('impersonate');
    const entityData = localStorage.getItem('entityId');
    // Extract needed properties from the configuration object
    const { timezone, contentType, userId, nodeId, token, urlEncode, acceptAll, entityId } = itemsNeeded;
    // Initialize the base header object
    const BASE_HEADER = {};
    const idToken = localStorage.getItem('id_token');
    const loggedInUserId = localStorage.getItem('userId');
    // Add User-ID header if needed
    if (userId) {
        BASE_HEADER['User-ID'] = loggedInUserId;
    }
    // Add Bearer token header if needed
    if (token) {
        BASE_HEADER['Authorization'] = `Bearer ${idToken}`;
    }
    // Add Node-ID header if needed
    if (nodeId) {
        BASE_HEADER['Node-ID'] = companyId;
    }
    // Add timezone header if needed
    if (timezone) {
        BASE_HEADER['timezone'] = Intl.DateTimeFormat().resolvedOptions().timeZone;
    }
    // Add Content-Type header if needed
    if (contentType) {
        BASE_HEADER['Content-Type'] = 'application/json';
    }
    // Add X-Impersonate header if impersonation is enabled
    if (impersonate) {
        BASE_HEADER['X-Impersonate'] = 'true';
    }
    if (urlEncode) {
        BASE_HEADER['Content-Type'] = 'application/x-www-form-urlencoded';
    }
    if (acceptAll) {
        BASE_HEADER['Accept'] = '*/*';
    }
    if (entityId) {
        BASE_HEADER['Entity-ID'] = entityData ? entityData : '';
    }
    // Create HTTP headers options object
    const httpOptions = {
        headers: new HttpHeaders({
            ...BASE_HEADER,
        }),
    };
    return httpOptions;
};

/* eslint-disable @typescript-eslint/no-explicit-any */
const imagePathPrefix = '../../../assets/images/';
class SnackBarComponent {
    constructor(snackBarRef, data) {
        this.snackBarRef = snackBarRef;
        this.data = data;
    }
    get getClass() {
        if (this.data.icon === 'error') {
            return 'fonterror';
        }
        else {
            return 'fontsucces';
        }
    }
    get getIcon() {
        if (['success', 'error', 'delete'].includes(this.data.icon)) {
            return `${imagePathPrefix}${this.data.icon.toLowerCase()}.svg`;
        }
        else {
            return `${imagePathPrefix}success.svg`;
        }
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "16.2.12", ngImport: i0, type: SnackBarComponent, deps: [{ token: i1$1.MatSnackBarRef }, { token: MAT_SNACK_BAR_DATA }], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "16.2.12", type: SnackBarComponent, isStandalone: true, selector: "app-snack-bar", ngImport: i0, template: "<div fxLayout=\"row\" class=\"snack-container\">\n    <article class=\"disp-flex\">\n      <img class=\"mr-20\" src=\"{{getIcon}}\" alt=\"\">\n      <span class=\"{{getClass}} mat-select text-overflow\">\n          {{ data.message }}</span>\n    </article>\n  </div>\n  ", styles: [".disp-flex{display:flex;align-items:center;justify-content:flex-start}.mr-20{margin-right:20px}.fontsucces{font-size:16px;color:var(--font-color)}.fonterror{font-size:16px;color:var(--color-secondary)}::ng-deep .mat-mdc-snack-bar-container .mdc-snackbar__surface{border-radius:5px!important;padding:13px 25px;max-width:560px!important;background:#fff!important}\n"], dependencies: [{ kind: "ngmodule", type: MatSnackBarModule }, { kind: "ngmodule", type: CommonModule }] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "16.2.12", ngImport: i0, type: SnackBarComponent, decorators: [{
            type: Component,
            args: [{ selector: 'app-snack-bar', standalone: true, imports: [MatSnackBarModule, CommonModule], template: "<div fxLayout=\"row\" class=\"snack-container\">\n    <article class=\"disp-flex\">\n      <img class=\"mr-20\" src=\"{{getIcon}}\" alt=\"\">\n      <span class=\"{{getClass}} mat-select text-overflow\">\n          {{ data.message }}</span>\n    </article>\n  </div>\n  ", styles: [".disp-flex{display:flex;align-items:center;justify-content:flex-start}.mr-20{margin-right:20px}.fontsucces{font-size:16px;color:var(--font-color)}.fonterror{font-size:16px;color:var(--color-secondary)}::ng-deep .mat-mdc-snack-bar-container .mdc-snackbar__surface{border-radius:5px!important;padding:13px 25px;max-width:560px!important;background:#fff!important}\n"] }]
        }], ctorParameters: function () { return [{ type: i1$1.MatSnackBarRef }, { type: undefined, decorators: [{
                    type: Inject,
                    args: [MAT_SNACK_BAR_DATA]
                }] }]; } });

class SyncButtonService {
    constructor() {
        this.snackBar = inject(MatSnackBar);
        this.http = inject(HttpClient);
    }
    customSnackBar(message, type) {
        this.snackBar.openFromComponent(SnackBarComponent, {
            data: {
                message: message,
                icon: type,
            },
            panelClass: 'snackbar-color',
            duration: 3000,
        });
    }
    syncConnect(baseUrl) {
        return this.http.post(baseUrl + '/projects/reverse-sync/', {}, headerOptions(HTTP_OPTION_1));
    }
    syncNavigate(params, baseUrl) {
        console.log(params, baseUrl);
        return this.http.post(baseUrl + '/projects/navigate-sync/', params, headerOptions(HTTP_OPTION_1));
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "16.2.12", ngImport: i0, type: SyncButtonService, deps: [], target: i0.ɵɵFactoryTarget.Injectable }); }
    static { this.ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "16.2.12", ngImport: i0, type: SyncButtonService, providedIn: 'root' }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "16.2.12", ngImport: i0, type: SyncButtonService, decorators: [{
            type: Injectable,
            args: [{
                    providedIn: 'root',
                }]
        }], ctorParameters: function () { return []; } });

class SyncBtnComponent {
    constructor() {
        this.showConnectBtn = true;
        this.showNavigateBtn = true;
        this.nodeId = '';
        this.supplychainId = '';
        this.baseUrl = '';
        this.destroy$ = new Subject();
        this.syncService = inject(SyncButtonService);
    }
    /**
     * The `syncFromConnect` function in TypeScript initiates synchronization with a service and displays
     * corresponding messages based on success or failure.
     */
    syncFromConnect() {
        this.syncService
            .syncConnect(this.baseUrl)
            .pipe(takeUntil(this.destroy$))
            .subscribe({
            next: () => {
                this.syncService.customSnackBar('Syncing started, it will take a few minutes', ACTION_TYPE.SUCCESS);
            },
            error: (error) => {
                const message = error?.error?.detail?.detail || error?.detail?.detail || 'Something went wrong!';
                this.syncService.customSnackBar(message, ACTION_TYPE.FAILED);
            },
        });
    }
    /**
     * The `syncWithNavigate` function synchronizes data with navigation and displays corresponding
     * messages based on success or failure.
     */
    syncWithNavigate() {
        const params = {
            node: this.nodeId,
            supply_chain: this.supplychainId || '',
        };
        this.syncService
            .syncNavigate(params, this.baseUrl)
            .pipe(takeUntil(this.destroy$))
            .subscribe({
            next: () => {
                this.syncService.customSnackBar('Syncing started, it will take a few minutes', ACTION_TYPE.SUCCESS);
            },
            error: (error) => {
                const message = error?.error?.detail?.detail || error?.detail?.detail || 'Something went wrong!';
                this.syncService.customSnackBar(message, ACTION_TYPE.FAILED);
            },
        });
    }
    ngOnDestroy() {
        this.destroy$.next();
        this.destroy$.complete();
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "16.2.12", ngImport: i0, type: SyncBtnComponent, deps: [], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "16.2.12", type: SyncBtnComponent, isStandalone: true, selector: "app-sync-button", inputs: { showConnectBtn: "showConnectBtn", showNavigateBtn: "showNavigateBtn", nodeId: "nodeId", supplychainId: "supplychainId", baseUrl: "baseUrl" }, ngImport: i0, template: "<article>\n    <div [matMenuTriggerFor]=\"syncMenu\" class=\"pointer sync-button\">\n      <img src=\"../../../assets/images/sync.svg\" class=\"sync-icon\" alt=\"\">\n      <span class=\"sync-text ml-8\">Sync</span>\n      <mat-icon class=\"down-arrow\">keyboard_arrow_down</mat-icon>\n    </div>\n    <mat-menu class=\"profile-dropdown navbar-collapse\" #syncMenu=\"matMenu\" xPosition=\"before\">\n      <ng-container *ngIf=\"showConnectBtn\">\n        <button mat-menu-item *ngIf=\"showConnectBtn\" class=\"sync-option\" (click)=\"syncFromConnect()\">Sync from Connect</button>\n      </ng-container>\n      <ng-container *ngIf=\"showNavigateBtn\">\n        <button mat-menu-item class=\"sync-option\" (click)=\"syncWithNavigate()\">Sync with Navigate</button>\n      </ng-container>\n    </mat-menu>\n  </article>", styles: [".ml-8{margin-left:8px}.sync-text{font-size:14px;color:var(--font-color);font-weight:700}.sync-icon{width:15px}.sync-button{display:flex;align-items:center}::ng-deep .sync-option .mdc-list-item__primary-text{font-size:14px;color:var(--font-color)}\n"], dependencies: [{ kind: "ngmodule", type: MatIconModule }, { kind: "component", type: i2.MatIcon, selector: "mat-icon", inputs: ["color", "inline", "svgIcon", "fontSet", "fontIcon"], exportAs: ["matIcon"] }, { kind: "ngmodule", type: MatMenuModule }, { kind: "component", type: i2$1.MatMenu, selector: "mat-menu", exportAs: ["matMenu"] }, { kind: "component", type: i2$1.MatMenuItem, selector: "[mat-menu-item]", inputs: ["disabled", "disableRipple", "role"], exportAs: ["matMenuItem"] }, { kind: "directive", type: i2$1.MatMenuTrigger, selector: "[mat-menu-trigger-for], [matMenuTriggerFor]", exportAs: ["matMenuTrigger"] }, { kind: "directive", type: NgIf, selector: "[ngIf]", inputs: ["ngIf", "ngIfThen", "ngIfElse"] }] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "16.2.12", ngImport: i0, type: SyncBtnComponent, decorators: [{
            type: Component,
            args: [{ selector: 'app-sync-button', standalone: true, imports: [MatIconModule, MatMenuModule, NgIf, AsyncPipe], template: "<article>\n    <div [matMenuTriggerFor]=\"syncMenu\" class=\"pointer sync-button\">\n      <img src=\"../../../assets/images/sync.svg\" class=\"sync-icon\" alt=\"\">\n      <span class=\"sync-text ml-8\">Sync</span>\n      <mat-icon class=\"down-arrow\">keyboard_arrow_down</mat-icon>\n    </div>\n    <mat-menu class=\"profile-dropdown navbar-collapse\" #syncMenu=\"matMenu\" xPosition=\"before\">\n      <ng-container *ngIf=\"showConnectBtn\">\n        <button mat-menu-item *ngIf=\"showConnectBtn\" class=\"sync-option\" (click)=\"syncFromConnect()\">Sync from Connect</button>\n      </ng-container>\n      <ng-container *ngIf=\"showNavigateBtn\">\n        <button mat-menu-item class=\"sync-option\" (click)=\"syncWithNavigate()\">Sync with Navigate</button>\n      </ng-container>\n    </mat-menu>\n  </article>", styles: [".ml-8{margin-left:8px}.sync-text{font-size:14px;color:var(--font-color);font-weight:700}.sync-icon{width:15px}.sync-button{display:flex;align-items:center}::ng-deep .sync-option .mdc-list-item__primary-text{font-size:14px;color:var(--font-color)}\n"] }]
        }], ctorParameters: function () { return []; }, propDecorators: { showConnectBtn: [{
                type: Input
            }], showNavigateBtn: [{
                type: Input
            }], nodeId: [{
                type: Input
            }], supplychainId: [{
                type: Input
            }], baseUrl: [{
                type: Input
            }] } });

/* eslint-disable @typescript-eslint/no-explicit-any */
class DateAgoPipe {
    transform(value) {
        const date = new Date(value * 1000);
        if (value) {
            const seconds = Math.floor((+new Date() - +new Date(date)) / 1000);
            if (seconds < 29) {
                // less than 30 seconds ago will show as 'Just now'
                return 'Just now';
            }
            const intervals = {
                year: 31536000,
                month: 2592000,
                week: 604800,
                day: 86400,
                hour: 3600,
                minute: 60,
                second: 1,
            };
            let counter;
            for (const i in intervals) {
                counter = Math.floor(seconds / intervals[i]);
                if (counter > 0)
                    if (counter === 1) {
                        return counter + ' ' + i + ' ago'; // singular (1 day ago)
                    }
                    else {
                        return counter + ' ' + i + 's ago'; // plural (2 days ago)
                    }
            }
        }
        return date;
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "16.2.12", ngImport: i0, type: DateAgoPipe, deps: [], target: i0.ɵɵFactoryTarget.Pipe }); }
    static { this.ɵpipe = i0.ɵɵngDeclarePipe({ minVersion: "14.0.0", version: "16.2.12", ngImport: i0, type: DateAgoPipe, isStandalone: true, name: "dateAgo" }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "16.2.12", ngImport: i0, type: DateAgoPipe, decorators: [{
            type: Pipe,
            args: [{
                    name: 'dateAgo',
                    pure: true,
                    standalone: true,
                }]
        }] });

/* eslint-disable @typescript-eslint/no-explicit-any */
class FilterDropdownPipe {
    transform(items, searchKey) {
        if (!items || !searchKey) {
            return items;
        }
        // filter items array, items which match and return true will be
        // kept, false will be filtered out
        return items.filter(item => item.name.toLowerCase().indexOf(searchKey.toLowerCase()) !== -1);
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "16.2.12", ngImport: i0, type: FilterDropdownPipe, deps: [], target: i0.ɵɵFactoryTarget.Pipe }); }
    static { this.ɵpipe = i0.ɵɵngDeclarePipe({ minVersion: "14.0.0", version: "16.2.12", ngImport: i0, type: FilterDropdownPipe, isStandalone: true, name: "searchOptions", pure: false }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "16.2.12", ngImport: i0, type: FilterDropdownPipe, decorators: [{
            type: Pipe,
            args: [{
                    name: 'searchOptions',
                    pure: false,
                    standalone: true,
                }]
        }] });

function AutoUnsubscribe(constructor) {
    // Get a reference to the original ngOnDestroy function of the component/service
    const original = constructor.prototype.ngOnDestroy;
    // Override the ngOnDestroy function of the component/service
    constructor.prototype.ngOnDestroy = function () {
        // Loop through all properties of the component/service
        for (const prop in this) {
            const property = this[prop];
            // Check if the property is a subscription
            if (property && typeof property.unsubscribe === 'function') {
                // Call the unsubscribe function to unsubscribe from the subscription
                property.unsubscribe();
            }
        }
        original?.apply(this, arguments);
    };
}

/*
 * Public API Surface of fairfood-utils
 */

/**
 * Generated bundle index. Do not edit.
 */

export { ACTION_TYPE, ActionButtonsComponent, AutoUnsubscribe, ButtonsComponent, DateAgoPipe, FairFoodCustomTabComponent, FfCustomPaginationComponent, FfPaginationComponent, FilterDropdownPipe, HTTP_OPTION_1, HTTP_OPTION_2, HTTP_OPTION_3, HTTP_OPTION_4, HTTP_OPTION_5, HTTP_OPTION_6, HTTP_OPTION_7, LoaderComponent, LoaderType, SortCustomComponent, SyncBtnComponent, headerOptions };
//# sourceMappingURL=fairfood-utils.mjs.map
