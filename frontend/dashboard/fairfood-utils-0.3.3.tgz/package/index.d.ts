/**
 * Generated bundle index. Do not edit.
 */
/// <amd-module name="fairfood-utils" />
export * from './public-api';
