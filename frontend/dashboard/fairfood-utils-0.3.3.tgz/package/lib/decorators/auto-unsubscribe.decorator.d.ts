export declare function AutoUnsubscribe(constructor: any): void;
