import { EventEmitter, OnChanges, SimpleChanges } from '@angular/core';
import * as i0 from "@angular/core";
export interface Paginator {
    limit: number;
    offset: number;
    type?: 'perPage' | 'page';
}
export declare class FfCustomPaginationComponent implements OnChanges {
    totalCount: number;
    customPage?: Partial<Paginator>;
    hidePageSize: boolean;
    defaultPageSize: number;
    totalPages: string;
    currentStartIndex: number;
    currentEndIndex: number;
    enteredPageNo: any;
    isLoading: boolean;
    pageSize: number;
    pageIndex: number;
    paginationAction: EventEmitter<any>;
    ngOnChanges(changes: SimpleChanges): void;
    getPageSizeOptions(): number[];
    pageEvent(e: any): void;
    pageSizeSetter(pageSize: number): void;
    updatePaginationDetails(pageIndex?: number, pageSize?: number): void;
    jumpToPage(pageNo: any): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<FfCustomPaginationComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<FfCustomPaginationComponent, "app-ff-custom-pagination", never, { "totalCount": { "alias": "totalCount"; "required": false; }; "customPage": { "alias": "customPage"; "required": false; }; "hidePageSize": { "alias": "hidePageSize"; "required": false; }; "defaultPageSize": { "alias": "defaultPageSize"; "required": false; }; }, { "paginationAction": "paginationAction"; }, never, never, true, never>;
}
