import { EventEmitter, OnChanges, SimpleChanges } from '@angular/core';
import { MatPaginator } from '@angular/material/paginator';
import * as i0 from "@angular/core";
export interface IPaginator {
    limit: number;
    offset: number;
    type?: 'perPage' | 'page';
}
export declare class FfPaginationComponent implements OnChanges {
    paginator: MatPaginator;
    totalCount: number;
    customPageSize?: Partial<IPaginator>;
    hidePageSize: boolean;
    defaultPageSize: number;
    paginationAction: EventEmitter<any>;
    /**
     * This method is called when there are changes in the input properties.
     * It adjusts the paginator's pageSize and pageIndex if customPageSize is provided.
     * @param changes - The changes in input properties.
     */
    ngOnChanges(changes: SimpleChanges): void;
    /**
     * Get the page size options based on the totalCount.
     * @returns An array of page size options.
     */
    getPageSizeOptions(): number[];
    /**
     * Handles the page event emitted by the paginator.
     * @param e - The page event.
     */
    pageEvent(e: any): void;
    /**
     * Sets the page size and resets pageIndex to 0.
     * @param pageSize - The selected page size.
     */
    pageSizeSetter(pageSize: any): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<FfPaginationComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<FfPaginationComponent, "app-ff-pagination", never, { "totalCount": { "alias": "totalCount"; "required": false; }; "customPageSize": { "alias": "customPageSize"; "required": false; }; "hidePageSize": { "alias": "hidePageSize"; "required": false; }; "defaultPageSize": { "alias": "defaultPageSize"; "required": false; }; }, { "paginationAction": "paginationAction"; }, never, never, true, never>;
}
