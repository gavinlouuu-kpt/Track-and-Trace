export { FfPaginationComponent, IPaginator } from './ff-pagination.component';
