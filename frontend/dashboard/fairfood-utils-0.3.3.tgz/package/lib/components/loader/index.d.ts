/**
 * @component LoaderComponent
 * @description
 *   The `LoaderComponent` is a reusable Angular component that displays a loader with customizable text and styles.
 *   It can be used to indicate loading or processing states in an Angular application.
 *
 * @usage
 *   ```
 *   <app-loader
 *     [loaderText]="loadingText"
 *     [noText]="hideText"
 *     [loaderType]="selectedLoaderType"
 *   ></app-loader>
 *   ```
 *
 * @inputs
 *   - `loaderText` (string): The text to display alongside the loader. (Optional)
 *   - `noText` (boolean): Determines whether to hide the loader text. Defaults to `false`. (Optional)
 *   - `loaderType` (string): The type of loader to display. Possible values are `LoaderType.Type1`, `LoaderType.Type2`, `LoaderType.Type3`, and `LoaderType.Default`. Defaults to `LoaderType.Default`. (Optional)
 *
 * @enums
 *   - `LoaderType`: An enumeration that represents the available loader types.
 *     - `Type1`: Type 1 loader style.
 *     - `Type2`: Type 2 loader style.
 *     - `Type3`: Type 3 loader style.
 *     - `Default`: Default loader style.
 *
 * @example
 *   ```typescript
 *   import { Component } from '@angular/core';
 *
 *   @Component({
 *     selector: 'app-example',
 *     template: `
 *       <app-loader
 *         [loaderText]="'Loading...'"
 *         [noText]="false"
 *         [loaderType]="LoaderType.Type1"
 *       ></app-loader>
 *     `,
 *   })
 *   export class ExampleComponent {
 *     readonly LoaderType = LoaderType;
 *   }
 *   ```
 *
 * @styles
 *   The `LoaderComponent` applies the following CSS classes:
 *   - `.loader-container`: The main container of the loader component.
 *   - `.loader-text`: The CSS class for the loader text.
 *   - `.circle1`, `.circle2`: Applied to customize the colors of the circles in the loader SVG code.
 *   - `.loader-wrapper`: The CSS class for the wrapper element of the loader component.
 *
 * @dependencies
 *   This component requires the following Angular modules and dependencies to be imported:
 *   - `@angular/core`: Angular core module.
 *   - `@angular/common`: Angular common module.
 *
 * @version 1.0.0
 */
export { LoaderComponent, LoaderType } from './loader.component';
