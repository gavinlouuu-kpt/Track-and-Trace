import * as i0 from "@angular/core";
export declare enum LoaderType {
    Type1 = "type1",
    Type2 = "type2",
    Default = "default"
}
export declare class LoaderComponent {
    loaderText: string;
    noText: boolean;
    loaderType: string;
    readonly LoaderType: typeof LoaderType;
    static ɵfac: i0.ɵɵFactoryDeclaration<LoaderComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<LoaderComponent, "app-loader", never, { "loaderText": { "alias": "loaderText"; "required": false; }; "noText": { "alias": "noText"; "required": false; }; "loaderType": { "alias": "loaderType"; "required": false; }; }, {}, never, never, true, never>;
}
