import { EventEmitter, OnChanges, SimpleChanges } from '@angular/core';
import * as i0 from "@angular/core";
export declare class CustomPaginatorComponent implements OnChanges {
    totalCount: number;
    pageSize: number;
    currentPage: number;
    pageChange: EventEmitter<any>;
    totalPages: number;
    previousPageIndex: number;
    ngOnChanges(changes: SimpleChanges): void;
    /**
     * Calculate total pages based on totalCount and pageSize.
     */
    calculateTotalPages(): void;
    /**
     * Navigate to the previous page.
     */
    goToPreviousPage(): void;
    /**
     * Navigate to the next page.
     */
    goToNextPage(): void;
    /**
     * Create the structured page event object.
     */
    private createPageEvent;
    static ɵfac: i0.ɵɵFactoryDeclaration<CustomPaginatorComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<CustomPaginatorComponent, "app-custom-paginator", never, { "totalCount": { "alias": "totalCount"; "required": false; }; "pageSize": { "alias": "pageSize"; "required": false; }; "currentPage": { "alias": "currentPage"; "required": false; }; }, { "pageChange": "pageChange"; }, never, never, true, never>;
}
