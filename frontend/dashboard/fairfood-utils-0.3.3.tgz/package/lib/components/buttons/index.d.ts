export { ButtonsComponent } from './buttons.component';
/**
 * ButtonsComponent is a reusable component that represents a button with different styles and sizes.
 * It supports various customization options such as button type, size, additional classes, and disabled state.
 *
 * Usage:
 *
 * <app-buttons
 *   [buttonType]="'fill' | 'stroked' | 'secondary'"
 *   [buttonSize]="'medium' | 'large'"
 *   [buttonClass]="customButtonClass"
 *   [isDisabled]="disabledState"
 *   [tooltip]="tooltipText"
 *   (buttonClicked)="handleButtonClick()"
 * >
 *   Button Text
 * </app-buttons>
 *
 * @example
 *
 * <app-buttons
 *   buttonType="fill"
 *   buttonSize="large"
 *   buttonClass="custom-class"
 *   isDisabled="false"
 *   tooltip="Click me!"
 *   (buttonClicked)="handleButtonClick()"
 * >
 *   Button Text
 * </app-buttons>
 *
 */
