import { EventEmitter } from '@angular/core';
import * as i0 from "@angular/core";
export declare class ButtonsComponent {
    /**
     * The type of the button. Possible values are 'fill', 'stroked', and 'secondary'.
     * Defaults to 'fill'.
     *
     * @type {('fill' | 'stroked' | 'secondary')}
     * @memberof ButtonsComponent
     */
    buttonType: 'fill' | 'stroked' | 'secondary';
    /**
     * The size of the button. Possible values are 'medium' and 'large'.
     * Defaults to 'medium'.
     *
     * @type {('medium' | 'large')}
     * @memberof ButtonsComponent
     */
    buttonSize: 'medium' | 'large';
    /**
     * For testing purpose
     */
    customId: string;
    /**
     * Additional CSS class(es) to apply to the button.
     * This can be used for further customization.
     *
     * @type {string}
     * @memberof ButtonsComponent
     */
    buttonClass: string;
    /**
     * Determines whether the button is disabled or not.
     * Defaults to false.
     *
     * @type {boolean}
     * @memberof ButtonsComponent
     */
    isDisabled: boolean;
    /**
     * The tooltip text to display when hovering over the button.
     * Defaults to an empty string.
     *
     * @type {string}
     * @memberof ButtonsComponent
     */
    tooltip: string;
    /**
     * Event emitted when the button is clicked.
     * Emits a boolean value representing the click event.
     *
     * @type {EventEmitter<boolean>}
     * @memberof ButtonsComponent
     */
    buttonClicked: EventEmitter<any>;
    buttonClick(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<ButtonsComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<ButtonsComponent, "app-buttons", never, { "buttonType": { "alias": "buttonType"; "required": false; }; "buttonSize": { "alias": "buttonSize"; "required": false; }; "customId": { "alias": "customId"; "required": false; }; "buttonClass": { "alias": "buttonClass"; "required": false; }; "isDisabled": { "alias": "isDisabled"; "required": false; }; "tooltip": { "alias": "tooltip"; "required": false; }; }, { "buttonClicked": "buttonClicked"; }, never, ["*"], true, never>;
}
