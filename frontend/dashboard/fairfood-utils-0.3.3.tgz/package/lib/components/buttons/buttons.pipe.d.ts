import { PipeTransform } from '@angular/core';
import * as i0 from "@angular/core";
export declare class ButtonClassPipe implements PipeTransform {
    transform(value: string, size: string, custom?: string): string;
    static ɵfac: i0.ɵɵFactoryDeclaration<ButtonClassPipe, never>;
    static ɵpipe: i0.ɵɵPipeDeclaration<ButtonClassPipe, "generateBtnClass", true>;
}
