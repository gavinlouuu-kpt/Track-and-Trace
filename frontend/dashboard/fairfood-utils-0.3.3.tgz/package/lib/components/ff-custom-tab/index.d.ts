export { FairFoodCustomTabComponent } from './ff-custom-tab.component';
