import { EventEmitter, OnDestroy, OnChanges, SimpleChanges } from '@angular/core';
import * as i0 from "@angular/core";
export declare class FairFoodCustomTabComponent implements OnChanges, OnDestroy {
    tabGroupItems: any[];
    activeTabId: string;
    moreTabs: any[];
    withDescription: boolean;
    tabChanged: EventEmitter<any>;
    tabList: any[];
    ngOnChanges(changes: SimpleChanges): void;
    changeTab(tabItem: any): void;
    addTab(item: any): void;
    trackByFn(index: number): any;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<FairFoodCustomTabComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<FairFoodCustomTabComponent, "app-ff-custom-tab", never, { "tabGroupItems": { "alias": "tabGroupItems"; "required": false; }; "activeTabId": { "alias": "activeTabId"; "required": false; }; "moreTabs": { "alias": "moreTabs"; "required": false; }; "withDescription": { "alias": "withDescription"; "required": false; }; }, { "tabChanged": "tabChanged"; }, never, never, true, never>;
}
