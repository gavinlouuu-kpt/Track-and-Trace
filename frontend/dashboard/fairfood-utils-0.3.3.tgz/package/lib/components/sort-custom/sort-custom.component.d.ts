import { OnChanges } from '@angular/core';
import * as i0 from "@angular/core";
export declare class SortCustomComponent implements OnChanges {
    filterValues: any;
    columnName: string;
    ngOnChanges(): void;
    logParams(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<SortCustomComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<SortCustomComponent, "app-sort-custom", never, { "filterValues": { "alias": "filterValues"; "required": false; }; "columnName": { "alias": "columnName"; "required": false; }; }, {}, never, never, true, never>;
}
