import { OnDestroy } from '@angular/core';
import * as i0 from "@angular/core";
export declare class SyncBtnComponent implements OnDestroy {
    showConnectBtn: boolean;
    showNavigateBtn: boolean;
    nodeId: string;
    supplychainId: string;
    baseUrl: string;
    private destroy$;
    private syncService;
    constructor();
    /**
     * The `syncFromConnect` function in TypeScript initiates synchronization with a service and displays
     * corresponding messages based on success or failure.
     */
    syncFromConnect(): void;
    /**
     * The `syncWithNavigate` function synchronizes data with navigation and displays corresponding
     * messages based on success or failure.
     */
    syncWithNavigate(): void;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<SyncBtnComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<SyncBtnComponent, "app-sync-button", never, { "showConnectBtn": { "alias": "showConnectBtn"; "required": false; }; "showNavigateBtn": { "alias": "showNavigateBtn"; "required": false; }; "nodeId": { "alias": "nodeId"; "required": false; }; "supplychainId": { "alias": "supplychainId"; "required": false; }; "baseUrl": { "alias": "baseUrl"; "required": false; }; }, {}, never, never, true, never>;
}
