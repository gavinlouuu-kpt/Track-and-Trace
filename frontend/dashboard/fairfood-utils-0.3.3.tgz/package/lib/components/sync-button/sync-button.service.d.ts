import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { MatSnackBar } from '@angular/material/snack-bar';
import * as i0 from "@angular/core";
export declare class SyncButtonService {
    snackBar: MatSnackBar;
    http: HttpClient;
    constructor();
    customSnackBar(message: string, type: string): void;
    syncConnect(baseUrl: string): Observable<any>;
    syncNavigate(params: any, baseUrl: string): Observable<any>;
    static ɵfac: i0.ɵɵFactoryDeclaration<SyncButtonService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<SyncButtonService>;
}
