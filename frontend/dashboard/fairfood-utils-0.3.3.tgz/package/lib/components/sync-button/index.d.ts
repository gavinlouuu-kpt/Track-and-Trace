export { SyncBtnComponent } from './sync-button.component';
