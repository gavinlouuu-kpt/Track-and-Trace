import { EventEmitter } from '@angular/core';
import * as i0 from "@angular/core";
export interface ButtonState {
    action?: string;
    disabled: boolean;
    currentStep?: string;
    buttonText: string;
}
export declare class ActionButtonsComponent {
    buttonNextState: ButtonState;
    buttonPrevText: string;
    customId: string;
    buttonsClicked: EventEmitter<any>;
    buttonNavigation(type: string): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<ActionButtonsComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<ActionButtonsComponent, "app-action-buttons", never, { "buttonNextState": { "alias": "buttonNextState"; "required": false; }; "buttonPrevText": { "alias": "buttonPrevText"; "required": false; }; "customId": { "alias": "customId"; "required": false; }; }, { "buttonsClicked": "buttonsClicked"; }, never, never, true, never>;
}
