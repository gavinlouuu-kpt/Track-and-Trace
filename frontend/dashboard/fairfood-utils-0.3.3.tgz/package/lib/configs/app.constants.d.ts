import { IhttpHeadConfig } from './app.model';
export declare const HTTP_OPTION_1: Partial<IhttpHeadConfig>;
export declare const HTTP_OPTION_2: Partial<IhttpHeadConfig>;
export declare const HTTP_OPTION_3: Partial<IhttpHeadConfig>;
export declare const HTTP_OPTION_4: Partial<IhttpHeadConfig>;
export declare const HTTP_OPTION_5: Partial<IhttpHeadConfig>;
export declare const HTTP_OPTION_6: Partial<IhttpHeadConfig>;
export declare const HTTP_OPTION_7: Partial<IhttpHeadConfig>;
export declare enum ACTION_TYPE {
    SUCCESS = "success",
    FAILED = "error",
    DELETE = "delete"
}
