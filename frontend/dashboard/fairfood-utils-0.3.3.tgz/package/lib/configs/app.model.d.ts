type FieldNames = 'contentType' | 'token' | 'timezone' | 'userId' | 'nodeId' | 'urlEncode' | 'acceptAll' | 'entityId';
export type IhttpHeadConfig = {
    [K in FieldNames]: boolean;
};
export {};
