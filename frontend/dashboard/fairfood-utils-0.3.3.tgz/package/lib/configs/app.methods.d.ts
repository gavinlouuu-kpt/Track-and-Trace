import { HttpHeaders } from '@angular/common/http';
import { IhttpHeadConfig } from './app.model';
/**
 * Generates HTTP headers based on the provided configuration.
 *
 * @param itemsNeeded - Partial configuration object specifying which headers are needed.
 * @returns HTTP headers options object.
 */
export declare const headerOptions: (itemsNeeded: Partial<IhttpHeadConfig>) => {
    headers: HttpHeaders;
};
