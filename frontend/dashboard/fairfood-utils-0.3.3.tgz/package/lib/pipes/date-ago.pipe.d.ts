import { PipeTransform } from '@angular/core';
import * as i0 from "@angular/core";
export declare class DateAgoPipe implements PipeTransform {
    transform(value: any): any;
    static ɵfac: i0.ɵɵFactoryDeclaration<DateAgoPipe, never>;
    static ɵpipe: i0.ɵɵPipeDeclaration<DateAgoPipe, "dateAgo", true>;
}
